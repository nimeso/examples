<?php

use SilverStripe\Forms\HTMLEditor\TinyMCEConfig;
use SilverStripe\Forms\HTMLEditor\HtmlEditorConfig;



\SilverStripe\ORM\Search\FulltextSearchable::enable();


//HtmlEditorConfig::get('cms')->insertButtonsAfter('code', 'hr');



// TinyMCEConfig::get('cms')
//     ->setButtonsForLine(2, [
//         'styleselect', '|',
//         'paste', 'pastetext', '|',
//         'table', 'ssmedia', 'ssembed', 'sslink', 'unlink', '|',
//         'code','|','hr'
//     ]);
    // ->setOptions([
    //     'importcss_append' => true,
    //     'style_formats'    => $formats,
    // ]);
//$config = TinyMCEConfig::get('cms');
//$config->enablePlugins('template');




HtmlEditorConfig::get('cms')->enablePlugins('template','hr','visualblocks');
HtmlEditorConfig::get('cms')->insertButtonsAfter('code', 'hr','visualblocks');
//HtmlEditorConfig::get('cms')->insertButtonsAfter('code', 'template');