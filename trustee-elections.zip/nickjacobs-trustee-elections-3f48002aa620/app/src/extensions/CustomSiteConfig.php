<?php
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\TextareaField;
use SilverStripe\ORM\DataExtension;
use SilverStripe\Assets\Image;
use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
use SilverStripe\Forms\HeaderField;


class CustomSiteConfig extends DataExtension 
{

    private static $db = [
        'MailChimpFormURL' => 'Varchar',
        //'MailChimpList' => 'Varchar',
        'SuccessMsg'=>'Text',
        'ContactAddress' => 'Text',
        'ContactPhone' => 'Varchar',
        'ContactEmail' => 'Varchar',
        'AdminEmail' => 'Varchar',
        'TwitterLink' => 'Varchar',
        'FacebookLink' => 'Varchar',
        


        
    ];

    private static $has_one = [
       
    ];

    private static $owns = [
        
    ];

    public function updateCMSFields(FieldList $fields) 
    {
        $fields->addFieldToTab("Root.Newsletter", 
            TextField::create("MailChimpFormURL", "Mailchimp Form URL")
        );
        // $fields->addFieldToTab("Root.Newsletter", 
        //     TextField::create("MailChimpList", "Mailchimp list ID")->setDescription('In Mailchimp go to Lists->TheList->Settings->List name and defaults (List ID is in red)')
        // );
        $fields->addFieldToTab("Root.Newsletter", 
            TextareaField::create("SuccessMsg", "Success message")
        );

        $fields->addFieldToTab("Root.Main", 
            HeaderField::create("hf0", "Contact details")
        );

        $fields->addFieldToTab("Root.Main", 
            TextareaField::create("ContactAddress", "Contact address")
        );
        $fields->addFieldToTab("Root.Main", 
            TextField::create("ContactPhone", "Contact phone")
        );
        $fields->addFieldToTab("Root.Main", 
            TextField::create("ContactEmail", "Contact email")
        );
        $fields->addFieldToTab("Root.Main", 
            TextField::create("AdminEmail", "Admin email to send contact enquiries to")
        );

        $fields->addFieldToTab("Root.Main", 
            HeaderField::create("hf1", "Social media")
        );

        $fields->addFieldToTab("Root.Main", 
            TextField::create("TwitterLink", "Twitter URL")
        );
        $fields->addFieldToTab("Root.Main", 
            TextField::create("FacebookLink", "Facebook URL")
        );

       
         

    }
}