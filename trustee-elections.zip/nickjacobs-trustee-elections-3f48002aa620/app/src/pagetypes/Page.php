<?php
namespace {

    use SilverStripe\CMS\Model\SiteTree;
    use SilverStripe\Assets\Image;
	use SilverStripe\AssetAdmin\Forms\UploadField;

    class Page extends SiteTree
    {
        private static $db = [];

        private static $has_one = [
        'PageBanner' => Image::class
        ];

        private static $owns = [
        	'PageBanner'
    	];





    	public function getCMSFields()
	    {
	        $fields = parent::getCMSFields();

	        
	            $up1 = UploadField::create('PageBanner');
	            $up1->setFolderName('PageBanners');
	            $up1->getValidator()->setAllowedExtensions(['png', 'gif', 'jpeg', 'jpg']);	         
	            $fields->addFieldToTab('Root.Banner', $up1);
	            
	        return $fields;
	    }

    }

}
