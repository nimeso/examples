<?php
namespace {

    use SilverStripe\Forms\TextField;
    use SilverStripe\Forms\CheckboxField; 

   
    class ElectionPlannerPage extends Page 
    {

    	private static $db = [
    	   
    	];

        private static $has_one = [];

        private static $has_many = [];

        private static $table_name = 'ElectionPlannerPage';



    	public function getCMSFields()
        {
            $fields = parent::getCMSFields();
            // $fields->addFieldToTab("Root.Main", new CheckboxField("ShowTitle", "Show page title?"),'Content');
            // $fields->addFieldToTab("Root.Main", new TextField("FrameURL", "IFrame URL"),'Content');
            return $fields;
        }



    }
}