<?php
namespace {

    use SilverStripe\Forms\TextField;
    use SilverStripe\Forms\CheckboxField; 

   
    class IFramePage extends Page 
    {

    	private static $db = [
    	   'FrameURL' => 'Text',
           'ShowTitle' => 'Boolean',
           'HeightPx' => 'Varchar',
           'IFrameFullWidth' => 'Boolean'
    	];

        private static $has_one = [];

        private static $has_many = [];

        private static $table_name = 'IFramePage';



    	public function getCMSFields()
        {
            $fields = parent::getCMSFields();
            $fields->addFieldToTab("Root.Main", new CheckboxField("ShowTitle", "Show page title?"),'Content');
            $fields->addFieldToTab("Root.Main", new TextField("FrameURL", "IFrame URL"),'Content');
            $fields->addFieldToTab("Root.Main", new TextField("HeightPx", "IFrame Height"),'Content');
            $fields->addFieldToTab("Root.Main", new CheckboxField("IFrameFullWidth", "Make IFrame the full page width?"),'Content');
            return $fields;
        }



    }
}