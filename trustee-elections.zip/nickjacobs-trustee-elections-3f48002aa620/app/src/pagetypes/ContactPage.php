<?php

use SilverStripe\Forms\TextField;

// namespace Devart\Pages; --cannot namespace due to upgrade of old site
// use Page;

class ContactPage extends Page
{
    private static $table_name = 'ContactPage';

    private static $db = [
        'NotifyEmail' => 'Text',
    ];

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->addFieldToTab('Root.Main', TextField::create('NotifyEmail'), 'Content');

        return $fields;
    }

}
