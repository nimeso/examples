<?php

namespace {
    use SilverStripe\View\Requirements;
    use SilverStripe\CMS\Controllers\ContentController;
    use SilverStripe\ORM\ArrayList;
    use SilverStripe\CMS\Model\SiteTree;
    use SilverStripe\Security\Member;

    class PageController extends ContentController
    {
        /**
         * An array of actions that can be accessed via a request. Each array element should be an action name, and the
         * permissions or conditions required to allow the user to access it.
         *
         * <code>
         * [
         *     'action', // anyone can access this action
         *     'action' => true, // same as above
         *     'action' => 'ADMIN', // you must have ADMIN permissions to access this action
         *     'action' => '->checkAction' // you can only access this action if $this->checkAction() returns true
         * ];
         * </code>
         *
         * @var array
         */
        private static $allowed_actions = ['logout'];

        protected function init()
            {
                parent::init();                
                Requirements::javascript('public/javascript/scripts.min.js');
                
            }




         /**
     * Returns a fixed navigation menu of the given level.
     * @param int $level Menu level to return.
     * @return ArrayList
     */
        public function getMenuIncludingSecure($level = 1)
        {
            if ($level == 1) {
                $result = SiteTree::get()->filter([
                    "ShowInMenus" => 1,
                    "ParentID" => 0,
                ]);
            } else {
                $parent = $this->data();
                $stack = [$parent];

                if ($parent) {
                    while (($parent = $parent->Parent()) && $parent->exists()) {
                        array_unshift($stack, $parent);
                    }
                }

                if (isset($stack[$level - 2])) {
                    $result = $stack[$level - 2]->AllChildren();
                }
            }

            $visible = [];

            // Remove all entries the can not be viewed by the current user
            // We might need to create a show in menu permission
            if (isset($result)) {
                foreach ($result as $page) {
                    /** @var SiteTree $page */
                    //if ($page->canView()) {
                    $visible[] = $page;
                    //}
                }
            }

            return new ArrayList($visible);
        }

        public function MenuIncludingSecure($level)
        {
            return $this->getMenuIncludingSecure($level);
        }

    }
}
