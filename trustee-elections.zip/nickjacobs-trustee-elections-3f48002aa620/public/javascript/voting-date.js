$(function() {
    function o(n) {
        var e, o, s = new Date(n);
        for (i = 0; i < t.length; i++) e = $("#" + t[i].ID), o = t[i].DaysFromVoting ? r(s, t[i].DaysFromVoting) : u(s, t[i].MonthsFromVoting), e.hide().html(o).fadeIn("slow");
        return !1
    }

    function s(t) {
        var e, o, s = new Date(t);
        for (i = 0; i < n.length; i++) e = $("#" + n[i].ID), o = n[i].DaysFromVoting ? r(s, n[i].DaysFromVoting) : u(s, n[i].MonthsFromVoting), e.hide().html(o).fadeIn("slow");
        return !1
    }

    function r(n, t) {
        var i = n.addDays(-t);
        return f(i)
    }

    function u(n, t) {
        var i = n.addMonths(-t);
        return f(i)
    }

    function h(n) {
        var t = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        return t[n.getDay()]
    }

    function c(n) {
        var t = String(n);
        return t.substr(-Math.min(t.length, 2)) > 3 && t.substr(-Math.min(t.length, 2)) < 21 ? "th" : ["th", "st", "nd", "rd", "th"][Math.min(Number(t) % 10, 4)]
    }

    function f(n) {
        return h(n) + ", " + n.getDate() + c(n.getDate()) + " " + e[n.getMonth()] + " " + n.getFullYear()
    }
    $("#voting-date").keydown(function() {
        return !1
    }), $("#fixed-voting-date").keydown(function() {
        return !1
    });
    var n = [{
            ID: "select-RO",
            DaysFromVoting: 37
        }, {
            ID: "close-main-roll",
            DaysFromVoting: 30
        }, {
            ID: "call-for-nominations",
            DaysFromVoting: 28
        }, {
            ID: "close-supplementary-roll",
            DaysFromVoting: 16
        }, {
            ID: "nominations-close",
            DaysFromVoting: 14
        }, {
            ID: "voting-papers-sent",
            DaysFromVoting: 9
        }, {
            ID: "count-votes",
            DaysFromVoting: -6
        }, {
            ID: "board-takes-office",
            DaysFromVoting: -7
        }],
        t = [{
            ID: "fixed-select-RO",
            DaysFromVoting: 37
        }, {
            ID: "fixed-close-main-roll",
            DaysFromVoting: 30
        }, {
            ID: "fixed-call-for-nominations",
            DaysFromVoting: 28
        }, {
            ID: "fixed-close-supplementary-roll",
            DaysFromVoting: 16
        }, {
            ID: "fixed-nominations-close",
            DaysFromVoting: 14
        }, {
            ID: "fixed-voting-papers-sent",
            DaysFromVoting: 9
        }, {
            ID: "fixed-count-votes",
            DaysFromVoting: -6
        }, {
            ID: "fixed-board-takes-office",
            DaysFromVoting: -7
        }],
        e = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    Date.prototype.addDays = function(n) {
        var t = new Date(this.valueOf());
        return t.setDate(t.getDate() + n), t
    }, Date.prototype.addMonths = function(n) {
        var t = new Date(this.valueOf());
        return t.setMonth(t.getMonth() + n), t
    }, $("#voting-date").datepicker({
        dateFormat: "MM d, yy",
        onSelect: s
    }), $("#fixed-voting-date").datepicker({
        dateFormat: "MM d, yy",
        onSelect: o,
        minDate: new Date(2016, 4, 13),
        maxDate: new Date(2016, 5, 10)
    })
})