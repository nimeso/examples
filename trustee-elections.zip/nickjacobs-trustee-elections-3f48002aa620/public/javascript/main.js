$(function () {
  'use strict'


  var toggleAffix = function(affixElement, scrollElement, wrapper) {
  
    var height = affixElement.outerHeight(),
        top = wrapper.offset().top;
    
    if (scrollElement.scrollTop() >= top){
        wrapper.height(height);
        affixElement.addClass("affix");
    }
    else {
        affixElement.removeClass("affix");
        wrapper.height('auto');
    }
      
  };
  

  $('[data-toggle="affix"]').each(function() {
    var ele = $(this),
        wrapper = $('<div></div>');
    
    ele.before(wrapper);
    $(window).on('scroll resize', function() {
        toggleAffix(ele, $(this), wrapper);
    });
    
    // init
    toggleAffix(ele, $(window), wrapper);
  });



  $('.content hr').hide().next('p').addClass('row tiny-gutters').find('a').wrap('<div class="col-md-4"></div>');


  $('.ss-htmleditorfield-file.embed').fitVids();


  $('.subnav.collapse').on('show.bs.collapse', function () {
        $(this).prev().addClass('showed');
    });
  $('.subnav.collapse').on('hide.bs.collapse', function () {
        $(this).prev().removeClass('showed');
    });
  


  $(window).scroll(function(){ 
        if ($(this).scrollTop() > 100) { 
            $('#backToTop').fadeIn(); 
        } else { 
            $('#backToTop').fadeOut(); 
        } 
    });
  $('#backToTop').click(function(){ 
        $("html, body").animate({ scrollTop: 0 }, 400); 
        return false; 
    });


  $('.menu-opener').on('click',function(){
    $(this).closest('.haschildren').toggleClass('active');
  });

  //any links with images inside - dont add an external link icon
  $("a").each(function(){
    if ( $(this).children('img').length > 0 ) {
    $(this).addClass("no-ext");
    }
  });

  // search form
  var searchField = $('#SearchForm_SearchForm_Search');
  var default_value = searchField.val();

  searchField.focus(function() {
    $(this).addClass('active');
    if(searchField.val() == default_value) {
      searchField.val('');
    }
  });

  searchField.blur(function() {
      if(searchField.val() == '') {
        searchField.val(default_value);
      }
  });

  $(".search-form .action").on('click',function(e){
    if(searchField.val() != "Search" && searchField.val() != ""){
      $("#SearchForm_SearchForm").submit();
    }else{
      $(".search-form .middleColumn").toggleClass("showing");
    }
    e.preventDefault();
  });

  if( searchField.val() != "Search" && searchField.val() != "" ) {
    $(".search-form .middleColumn").addClass("showing");
  }

});




