var gulp         = require('gulp');
var livereload   = require('gulp-livereload');
var sass         = require('gulp-sass');
var uglify       = require('gulp-uglify');
var postcss      = require('gulp-postcss');
var autoprefixer = require('autoprefixer');
var concat       = require('gulp-concat');
var jshint       = require('gulp-jshint');


gulp.task('sass', function() {
  var processors = [
    autoprefixer({ browsers: ['last 2 versions'] }),
    require("postcss-import")
  ];

  return gulp.src('themes/mygps/sass/styles.scss')
    .pipe(sass({ outputStyle: 'compressed' }).on('error', function(err) {
      console.log(err.toString());
      this.emit('end');
    }))
    .pipe(postcss(processors).on('error', function(err) {
      console.log(err);
    }))
    .pipe(gulp.dest('themes/mygps/css'))
    .pipe(livereload());
});


gulp.task('uglify', function() {
  return gulp.src('themes/mygps/js/*.js')
    .pipe(jshint()).pipe(jshint.reporter('jshint-stylish'))
    // .pipe(jshint.reporter('fail'))
    .pipe(livereload())
    .pipe(uglify({ compress: { drop_console: true } }).on('error', function(err) {
      console.log(err.toString());
      this.emit('end');
    }))
    .pipe(gulp.dest('themes/mygps/js/min'));
});

gulp.task('productionscripts', function() {
  gulp.src([
      'themes/mygps/bower/jquery/dist/jquery.min.js',
      'themes/mygps/bower/bootstrap-sass/assets/javascripts/bootstrap.min.js',
      'themes/mygps/bower/underscore/underscore-min.js',
      'themes/mygps/bower/matchHeight/dist/jquery.matchHeight-min.js',
    ])
    .pipe(concat('plugins.js'))
    .pipe(uglify())
    .pipe(gulp.dest('themes/mygps/js/min/'));
});

gulp.task('lint', function() {
  return gulp.src('themes/mygps/js/*.js')
    .pipe(jshint()).pipe(jshint.reporter('jshint-stylish'));
});

gulp.task('watch', function() {
  livereload.listen();
  gulp.watch('themes/mygps/sass/**/*.scss', ['sass']);
  gulp.watch('themes/mygps/js/*.js', ['uglify']);
  gulp.watch('themes/mygps/templates/**/*.ss').on('change', livereload.changed);
});

gulp.task('default', ['productionscripts', 'uglify', 'sass', 'watch']);
