require('./angular-masonry');
module.exports = 'wu.masonry';
