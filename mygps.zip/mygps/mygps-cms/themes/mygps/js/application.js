(function($) {

  var dom;
  var pageLoaded = false;
  var pageRendered = false;
  var scrollTop = 0;
  var winW = 0;
  var winH = 0;
  var dropDownScrollStart = 0;
  // var isMobile = Modernizr.touchevents;

  init();


  /**
   * Initialization
   */
  function init() {
    // Selector aliases
    dom = {
      window: $(window),
      document: $(document),
      html: $('html'),
      body: $('body'),
      pageWrap: $('.page-wrap'),
      mainMenuWrapper: $('.main-menu-wrapper'),
      mobileNavWrapper: $('.mobile-nav')
    };

    //defaults

    // Preload page
    dom.window.load(function() {
      pageLoaded = true;
      renderPage();
    });
  }



  /**
   * Get accurate viewport width/height
   * usage: viewport().width or viewport().height
   */
  function viewport() {
    var e = window,
      a = 'inner';
    if (!('innerWidth' in window)) {
      a = 'client';
      e = document.documentElement || document.body;
    }
    return { width: e[a + 'Width'], height: e[a + 'Height'] };
  }

  /**
   * Render page - most things should go in here
   */
  function renderPage() {
    pageRendered = true;

    scaleLayout();
    setupEventHandlers();

  }



  function setupEventHandlers() {
    // Resize
    $(window).on('resize', _.debounce(function() {
      scaleLayout();
    }, 50));

    // Scroll
    $(window).on('scroll', function() {
      scrollTop = dom.window.scrollTop();
      window.requestAnimationFrame(scrollHandler);
    });


    $('a.jumpto')
        .on('click', function() {
            var id = '#' + this.href.split('#')[1];
            jumpTo($(id));
            return false;
        });


    $('#toggle-main-menu').click(function() {
      //show/hide the menu
      dom.body.toggleClass('noscroll');

      if (dom.mainMenuWrapper.hasClass('open')) {
        dom.mainMenuWrapper.animate({
          opacity: 0
        }, {
          duration: 300,
          complete: function() {
            dom.mainMenuWrapper.removeClass('open');
          }
        });
      } else {
        dom.mainMenuWrapper.addClass('open');
        dom.mainMenuWrapper.css("opacity", 0).animate({
          opacity: 1
        }, {
          duration: 400
        });
      }

      return false;
    });



    $('.open-submenu')
      .on('click', function() {
        var doClose = $(this).hasClass('active');
        var parent = $(this);
        var submenu = parent.next();

        if (doClose) {
          submenu.slideUp(400, function() {
            submenu.removeClass('open');
            parent.removeClass('active');
          });
        } else {
          dropDownScrollStart = scrollTop;
          //close any other open menus
          $('.open-submenu.active').each(function() {
            $(this).trigger('click');
          });


          parent.addClass('active');
          submenu.addClass('open').hide();
          submenu.slideDown(400, function() {});
        }
        return false;
      });

  }


  /**
   * Scroll handler
   */
  function scrollHandler() {

    if (scrollTop > 150) { //example code
      dom.mainMenuWrapper.addClass('solid');
      dom.mobileNavWrapper.addClass('solid');
    } else {
      dom.mainMenuWrapper.removeClass('solid');
      dom.mobileNavWrapper.removeClass('solid');
    }
  }




  /**
   * Scale layout
   */
  function scaleLayout() {
    winW = viewport().width;
    winH = viewport().height;

    //may not be necessary to have this function in this website
  }



  function jumpTo(div) {
      var offset;
      if ($('.mobile-nav')
          .is(":visible")) {
          offset = $('.mobile-nav')
              .height();
      } else {
          offset = $('.main-menu-wrapper')
              .height();
      }

      $("body, html")
          .animate({
              scrollTop: div.offset()
                  .top - offset
          }, 400);

  }
  app.jumpTo = jumpTo;

}(jQuery));