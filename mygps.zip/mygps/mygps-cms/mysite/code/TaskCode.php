<?php
class TaskCode extends Task{
	
	private static $db = array(
		"Code" => "Varchar(56)"
	);
	
	private static $has_one = array(
		
	);

	public function getCMSFields(){
		$fields = parent::getCMSFields();	
		return $fields;
	}
	
}