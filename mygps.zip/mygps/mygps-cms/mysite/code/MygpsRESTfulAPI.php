<?php
class MygpsRESTfulAPI extends RESTfulAPI
{
    private static $allowed_actions = array(
        'GetQuests',
        'GetCompletedQuests',
        'GetQuestsUnstarted',
        'GetQuestTasks',
        'DeleteAllStudentTasks',
        'GetQuestsYourDoing',
        'GetTotalGrowthCategoryQuestsByAraCourse',
        'GetDoneGrowthCategoryQuestsByAraCourse',
        'GetCompletedQuestsByGrowthCategory',
        'GetFullStudentQuest',
        'UploadFile',
        'GetStudents',
        'CodeCheck',
        'UpdateOrganizationCourses',
        'SendContactMessage',
        'SendContactMessageGlobal',
        'AddToFavorites',
        'RemoveFromFavorites',
        'GetFavoriteStudents',
        'Member',
    );

    private static $url_handlers = array(
        'auth/$Action'   => 'auth',
        'acl/$Action'    => 'acl',
        'Member/$ID'     => 'Member',
        '$ClassName/$ID' => 'index',
    );

    public function Member($request)
    {
        $member = $this->GetMember($request);
        if ($member instanceof RESTfulAPI_Error) {
            return $this->error($member);
        }

        $params = $request->routeParams();

        $params['ClassName'] = 'Member';
        $request->setRouteParams($params);
        return parent::index($request);
    }

    public function GetFavoriteStudents($request)
    {
        $member = $this->GetMember($request);
        if ($member instanceof RESTfulAPI_Error) {
            return $this->error($member);
        }

        $data = array();
        if ($students = $member->FavoriteStudents()) {
            foreach ($students as $student) {
                if ($student->AllowOrganizations) {
                    $fStudent = $student->toMap();
                    if ($student->Photo()->exists()) {
                        $fStudent['PhotoLink'] = $student->Photo()->CroppedImage(256, 256)->getAbsoluteURL();
                    } else {
                        $siteConfig            = SiteConfig::current_site_config();
                        $fStudent['PhotoLink'] = $siteConfig->DefaultAvatar()->CroppedImage(320, 320)->getAbsoluteURL();
                    }

                    if ($student->AraCourse()->exists()) {
                        $fStudent['AraCourseName'] = $student->AraCourse()->Title;
                    }

                    if ($student->CV()->exists()) {
                        $fStudent['CVLink'] = $student->CV()->getAbsoluteURL();
                    }
                    array_push($data, $fStudent);
                }
            }
        }

        return $this->answer(json_encode($data));
    }

    public function RemoveFromFavorites($request)
    {
        $obj = json_decode($request->getBody());
        if (property_exists($obj, 'MemberID')) {
            if ($member = Member::get()->where(array('ID' => $obj->MemberID))->first()) {
                if (property_exists($obj, 'StudentID')) {
                    if ($student = Member::get()->where(array('ID' => $obj->StudentID))->first()) {
                        $member->FavoriteStudents()->remove($student);
                    }
                }
            }
        }

        return $this->answer(json_encode('success'));
    }

    public function AddToFavorites($request)
    {
        $obj = json_decode($request->getBody());
        if (property_exists($obj, 'MemberID')) {
            if ($member = Member::get()->where(array('ID' => $obj->MemberID))->first()) {
                if (property_exists($obj, 'StudentID')) {
                    if ($student = Member::get()->where(array('ID' => $obj->StudentID))->first()) {
                        $member->FavoriteStudents()->add($student);
                    }
                }
            }
        }
        return $this->answer(json_encode('success'));
    }

    public function SendContactMessage($request)
    {
        $obj = json_decode($request->getBody());
        if (property_exists($obj, 'MemberID')) {
            if ($member = Member::get()->where(array('ID' => $obj->MemberID))->first()) {
                if (property_exists($obj, 'StudentID')) {
                    if ($student = Member::get()->where(array('ID' => $obj->StudentID))->first()) {
                        if (property_exists($obj, 'Message')) {

                            $from = 'support@mygps.co.nz';
                            $to   = $student->Email;
                            //$to = "nimeso@gmail.com";
                            $sub   = 'Direct Message From myGPS';
                            $email = new Email($from, $to, $sub);
                            $email->setTemplate('StudentContact');
                            $email->populateTemplate(new ArrayData(array(
                                'Member'  => $member,
                                'Message' => $obj->Message,
                            )));
                            $email->send();

                        }
                    }
                }
            }
        }
        return $this->answer(json_encode('success'));
    }

    public function SendContactMessageGlobal($request)
    {
        $obj = json_decode($request->getBody());
        if (property_exists($obj, 'MemberID')) {
            if ($member = Member::get()->where(array('ID' => $obj->MemberID))->first()) {

                if (property_exists($obj, 'Message')) {

                    $from  = $member->Email;
                    $to    = 'support@mygps.co.nz';
                    $sub   = 'Direct Message From myGPS';
                    $email = new Email($from, $to, $sub);
                    $email->setTemplate('GlobalContact');
                    $email->populateTemplate(new ArrayData(array(
                        'Member'  => $member,
                        'Message' => $obj->Message,
                    )));
                    $email->send();

                }

            }
        }
        return $this->answer(json_encode('success'));
    }

    public function UpdateOrganizationCourses($request)
    {
        $obj = json_decode($request->getBody());

        if (property_exists($obj, 'MemberID')) {
            if ($member = Member::get()->where(array('ID' => $obj->MemberID))->first()) {
                $member->AraCourses()->removeAll();
                foreach ($obj->Courses as $rcourse) {
                    if ($course = AraCourse::get()->where(array('ID' => $rcourse))->first()) {
                        $member->AraCourses()->add($course);
                    }
                }
            }
        }
        echo 'success';

    }

    public function GetStudents($request)
    {

        $start = 0;
        $end = 2;
        $upper = $start;

        $member = $this->GetMember($request);
        if ($member instanceof RESTfulAPI_Error) {
            return $this->error($member);
        }

        $data = array();
        if ($group = Group::get()->where(array('code' => 'students'))->first()) {
            if ($group->Members()) {

                foreach ($group->Members() as $student) {

                    foreach ($member->AraCourses() as $course) {
                        if ($student->AllowOrganizations && $student->AraCourseID == $course->ID) {

                            $fStudent = $student->toMap();

                            $fStudent['Rank'] = $this->getCompletedNum($student->ID);

                            if ($student->Photo()->exists()) {
                                $fStudent['PhotoLink'] = $student->Photo()->CroppedImage(256, 256)->getAbsoluteURL();
                            } else {
                                $siteConfig            = SiteConfig::current_site_config();
                                $fStudent['PhotoLink'] = $siteConfig->DefaultAvatar()->CroppedImage(320, 320)->getAbsoluteURL();
                            }

                            if ($student->AraCourse()->exists()) {
                                $fStudent['AraCourseName'] = $student->AraCourse()->Title;
                            }

                            if ($student->CV()->exists()) {
                                $fStudent['CVLink'] = $student->CV()->getAbsoluteURL();
                            }

                            $fStudent['Favorite'] = null;
                            foreach ($member->FavoriteStudents() as $fav) {
                                if ($fav->ID == $student->ID) {
                                    $fStudent['Favorite'] = 1;
                                }
                            }

                            //if($student->Misson){
                            array_push($data, $fStudent);
                            //}

                            $upper ++;
                        }
                    }
                }
            }
        }

        $rank = array();
        foreach ($data as $key => $row) {
            $rank[$key] = $row['Rank'];
        }
        array_multisort($rank, SORT_DESC, $data);

        return $this->answer(json_encode($data));
    }

    public function getCompletedNum($studentID)
    {
        $c = 0;
        if ($quests = Quest::get()) {
            foreach ($quests as $quest) {
                if ($studentQuests = StudentQuest::get()->filter(array('MemberID' => $studentID, 'QuestID' => $quest->ID, 'Status' => 'completed'))->first()) {
                    $c += 1;
                }
            }
        }
        return $c;
    }

    public function CodeCheck($request)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        $code   = $request->getVar('Code');
        $taskID = $request->getVar('TaskID');
        $task   = Task::get()->where(array('ID' => $taskID))->first();

        if ($task->Code == $code) {
            return 'correct';
        } else {
            return 'wrong';
        }

    }

    public function UploadFile($request)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if ($file = $request->postVar('file')) {

            $ranFolderName = $this->generateRandomString();

            $baseFolder = Folder::find_or_make('myGPSUploads');
            $newFolder  = Folder::find_or_make('myGPSUploads/' . $ranFolderName);

            $newfile           = new Image();
            $newfile->ParentID = $newFolder->ID;
            $upload            = new Upload();
            $upload->loadIntoFile($file, $newfile, 'myGPSUploads/' . $ranFolderName);
            $newfile->write();

            echo $newfile->ID;

        } else {
            $error = array(
                'status'  => 'error',
                'message' => 'No file was found',
            );
            echo json_encode($error);
        }
    }

    public function GetCompletedQuestsByGrowthCategory($data)
    {
        //$student = $this->GetMember($data, 'StudentID');
        if (!$id = (int) $data->param('ID')) {
            $id = $data->getVar('StudentID');
        }

        $student = Member::get_one('Member', ['ID' => $id]);

        if (empty($student)) {
            return $this->error(new RESTfulAPI_Error(400, 'Member not found.'));
        }

        $studentQuests = StudentQuest::get()->where(array('MemberID' => $student->ID));

        $quests    = Quest::get()->where(array('GrowthCategoryID' => $data->getVar('GrowthCategory'), 'IsActive' => 1));
        $finQuests = new ArrayList();

        foreach ($quests as $quest) {

            foreach ($quest->AraCourses() as $course) {

                if ($student->AraCourseID == $course->ID) {

                    foreach ($studentQuests as $studentQuest) {
                        if ($studentQuest->QuestID == $quest->ID && $studentQuest->Status == 'completed') {
                            $finQuests->add($quest);
                        }
                    }

                }
            }
        }

        if ($finQuests->count() > 0) {

            $print = '00';
            $num   = $finQuests->count();
            if ($num < 10) {
                $print = '0' . $num;
            }

            $data = array(
                'GrowthCategoryID' => $data->getVar('GrowthCategory'),
                'Value'            => $print,
            );
        } else {
            $data = array(
                'GrowthCategoryID' => $data->getVar('GrowthCategory'),
                'Value'            => '00',
            );
        }

        return $this->answer(json_encode($data));

    }

    public function GetTotalGrowthCategoryQuestsByAraCourse($data)
    {
        //$student = $this->GetMember($data, 'StudentID');
        if (!$id = (int) $data->param('ID')) {
            $id = $data->getVar('StudentID');
        }

        $student = Member::get_one('Member', ['ID' => $id]);

        if (empty($student)) {
            return $this->error(new RESTfulAPI_Error(400, 'Member not found.'));
        }

        $quests    = Quest::get()->where(array('GrowthCategoryID' => $data->getVar('GrowthCategory')))->filter(array('IsActive' => 1));
        $finQuests = new ArrayList();

        foreach ($quests as $quest) {

            foreach ($quest->AraCourses() as $course) {
                if ($student->AraCourseID == $course->ID) {
                    $finQuests->add($quest);
                }
            }
        }

        if ($finQuests->count() > 0) {

            $count = '0';
            if ($finQuests->count() < 10) {
                $count = '0' . $finQuests->count();
            } else {
                $count = $finQuests->count();
            }

            $data = array(
                'GrowthCategoryID' => $data->getVar('GrowthCategory'),
                'Value'            => $count,
            );
        } else {
            $data = array(
                'GrowthCategoryID' => $data->getVar('GrowthCategory'),
                'Value'            => '00',
            );
        }

        return $this->answer(json_encode($data));
    }

    public function GetDoneGrowthCategoryQuestsByAraCourse($data)
    {
        $student = $this->GetMember($data, 'StudentID');
        if ($student instanceof RESTfulAPI_Error) {
            return $this->error($student);
        }

        $studentQuests = StudentQuest::get()->where(array('MemberID' => $student->ID));

        $quests    = Quest::get()->where(array('GrowthCategoryID' => $data->getVar('GrowthCategory'), 'IsActive' => 1));
        $finQuests = new ArrayList();

        foreach ($quests as $quest) {

            foreach ($quest->AraCourses() as $course) {

                if ($student->AraCourseID == $course->ID) {

                    echo ($course->ID);
                    foreach ($studentQuests as $studentQuest) {
                        if ($studentQuest->QuestID == $quest->ID && $studentQuest->Status == 'completed') {
                            $finQuests->add($quest);
                        }
                    }

                }
            }
        }

        if ($finQuests->count() > 0) {
            $data = array(
                'GrowthCategoryID' => $data->getVar('GrowthCategory'),
                'Value'            => $finQuests->count(),
            );
        } else {
            $data = array(
                'GrowthCategoryID' => $data->getVar('GrowthCategory'),
                'Value'            => 0,
            );
        }

        return $this->answer(json_encode($data));

    }

    public function DeleteAllStudentTasks($data)
    {
        $studentQuest = StudentQuest::get()->where(array('ID' => $data->getVar('StudentQuestID')))->first();
        if ($studentTasks = $studentQuest->StudentTasks()) {
            foreach ($studentTasks as $studentTask) {
                $studentTask->delete();
            }
        }
        return $this->answer(json_encode('success'));

    }

    public function GetQuestTasks($data)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        $courseID = $data->getVar('questid');
        $tasksRaw = Quest::get()->filter(array('IsActive' => 1));

        $tasks = array();
        foreach ($tasksRaw as $task) {
            /*
            $courses = $quest->AraCourses();
            foreach ($courses as $course){
            if($courseID == $course->ID){
            $quests[] = array(
            "ID" => $quest->ID,
            "Title" => $quest->Title,
            "SubTitle" => $quest->SubTitle
            );
            }
            }
             */
            echo $task->Title;
        }

        //echo json_encode($quests);

    }

    public function GetFullStudentQuest($request)
    {
        //get a single student quest record with the quest. INCOMPLETE DO NOT USE
        $id           = $request->getVar('id');
        $StudentQuest = DataObject::get_by_id('StudentQuest', $id)->toMap();
        $Quest        = DataObject::get_by_id('Quest', $StudentQuest['QuestID']);
        $Tasks        = $Quest->Tasks()->toArray(); //actually need to foreach and toMap()

        $Quest = $Quest->toMap();

        return $this->answer(json_encode(compact('StudentQuest', 'Quest', 'Tasks')));
    }

    public function GetQuests($data)
    {
        //get active quests for a given student
        $member = $this->GetMember($data, 'studentid');
        if ($member instanceof RESTfulAPI_Error) {
            return $this->error($member);
        }

        $courseID  = $data->getVar('courseid');
        $studentID = $member->ID;

        $studentQuests = StudentQuest::get()->filter(array('MemberID' => $studentID, 'Status:not' => 'completed'));

        $quests = array();
        foreach ($studentQuests as $sq) {
            $quest = DataObject::get_by_id('Quest', $sq->QuestID);

            $totaldays      = intval($quest->Duration) * 7;
            $task_started   = date_create($sq->Created);
            $interval       = date_diff(date_create(), $task_started)->format('%a');
            $remaining      = $totaldays - $interval;
            $remaining_text = ($remaining >= 0) ? $remaining . ' DAYS LEFT' : abs($remaining) . ' DAYS OVERDUE';

            if ($remaining >= 0) {
                $quests[] = array(
                    'ID'              => $quest->ID,
                    'StudentQuestID'  => $sq->ID,
                    'Title'           => $quest->Title,
                    'Description'     => $quest->Description,
                    'Content'         => utf8_encode($quest->Content),
                    'Date'            => $quest->obj('Date')->Ago(),
                    'GrowthTitle'     => $quest->getGrowthTitle(),
                    'GrowthIcon'      => $quest->getGrowthIconURL(),
                    'GrowthIconLight' => $quest->getGrowthIconLightURL(),
                    'Colour'          => $quest->GrowthCategory()->Colour,
                    'LightColour'     => $quest->GrowthCategory()->LightColour,
                    'DaysRemaining'   => $remaining_text,
                    'Duration'        => $quest->Duration,
                );
            } else {
                $sq->delete();
            }

        }

        return $this->answer(json_encode($quests));
    }

    public function GetCompletedQuests($data)
    {
        $member = $this->GetMember($data, 'studentid');
        if ($member instanceof RESTfulAPI_Error) {
            return $this->error($member);
        }

        $courseID  = $data->getVar('courseid');
        $studentID = $member->ID;

        $questsRaw = Quest::get()->filter(array('IsActive' => 1));

        $quests = array();
        foreach ($questsRaw as $quest) {

            $unstartedCheck     = false;
            $questGrowIcon      = $quest->getGrowthIconURL();
            $questGrowIconLight = $quest->getGrowthIconLightURL();
            $questGrowTitle     = $quest->getGrowthTitle();
            $questGrowID        = $quest->GrowthCategory()->ID;

            if ($studentQuests = StudentQuest::get()->filter(array('MemberID' => $studentID, 'QuestID' => $quest->ID))) {
                foreach ($studentQuests as $studentQuest) {
                    if ($studentQuest->Status == 'completed') {
                        $unstartedCheck = true;
                    }
                }
            }

            $courses = $quest->AraCourses();

            foreach ($courses as $course) {
                if (($courseID == $course->ID) && $unstartedCheck) {

                    foreach ($studentQuests as $studentQuest) {
                        $studentQuestID = $studentQuest->ID;
                        $taskArray      = array();
                        if ($studentQuest->QuestID == $quest->ID) {
                            if ($studentQuest->StudentTasks()->exists()) {
                                foreach ($studentQuest->StudentTasks() as $studentTask) {
                                    $task        = Task::get()->filter(array('ID' => $studentTask->TaskID))->first();
                                    $taskArray[] = array(
                                        'Title'     => $studentTask->Task()->Title,
                                        'ClassName' => $studentTask->Task()->ClassName,
                                        'Value'     => $studentTask->Value,
                                        'Label'     => $studentTask->Label,
                                        'FileName'  => $studentTask->FileUpload()->Name,
                                        'FilePath'  => $studentTask->FileUpload()->AbsoluteLink(),
                                    );
                                }
                            }
                        }
                    }

                    $quests[] = array(
                        'test'            => 'test',
                        'ID'              => $quest->ID,
                        'Title'           => $quest->Title,
                        'PublicTitle'     => $quest->PublicTitle,
                        'PublicSubTitle'  => $quest->PublicSubTitle,
                        'Description'     => $quest->Description,
                        'Content'         => utf8_encode($quest->Content),
                        'Date'            => $quest->obj('Date')->Ago(),
                        'GrowthTitle'     => $questGrowTitle,
                        'GrowthIcon'      => $questGrowIcon,
                        'GrowthIconLight' => $questGrowIconLight,
                        'GrowthID'        => $questGrowID,
                        'Colour'          => $quest->GrowthCategory()->Colour,
                        'LightColour'     => $quest->GrowthCategory()->LightColour,
                        'StudentQuestID'  => $studentQuestID,
                        'Tasks'           => $taskArray,
                    );

                }
            }
        }

        return $this->answer(json_encode($quests));
    }

    public function GetQuestsUnstarted($data)
    {
        $member = $this->GetMember($data, 'studentid');
        if ($member instanceof RESTfulAPI_Error) {
            return $this->error($member);
        }

        $courseID  = $data->getVar('courseid');
        $studentID = $member->ID;

        $questsRaw = Quest::get()->filter(array('IsActive' => 1));

        $quests = array();
        foreach ($questsRaw as $quest) {

            $dateString = $quest->obj('Date')->Ago();

            if (strpos($dateString, 'ago') === false) {

                $unstartedCheck     = true;
                $questGrowIcon      = $quest->getGrowthIconURL();
                $questGrowIconLight = $quest->getGrowthIconLightURL();
                $questGrowTitle     = $quest->getGrowthTitle();

                if ($studentQuests = StudentQuest::get()->filter(array('MemberID' => $studentID, 'QuestID' => $quest->ID))) {

                    foreach ($studentQuests as $studentQuest) {

                        if ($studentQuest->Status != 'completed') {
                            $unstartedCheck = false;
                        }

                        if ($studentQuest->Status == 'completed' && $quest->OneOffQuest == 1) {
                            $unstartedCheck = false;
                        }
                    }

                }

                $courses = $quest->AraCourses();

                foreach ($courses as $course) {

                    if (($courseID == $course->ID) && $unstartedCheck) {

                        $quests[] = array(
                            'ID'              => $quest->ID,
                            'Title'           => $quest->Title,
                            'Description'     => $quest->Description,
                            'Content'         => utf8_encode($quest->Content),
                            'Date'            => $quest->obj('Date')->Ago(),
                            'GrowthTitle'     => $questGrowTitle,
                            'GrowthIcon'      => $questGrowIcon,
                            'GrowthIconLight' => $questGrowIconLight,
                            'Colour'          => $quest->GrowthCategory()->Colour,
                            'LightColour'     => $quest->GrowthCategory()->LightColour,
                        );
                    }
                }
            }
        }

        return $this->answer(json_encode($quests));
    }

    public function GetQuestsYourDoing($data)
    {
        $member = $this->GetMember($data, 'studentid');
        if ($member instanceof RESTfulAPI_Error) {
            return $this->error($member);
        }

        $courseID  = $data->getVar('courseid');
        $studentID = $member->ID;

        $questsRaw = Quest::get()->filter(array('IsActive' => 1));

        $quests = array();
        foreach ($questsRaw as $quest) {

            $msg            = '';
            $unstartedCheck = true;
            $questGrowIcon  = $quest->getGrowthIconURL();

            if ($studentQuests = StudentQuest::get()->filter(array('MemberID' => $studentID, 'QuestID' => $quest->ID))) {

                if ($quest->StudentQuests()->count() < 1) {
                    $msg .= 'NO StudentQuest found = ' . $quest->Title . '</br>';
                    $unstartedCheck = false;
                }

                //$msg .= "NOT FOUND Student Quest for Quest = ".$quest->StudentQuests()->count()."</br>";

                foreach ($studentQuests as $studentQuest) {
                    //$msg .= "YES</br>";
                    //$msg .= "Found Student Quest for Quest = ".$quest->Title." - Status == ".$studentQuest->Status."</br>";

                    if (!$studentQuest->Status || $studentQuest->Status != 'started') {
                        $unstartedCheck = false;
                    }
                }

            } else {
                //$msg .= "NOT FOUND Student Quest for Quest = ".$quest->Title."</br>";
            }

            //echo $msg;

            $courses = $quest->AraCourses();

            foreach ($courses as $course) {
                if ($courseID == $course->ID && $unstartedCheck) {

                    $quests[] = array(
                        'ID'         => $quest->ID,
                        'Title'      => $quest->Title,
                        'SubTitle'   => $quest->SubTitle,
                        'GrowthIcon' => $questGrowIcon,
                    );
                }
            }
        }

        return $this->answer(json_encode($quests));

    }

    public function index(SS_HTTPRequest $request)
    {
        $method  = $request->param('ClassName');
        $actions = Config::inst()->get(get_class($this), 'allowed_actions');

        if (in_array($method, $actions)) {
            return $this->$method($request);
        }

        return parent::index($request);
    }

    protected function unformatPayloadData(array $data)
    {
        $unformattedData = array();

        foreach ($data as $key => $value) {
            $newKey = $this->deserializeColumnName($key);

            if (is_array($value)) {
                $newValue = $this->unformatPayloadData($value);
            } else {
                $newValue = $value;
            }

            $unformattedData[$newKey] = $newValue;
        }

        return $unformattedData;
    }

    public static function GetMember($request, $idfield = 'studentid')
    {
        //make sure we only get back user details belonging to the user currently logged in
        if (!$id = (int) $request->param('ID')) {
            $id = $request->getVar($idfield);
        }

        if (!$token = $request->getHeader('X-Silverstripe-Apitoken')) {
            $token = $request->requestVar('token');
        }

        if (!$token) {
            return new RESTfulAPI_Error(400, 'Invalid or missing token.');
        }

        $member = Member::get_one('Member', ['ApiToken' => $token]);

        if (empty($member) || $id != $member->ID) {
            return new RESTfulAPI_Error(400, 'Invalid or missing ID.');
        }

        return $member;
    }

}
