<?php
class Task extends DataObject{

	private static $db = array(
		"Title"               => "Varchar(256)",
		"PublicProfileTitle"  => "Varchar(256)",
		"Required"            => "Boolean",
		"ProfileField"        => "Varchar(128)",
		"ShowOnPublicProfile" => "Boolean"
	);

	private static $has_one = array(

	);

	private static $has_many = array(
		"StudentTasks" => "StudentTask"
	);

	/*private static $belongs_many_many= array(
		"Quests" => "Quest"
	);*/

	private static $summary_fields = array(
		"Title",
		"ClassName"
	);

	public function getCMSFields(){

		$profileFields = array(
			"FirstName"         => "First Name",
			"Surname"           => "Surname",
			"Email"             => " Email",
			"Mission"           => "Purpose Statement",
			"Referance"         => "Endorsment",
			"ReferanceName"     => "Endorsment Person Name",
			"ReferencePosition" => "Endorsment Person Job Title",
			"LinkedInURL"       => "LinkedIn URL",
			"TwitterURL"        => "Twitter URL",
			"FacebookURL"       => "Facebook URL",
			"PortfolioURL"      => "Portfolio URL",
			"BlogURL"           => "Blog URL",
			"PhotoID"           => "Photo Image",
			"CVID"              => "CV File"
		);

		$fields = parent::getCMSFields();

		$fields->addFieldToTab('Root.Main', $dd = new DropdownField("ProfileField","Select a profile field (optional)",$profileFields));
		$dd->setEmptyString('None');
		return $fields;
	}

	public function onAfterSerialize( &$formattedDataObjectMap ){

  		$formattedDataObjectMap["Class"] = $this->ClassName;

  	}

}