<?php
class AraCourse extends DataObject
{

    private static $db = array(
        "Title"     => "Varchar(256)",
        "CouseCode" => "Varchar(256)",
        "Content"   => "HTMLText",
    );

    private static $has_one = array(

    );

    private static $has_many = array(
        "Students" => "Member",
    );

    private static $belongs_many_many = array(
        "Quests"  => "Quest",
        "Members" => "Member",
    );

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        return $fields;
    }


    /**
     * Get full shortened list of all courses
     *
     * @return array
     */
    public static function GetList()
    {
        $coursesRaw = AraCourse::get();

        $courses    = array();
        foreach ($coursesRaw as $course) {
            $courses[] = array(
                "Title" => $course->Title,
                "ID"    => $course->ID,
            );
        }

        return $courses;
    }

}
