<?php
class StudentQuest extends DataObject{

	private static $db = array(
		"Status"      => "Varchar(16)", // started, completed
		"CompletedAt" => "Datetime"
	);

	private static $has_one = array(
		"Member" => "Member",
		"Quest"  => "Quest"
	);

	private static $has_many = array(
		"StudentTasks" => "StudentTask"
	);
	
	private static $summary_fields = array(
		"LastEdited" => "Last Edited",
		"Quest.Title" => "Quest Title",
		"getTasks" => "Tasks"
	);
	
	public function getTasks() {
		$str = "";
		$studentTasks = $this->StudentTasks();
		foreach ($this->StudentTasks() as $studentTask) {
			$str .= "<strong>".$studentTask->Task()->Title."</strong></br>";
			if($studentTask->FileUpload()->exists()){
				$str .= "<a href='".$studentTask->FileUpload()->AbsoluteLink()."' target='_blank'>".$studentTask->FileUpload()->Name."</a></br></br>";
			}else{
				$str .= $studentTask->Value."</br></br>";
			}
			
		}
		return DBField::create_field('HTMLVarchar',$str);
	}

}