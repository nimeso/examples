<?php
class HelpPage extends DataObject{

	private static $db = array(
		"Title"   => "Varchar(256)",
		"Content" => "Text",
		"BackgroundColour"  => "Varchar(256)",
		'ButtonBackground' => 'Varchar'
	);

	private static $has_one = array(
		"Image" => "Image"
	);

	public function getCMSFields(){
		$fields = parent::getCMSFields();
		$fields->addFieldToTab('Root.Main', new ColourPicker('BackgroundColour', 'Background Colour'));
		$fields->addFieldToTab('Root.Main', new ColourPicker('ButtonBackground', 'Button Background Colour'));
		return $fields;
	}

	public function onAfterSerialize(&$formattedDataObjectMap) {
		if ($this->Image()->exists()) {
			$formattedDataObjectMap["Image"] = $this->Image()->getAbsoluteURL();
		}
	}

}
