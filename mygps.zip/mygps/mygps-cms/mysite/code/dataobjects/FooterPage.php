<?php
class FooterPage extends DataObject{

	private static $db = array(
		"Title"   => "Varchar(256)",
		"Content" => "HTMLText",
		"BackgroundColour"  => "Varchar(256)",
		'SortOrder' => 'Int'
	);
	
	static $default_sort = "SortOrder ASC";

	public function getCMSFields(){
		$fields = parent::getCMSFields();
		$fields->addFieldToTab('Root.Main', new ColourPicker('BackgroundColour', 'Background Colour'));
		return $fields;
	}

	public function onAfterSerialize(&$formattedDataObjectMap) {

	}

}
