<?php
class QuestCron extends DataObject{

	private static $db = array(
		"QuestID" => "Int",
		"QuestCreated" => "Datetime",

		"Title" => "Varchar(256)",
		"NotificationOne" => "Varchar(256)",
		"NotificationTwo" => "Varchar(256)",
		"Duration" => "Int",
		"Date" => "Datetime",

		"Status" => "Int"
	);

}
