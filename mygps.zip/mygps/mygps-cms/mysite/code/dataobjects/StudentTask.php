<?php
class StudentTask extends DataObject{
	
	private static $db = array(
		"Value" => "Text",
		"Label" => "Varchar(256)"
	);
	
	private static $has_one = array(
		"Task" => "Task",
		"StudentQuest" => "StudentQuest",
		"FileUpload" => "File"
	);
	
}