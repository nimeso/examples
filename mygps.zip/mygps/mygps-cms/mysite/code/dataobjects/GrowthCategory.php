<?php
class GrowthCategory extends DataObject{
	
	static $singular_name = "Focus Area";
	static $plural_name = "Focus Areas";
	
	public static $db = array(
		"Title" => "Varchar(256)",
		"Description" => "Text",
		"Content" => "HTMLText",
		"Colour" => "Varchar(256)",
		"LightColour" => "Varchar(256)"
	);
	
	public static $has_one= array(
		"Icon" => "Image",
		"IconLight" => "Image"
	);
	
	public static $has_many= array(
		"Quests" => "Quest"
	);
	
	public static $many_many= array(
		
	);
	
	public static $summary_fields = array( 
		
    );
    
    private static $casting = array(
      
    );
	
	public function getCMSFields(){
		$fields = parent::getCMSFields();
		
		$fields->addFieldToTab('Root.Main', new ColourPicker('Colour', 'Dark Colour'), "Icon"); 
		$fields->addFieldToTab('Root.Main', new ColourPicker('LightColour', 'Light Colour'), "Icon"); 
		
		return $fields;
	}
	
	public function onAfterSerialize( &$formattedDataObjectMap ){
		
  		if($this->Icon()->exists()){
  			$formattedDataObjectMap["Icon"] = $this->Icon()->CroppedImage(256,256)->getAbsoluteURL();
  		}
  		
		if($this->IconLight()->exists()){
  			$formattedDataObjectMap["IconLight"] = $this->IconLight()->CroppedImage(256,256)->getAbsoluteURL();
  		}
  	}
	
}
