<?php
class Quest extends DataObject{

	private static $db = array(
		"Title"            => "Varchar(256)",
		"PublicTitle" 	   => "Varchar(256)",
		// "PublicSubTitle"   => "Varchar(512)",
		"Description"      => "Text",
		"Date"             => "SS_Datetime",
		"Duration"         => "Int",
		"Content"          => "HTMLText",
		"CompletedContent" => "Text",
		"TipContent"       => "HTMLText",
		"DefaultQuest"     => "Boolean",
		"IsActive"         => "Boolean",
		"OneOffQuest"      => "Boolean",
		//"HelperContent"  => "HTMLText",
		"NotificationOne"  => "Varchar(128)",
		"NotificationTwo"  => "Varchar(128)",
		'SortOrder' => 'Int',
		//"ShowOnPublicProfile" => "Boolean",
		"PublicTemplate" => "Varchar(128)"
	);

	static $default_sort = "SortOrder ASC";

	private static $has_one = array(
		"GrowthCategory" => "GrowthCategory"
	);

	private static $has_many = array(
		"StudentQuests" => "StudentQuest"
	);

	private static $many_many = array(
		"AraCourses" => "AraCourse",
		"Tasks"      => "Task"
	);

	private static $many_many_extraFields = array(
		'Tasks' => array(
			'SortOrder' => 'Int',
		)
	);

	public function Tasks()
	{
		return $this->getManyManyComponents('Tasks')->sort('SortOrder');
	}

	private static $summary_fields = [
	  'Title'                => 'Title',
	  'Description'          => 'Description',
	  'GrowthCategory.Title' => 'Focus Area',
	  'PublicTitle' => 'Public Title',
	  'FriendlyActiveStatus' => 'Status'
	];

	private static $searchable_fields = [
	  'Title'          => 'PartialMatchFilter',
	  'Description'    => 'PartialMatchFilter',
	  'PublicTitle' => 'PartialMatchFilter',
	  'GrowthCategoryID' => ['title'=>'Focus Area'],
	  'IsActive'       => 'Boolean'
	];

	public function getCMSFields(){

		$fields = parent::getCMSFields();
		$fields->removeByName("StudentQuests");
		$fields->removeByName("AraCourses");
		$fields->removeByName("TipContent");
		$fields->removeByName("SortOrder");

		$fields->dataFieldByName('Date')->getDateField()->setConfig('showcalendar', true);
		$fields->dataFieldByName('Date')->getTimeField()->setConfig('use_strtotime', true);
		//$fields->dataFieldByName('Date')->getTimeField()->setValue('now');

		$fields->addFieldsToTab("Root.Main", new TextareaField("Description","Short Title (10 words)"));
		$fields->addFieldsToTab("Root.DetailsAndSuccess", new HtmlEditorField("Content","Quest (50 words)"));
		$fields->addFieldsToTab("Root.DetailsAndSuccess", new TextareaField("CompletedContent","Success Text"));

		$fields->addFieldsToTab("Root.Notifications", new TextareaField("NotificationOne","Notification One"));
		$fields->addFieldsToTab("Root.Notifications", new TextareaField("NotificationTwo","Notification Two"));

		//$fields->addFieldsToTab("Root.PublicProfile", new CheckboxField("ShowOnPublicProfile","Show On Public Profile"));
		//$fields->addFieldsToTab("Root.PublicProfile", new TextField("PublicSubTitle","Sub Title"));

		$publicTemplates = array(
			"portfolio" => "Portfolio",
			"quote" => "Quote",
			"listing" => "Listing"
		);

		$typeDropdown = new DropdownField("PublicTemplate","Quest Type",$publicTemplates);
		$typeDropdown->setHasEmptyDefault(true);

		$fields->addFieldsToTab("Root.PublicProfile",$typeDropdown);

		$fields->addFieldsToTab("Root.PublicProfile", new TextField("PublicTitle","Title - this will override the default title"));
		//$fields->addFieldsToTab("Root.Main", new HtmlEditorField("HelperContent","Helper Content"),"CompletedContent");

		$coures = AraCourse::get()->map("ID","Title");
		$couresID = array();

		if(count($this->AraCourses()) < 1){
			foreach ($coures as $key => $value){
				array_push($couresID,$key);
			}
		}

		$couresDropdown = new CheckboxSetField("AraCourses","Department Focus",$coures);
		if(count($this->AraCourses()) < 1){
			$couresDropdown->setDefaultItems($couresID);
		}

		$fields->addFieldsToTab("Root.Main", $couresDropdown);

		$gridfieldPages = new GridField("Tasks","Tasks",$this->Tasks());
		$gridfieldPages->getConfig()
			 ->addComponent(new GridFieldSortableRows("SortOrder"))
		     ->addComponent(new GridFieldDetailForm())
		     ->addComponent(new GridFieldEditButton())
		     ->addComponent(new GridFieldDeleteAction())
		     ->addComponent($multiClassPages = new GridFieldAddNewMultiClass());
		$multiClassPages->setClasses( array(
			"TaskTitle" => "Title",
			"TaskText" => "Text",
			"TaskArea" => "Text Area",
			"TaskUpload" => "Document Upload",
			"TaskImageUpload" => "Image Upload",
			"TaskCode" => "Event Code",
			"TaskLink" => "Link",
			"TaskListing" => "Listing"
		));
		$fields->addFieldToTab("Root.Tasks", $gridfieldPages);

		$focusAreas = GrowthCategory::get()->map("ID","Title");

		$fields->insertBefore("Title",new DropdownField("GrowthCategoryID","Focus Area",$focusAreas));

		$fields->addFieldsToTab("Root.Main", new CheckboxField("OneOffQuest","One Off Quest"),"AraCourses");
		$fields->addFieldsToTab("Root.Main", new CheckboxField("DefaultQuest","Default Quest"),"AraCourses");


		$duration = array(1 => "1 week",2 => "2 Weeks",4 => "4 Weeks");
		$durationDropdown = new DropdownField("Duration","Duration",$duration);
		$durationDropdown->setEmptyString("Select duration to complete quest");
		$fields->insertBefore("Date", $durationDropdown);

		$fields->addFieldsToTab("Root.Main", new CheckboxField("IsActive"),"Description");


		return $fields;
	}

	public function getFriendlyActiveStatus() {
		return ($this->IsActive == 1) ? "Active" : "Inactive" ;
	}

	public function getGrowthIconURL(){
		if($this->GrowthCategory()->Icon()->exists()){
  			return $this->GrowthCategory()->Icon()->CroppedImage(256,256)->getAbsoluteURL();
  		}
	}

	public function getGrowthTitle(){
  		return $this->GrowthCategory()->Title;
	}

	public function getGrowthIconLightURL(){
		if($this->GrowthCategory()->IconLight()->exists()){
  			return $this->GrowthCategory()->IconLight()->CroppedImage(256,256)->getAbsoluteURL();
  		}
	}

	public function onAfterSerialize( &$formattedDataObjectMap ){

  		if($this->GrowthCategory()->Icon()->exists()){
  			$formattedDataObjectMap["GrowthIcon"] = $this->GrowthCategory()->Icon()->CroppedImage(256,256)->getAbsoluteURL();
  		}

		if($this->GrowthCategory()->IconLight()->exists()){
  			$formattedDataObjectMap["GrowthIconLight"] = $this->GrowthCategory()->IconLight()->CroppedImage(256,256)->getAbsoluteURL();
  		}

		if($this->GrowthCategory()->exists()){
  			$formattedDataObjectMap["GrowthColour"] = $this->GrowthCategory()->Colour;
  		}

		if($this->GrowthCategory()->exists()){
  			$formattedDataObjectMap["GrowthLightColour"] = $this->GrowthCategory()->LightColour;
  		}

		if($this->GrowthCategory()->exists()){
  			$formattedDataObjectMap["GrowthName"] = $this->GrowthCategory()->Title;
  		}

  		$formattedDataObjectMap["Date"] = $this->obj('Date')->Ago();

  	}

	public function onAfterWrite(){
		parent::onAfterWrite();
		/*$to_time = strtotime(date("Y-m-d H:i:s"));
		$from_time = strtotime("2017-12-13 16:46:51");
		$date_difference = (int) round(abs($to_time - $from_time) / 60,2);*/

		$notification = ($this->NotificationOne) ? $this->NotificationOne : $this->Title;

		if($this->LastEdited === $this->Created){ // Checking that, quest is new
			$query = DB::query("
				select dt.Token
				from DeviceToken dt
				inner join Member m on m.ID=dt.StudentID
				inner join Quest_AraCourses qac on qac.AraCourseID=m.AraCourseID
				inner join Quest q on q.ID=qac.QuestID
				where q.ID=".$this->ID."
			");
			if($query){
				foreach($query as $token){
					$this->sendNotification([
						'token' => $token['Token'],
						'title' => $notification,
						'body' => ''
					]);
				}
			}
		}

		$d = date('Y-m-d H:i:s');
		if($this->Duration == 1) $date = date("Y-m-d H:i:s", strtotime($d." +1 week"));
		if($this->Duration == 2) $date = date("Y-m-d H:i:s", strtotime($d." +2 week"));
		if($this->Duration == 4) $date = date("Y-m-d H:i:s", strtotime($d." +4 week"));
		if($this->Duration == 0) $date = $this->Date;

		$QuestCron = QuestCron::create();
		$QuestCron->QuestID = $this->ID;
		$QuestCron->QuestCreated = $this->Created;
		$QuestCron->Title = $this->Title;
		$QuestCron->NotificationOne = $this->NotificationOne;
		$QuestCron->NotificationTwo = $this->NotificationTwo;
		$QuestCron->Duration = $this->Duration;
		$QuestCron->Date = $date;
		$QuestCron->Status = 0;
		$QuestCron->write();
	}

	public function sendNotification($arr){
		if(empty($arr) || !$arr) return false;
		try {
		   $ch = curl_init("https://fcm.googleapis.com/fcm/send");
		   //The device token.
		   $token = $arr["token"];

		   //Title of the Notification.
		   $title = $arr["title"];

		   //Body of the Notification.
		   $body = $arr["body"];

		   //Creating the notification array.
		   $notification = array('title' => $title , 'text' => $body);

		   //This array contains, the token and the notification. The 'to' attribute stores the token.
		   $arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');

		   //Generating JSON encoded string form the above array.
		   $json = json_encode($arrayToSend);
		   //Setup headers:
		   $headers = array();
		   $headers[] = 'Content-Type: application/json';
		   $headers[] = 'Authorization: key=AAAANolNEvo:APA91bEuB2j-ABs9rI0ZRFBrpveEvwWxcYr6yfOpV7O2IUEYoakk24YkYyPfaBp5DddoWOyb0a8p9FfeG_gqifVINVxIXVeuG4sTXAoJHFUxDsJQoRn6GXUTv8sZIydQTB1SQ7hw2WvI'; // key here
		   //Setup curl, add headers and post parameters.
		   curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		   curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
		   $ch = curl_init();
		   curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		   curl_setopt( $ch,CURLOPT_POST, true );
		   curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		   curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		   curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		   curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		   //curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $notification ) );
		   $result = curl_exec($ch );
		   curl_close( $ch );
		   return $result;
	   } catch(Exception $e) {
		   return $e->getMessage();
	   }
    }
}
