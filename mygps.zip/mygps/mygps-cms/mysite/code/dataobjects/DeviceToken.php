<?php
class DeviceToken extends DataObject{

	private static $db = array(
		"Token" => "Varchar(256)",
		"Platform" => "Varchar(100)",
		"StudentID" => "Int",
		"ForAll" => "Int"
	);

}
