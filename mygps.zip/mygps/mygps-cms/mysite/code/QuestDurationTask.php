<?php
class Tasks_Controller extends CliController {
	
	private static $allowed_actions = array(
		'checkQuestDurations',
	);
	
	public function checkQuestDurations() {
		
		$quests = Quest::get()->where("Duration != 0")->filter(array("IsActive" => 1));
		
		foreach ($quests as $quest){
			
			$studentQuests = StudentQuest::get()->filter(array("QuestID" => $quest->ID));
			
			foreach ($studentQuests as $studentQuest){

				$currentDate = strtotime("now");
				$finalDate = strtotime($studentQuest->obj('Created')->Format('Y-m-d'));
				$finalDate = strtotime('+'.$quest->Duration.' weeks',$finalDate);

				if($currentDate > $finalDate){
					$studentQuest->Status = null;
					$studentQuest->write();
				}
				
			}
		}
	}

}