<?php
class Page extends SiteTree
{

    private static $db = array(
        'ShowInFooter' => 'Boolean',
    );

    public function getSettingsFields()
    {
        $fields = parent::getSettingsFields();

        $fields->addFieldToTab('Root.Settings', new CheckBoxField('ShowInFooter', 'Show in footer menu?'), 'ShowInSearch');

        return $fields;
    }

    public function FooterPages()
    {
        return Page::get()->filter(array('ShowInFooter' => 1));
    }

}

class Page_Controller extends ContentController
{

    private static $allowed_actions = array(
        'createMember',
        'getAraCourses',
        'UploadFile',
        'ForgottenPassword',
        'ForgottenPasswordCode',
        'ForgottenPasswordReset',
        'GetFooterPages',
        'GetFooterPage',
        'GetStudentPublic',
        'StudentIDCheck',
        'verifyEmail',
        'getConfirmStatus',
        'updateConfirmStatus',
        'AllowAllStudentAccess',
        'AraLogin',
        'GetPublicCompletedQuests',
        'RegisterToken',
        'QuestNotificationCron',
        'SendNotificationToAll',
    );

    public function SendNotificationToAll($request)
    {
        $title   = $request->getVar('title');
        $message = $request->getVar('msg');

        if (empty($title)) {
            $title = 'MyGPS Notificaton';
        }

        if (empty($message)) {
            $message = '';
        }

        $query = DB::query('select Token,Platform from DeviceToken where ForAll=1');
        if ($query) {
            foreach ($query as $get_results) {
                $data_arr = [
                    'title' => $title,
                    'body'  => $message,
                    'token' => $get_results['Token'],
                ];
                $this->sendNotification($data_arr);
            }
        }
        echo '1';
    }

    public function RegisterToken($request)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');
        $error_arr = [];

        $token      = $request->getVar('token');
        $platform   = $request->getVar('platform');
        $student_id = $request->getVar('student_id');

        if (!$token) {
            $error_arr['token'] = 'Token string is required';
        }

        if (!$platform) {
            $error_arr['platform'] = 'Device platform is required';
        }

        if (!isset($student_id)) {
            $error_arr['student_id'] = 'Student ID is required';
        }

        if ($error_arr) {
            http_response_code(400);
            echo json_encode($error_arr);
            exit;
        }

        // Token For all devices.
        if ($student_id == 0) {
            $DeviceTokenCheck = DeviceToken::get()->filter([
                'Token'     => $token,
                'StudentID' => '0',
            ])->first();

            if (!$DeviceTokenCheck) {
                // Add
                $DeviceToken            = DeviceToken::create();
                $DeviceToken->StudentID = 0;
                $DeviceToken->Token     = $token;
                $DeviceToken->Platform  = $platform;
                $DeviceToken->ForAll    = 1;

                if ($DeviceToken->write()) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Token save successfully.']);
                    exit;
                } else {
                    http_response_code(503);
                    echo json_encode(['message' => 'Record not save successfully. Please try later or contact to administrator.']);
                    exit;
                }
            } else {
                // Update
                $DeviceTokenCheck->Token    = $token;
                $DeviceTokenCheck->Platform = $platform;

                if ($DeviceTokenCheck->write()) {
                    http_response_code(200);
                    echo json_encode(['message' => 'Token save successfully.']);
                    exit;
                } else {
                    http_response_code(503);
                    echo json_encode(['message' => 'Record not save successfully. Please try later or contact to administrator.']);
                    exit;
                }
            }
            exit;
        }

        // Token for specific devices
        $DeviceTokenCheck = DeviceToken::get()->filter([
            'StudentID' => $student_id,
        ])->first();

        if (!$DeviceTokenCheck) {
            // New Record
            $DeviceToken            = DeviceToken::create();
            $DeviceToken->StudentID = $student_id;
            $DeviceToken->Token     = $token;
            $DeviceToken->Platform  = $platform;
            $DeviceToken->ForAll    = 0;

            if ($DeviceToken->write()) {
                http_response_code(200);
                echo json_encode(['message' => 'Token save successfully.']);
                exit;
            } else {
                http_response_code(503);
                echo json_encode(['message' => 'Record not save successfully. Please try later or contact to administrator.']);
                exit;
            }
        } else {
            // Edit Record
            $DeviceTokenCheck->Token    = $token;
            $DeviceTokenCheck->Platform = $platform;

            if ($DeviceTokenCheck->write()) {
                http_response_code(200);
                echo json_encode(['message' => 'Token save successfully.']);
                exit;
            } else {
                http_response_code(503);
                echo json_encode(['message' => 'Record not save successfully. Please try later or contact to administrator.']);
                exit;
            }
        }
    }

    public function set_student_tokens_for_notifications($quest)
    {
        $notification = ($quest['NotificationTwo']) ? $quest['NotificationTwo'] : $quest['Title'];

        $query = DB::query('
			select dt.Token
			from DeviceToken dt
			inner join Member m on m.ID=dt.StudentID
			inner join Quest_AraCourses qac on qac.AraCourseID=m.AraCourseID
			inner join Quest q on q.ID=qac.QuestID
			where q.ID=' . $quest['QuestID'] . '
		');
        if ($query) {
            foreach ($query as $token) {
                $this->sendNotification([
                    'token' => $token['Token'],
                    'title' => $notification,
                    'body'  => '',
                ]);
            }
            $QuestCron = QuestCron::get()->filter([
                'ID' => $quest['ID'],
            ])->first();
            $QuestCron->Status = 1;
            $QuestCron->write();
        }
    }
    public function QuestNotificationCron()
    {
        $query = DB::query('select * from QuestCron where status=0');
        if ($query) {
            foreach ($query as $get_results) {
                if (date('Y-m-d', strtotime($get_results['Date'] . ' -1 day')) === date('Y-m-d')) {
                    $this->set_student_tokens_for_notifications($get_results);
                }
            }
        }
    }

    public function sendNotification($arr)
    {
        if (empty($arr) || !$arr) {
            return false;
        }

        try {
            //The device token.
            $token = $arr['token'];

            //Title of the Notification.
            $title = $arr['title'];

            //Body of the Notification.
            $body = $arr['body'];

            //Creating the notification array.
            $notification = array('title' => $title, 'text' => $body);

            //This array contains, the token and the notification. The 'to' attribute stores the token.
            $arrayToSend = array('to' => $token, 'notification' => $notification, 'priority' => 'high');

            //Generating JSON encoded string form the above array.
            $json = json_encode($arrayToSend);
            //Setup headers:
            $headers   = array();
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Authorization: key=AAAANolNEvo:APA91bEuB2j-ABs9rI0ZRFBrpveEvwWxcYr6yfOpV7O2IUEYoakk24YkYyPfaBp5DddoWOyb0a8p9FfeG_gqifVINVxIXVeuG4sTXAoJHFUxDsJQoRn6GXUTv8sZIydQTB1SQ7hw2WvI'; // key here
            //Setup curl, add headers and post parameters.
            $ch = curl_init('https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            //curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $notification ) );
            $result = curl_exec($ch);
            curl_close($ch);
            return $result;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    public function GetPublicCompletedQuests($data)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');

        $courseID  = $data->getVar('courseid');
        $studentID = $data->getVar('studentid');
        $questsRaw = Quest::get()->filter(array('IsActive' => 1));
        foreach ($questsRaw as $quest) {

            $unstartedCheck     = false;
            $questGrowIcon      = $quest->getGrowthIconURL();
            $questGrowIconLight = $quest->getGrowthIconLightURL();
            $questGrowTitle     = $quest->getGrowthTitle();
            $questGrowID        = $quest->GrowthCategory()->ID;

            if ($studentQuests = StudentQuest::get()->filter(array('MemberID' => $studentID, 'QuestID' => $quest->ID))) {
                foreach ($studentQuests as $studentQuest) {
                    if ($studentQuest->Status == 'completed') {
                        $unstartedCheck = true;
                    }
                }
            }

            $courses = $quest->AraCourses();

            foreach ($courses as $course) {
                if (($courseID == $course->ID) && $unstartedCheck) {

                    foreach ($studentQuests as $studentQuest) {

                        $studentQuestID = $studentQuest->ID;
                        $taskArray      = array();
                        if ($studentQuest->QuestID == $quest->ID) {
                            if ($studentQuest->StudentTasks()->exists()) {

                                foreach ($studentQuest->StudentTasks() as $studentTask) {

                                    if ($studentTask->Task()->PublicProfileTitle) {
                                        $t = $studentTask->Task()->PublicProfileTitle;
                                    } else {
                                        $t = $studentTask->Task()->Title;
                                    }

                                    if ($task = $quest->Tasks()->filter(array('ID' => $studentTask->TaskID))->first()) {
                                        if ($task->ShowOnPublicProfile) {

                                            $imageURL = null;
                                            if ($task->ClassName == 'TaskImageUpload') {
                                                if ($image = Image::get()->where(array('ID' => $studentTask->FileUpload()->ID))->first()) {
                                                    $imageURL = $image->CroppedImage(400, 270)->AbsoluteLink();
                                                }
                                            }

                                            $taskArray[] = array(
                                                'Title'               => $t,
                                                'PublicProfileTitle'  => $task->PublicProfileTitle,
                                                'ShowOnPublicProfile' => $task->ShowOnPublicProfile,
                                                'ClassName'           => $task->ClassName,
                                                'Value'               => $studentTask->Value,
                                                'Label'               => $studentTask->Label,
                                                'FileID'              => $studentTask->FileUpload()->ID,
                                                'FileName'            => $studentTask->FileUpload()->Name,
                                                'FilePath'            => $studentTask->FileUpload()->AbsoluteLink(),
                                                'ImageURL'            => $imageURL,
                                                'SortOrder'           => $task->SortOrder,
                                            );

                                        }
                                    }
                                }
                            }
                        }
                    }

                    $quests[] = array(
                        'ID'              => $quest->ID,
                        'Title'           => $quest->Title,
                        'PublicTitle'     => $quest->PublicTitle,
                        'PublicSubTitle'  => $quest->PublicSubTitle,
                        'PublicTemplate'  => $quest->PublicTemplate,
                        'Description'     => $quest->Description,
                        'Content'         => utf8_encode($quest->Content),
                        'Date'            => $quest->obj('Date')->Ago(),
                        'GrowthTitle'     => $questGrowTitle,
                        'GrowthIcon'      => $questGrowIcon,
                        'GrowthIconLight' => $questGrowIconLight,
                        'GrowthID'        => $questGrowID,
                        'Colour'          => $quest->GrowthCategory()->Colour,
                        'LightColour'     => $quest->GrowthCategory()->LightColour,
                        'StudentQuestID'  => $studentQuestID,
                        'Tasks'           => $taskArray,
                    );

                }
            }
        }

        echo json_encode($quests);
    }

    public function AllowAllStudentAccess($request)
    {
        if ($group = Group::get()->where(array('code' => 'students'))->first()) {
            if ($group->Members()) {
                foreach ($group->Members() as $student) {
                    $student->AllowOrganizations = 1;
                    $student->write();
                }
            }
        }
    }

    public function StudentIDCheck($request)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        $personId = $request->getVar('studentID');
        try {
            $client = new SOAPClient('http://esb.cpit.ac.nz/PersonInfo_MediationWeb/sca/PersonInfoExport/wsdl/interfaces/PersonInfo_Mediation_PersonInfoExport.wsdl');
            $data   = $client->findPerson(array('personId' => $personId));
            if ($data->findPersonResponse->personId) {
                return 'success';
            } else {
                return 'fail';
            }
        } catch (SOAPFault $e) {
            return 'fail';
        }
    }

    public function init()
    {
        parent::init();

        Requirements::css("{$this->ThemeDir()}/css/styles.css");
        Requirements::css("{$this->ThemeDir()}/css/signup.css");
        Requirements::css("{$this->ThemeDir()}/css/font-awesome.css");
        Requirements::block(THIRDPARTY_DIR . '/jquery/jquery.js');
        Requirements::combine_files(
            'app.js', array(
                THIRDPARTY_DIR . '/jquery/jquery.min.js',
                $this->ThemeDir() . '/js/min/jquery.cycle2.min.js',
                $this->ThemeDir() . '/js/min/plugins.js',
            )
        );

        if (Director::isDev()) {
            Requirements::javascript("{$this->ThemeDir()}/js/application.js");
            Requirements::javascript('http://' . $_SERVER['SERVER_ADDR'] . ':35729/livereload.js'); //gulp watch
        } else {
            Requirements::javascript("{$this->ThemeDir()}/js/min/application.js");
            Requirements::customScript("
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		  ga('create', 'UA-2754445-19', 'auto');
		  ga('require', 'linkid', 'linkid.js');
		  ga('send', 'pageview');
		");
        }
    }

    public function GetStudentPublic($request)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');

        if ($student = Member::get()->filter(array('UID' => $request->param('ID')))->first()) {
            //$st = $student::toJSON;
            $studentJson = array(
                'ID'                => $student->ID,
                'FirstName'         => $student->FirstName,
                'Surname'           => $student->Surname,
                'Email'             => $student->Email,

                'Phone'             => $student->Phone,
                'Misson'            => $student->Misson,
                'Reference'         => $student->Reference,

                'ReferenceName'     => $student->ReferenceName,
                'ReferencePosition' => $student->ReferencePosition,
                'LinkedInURL'       => $student->LinkedInURL,

                'TwitterURL'        => $student->TwitterURL,
                'FacebookURL'       => $student->FacebookURL,
                'PortfolioURL'      => $student->PortfolioURL,

                'BlogURL'           => $student->BlogURL,
                'PersonalityType'   => $student->ReferencePosition,
                'CVID'              => $student->CVID,
            );

            if ($student->Photo()->exists()) {
                $studentJson['PhotoLink']         = $student->Photo()->CroppedImage(256, 256)->getAbsoluteURL();
                $studentJson['PhotoID']           = $student->Photo()->ID;
                $studentJson['PhotoLinkFileName'] = $student->Photo()->Name;
            } else {
                $siteConfig               = SiteConfig::current_site_config();
                $studentJson['PhotoID']   = $siteConfig->DefaultAvatar()->ID;
                $studentJson['PhotoLink'] = $siteConfig->DefaultAvatar()->CroppedImage(320, 320)->getAbsoluteURL();
            }

            if ($student->CV()->exists()) {
                $studentJson['CVFileName'] = $student->CV()->Name;
                $studentJson['CVFileURL']  = $student->CV()->getAbsoluteURL();
            }

            if ($student->AraCourse()->exists()) {
                $studentJson['AraCourseName'] = $student->AraCourse()->Title;
                $studentJson['AraCourseID']   = $student->AraCourse()->ID;
            }

            echo json_encode($studentJson);
        }
    }

    public function GetFooterPages()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if ($footerPages = Page::get()->filter(array('ShowInFooter' => 1))) {
            $footerArray = array();
            foreach ($footerPages as $page) {
                $pageJson = array(
                    'ID'    => $page->ID,
                    'Title' => $page->Title,
                );
                $footerArray[] = $pageJson;
            }
            echo json_encode($footerArray);
        }
    }

    public function GetFooterPage($request)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if ($footerPage = Page::get()->filter(array('ID' => $request->param('ID')))->first()) {

            $pageJson = array(
                'ID'               => $footerPage->ID,
                'Title'            => $footerPage->Title,
                'Content'          => $footerPage->Content,
                'BackgroundColour' => $footerPage->BackgroundColour,
            );

            echo json_encode($pageJson);
        }
    }

    public function getHelpPage()
    {
        return HelpPage::get();
    }

    public function UploadFile($request)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if ($file = $request->postVar('file')) {

            $ranFolderName = $this->generateRandomString();

            $baseFolder = Folder::find_or_make('myGPSUploads');
            $newFolder  = Folder::find_or_make('myGPSUploads/' . $ranFolderName);

            $newfile           = new Image();
            $newfile->ParentID = $newFolder->ID;
            $upload            = new Upload();
            $upload->loadIntoFile($file, $newfile, 'myGPSUploads/' . $ranFolderName);
            $newfile->write();

            echo $newfile->ID;

        } else {
            $error = array(
                'status'  => 'error',
                'message' => 'No file was found',
            );
            echo json_encode($error);
        }
    }

    public function ForgottenPassword($request)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if ($member = Member::get()->filter(array('Email' => $request->getVar('email')))->first()) {

            $member->ForgottenPasswordHash = $this->generateRandomString(8);
            $member->write();

            $email = new Email();
            $email
                ->setFrom('info@mygps.com')
                ->setTo($member->Email)
                ->setSubject('Reset your myGPS password')

                ->setTemplate('ForgottenPassword')
                ->populateTemplate(new ArrayData(array(
                    'Member' => $member,
                )));

            $email->send();

            $response = array(
                'status'  => 'success',
                'message' => 'All good',
            );

        } else {
            $response = array(
                'status'  => 'error',
                'message' => "Sorry, we can't find a member with this email address",
            );

        }

        echo json_encode($response);

    }

    public function ForgottenPasswordCode($request)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if ($member = Member::get()->filter(array('Email' => $request->getVar('email'), 'ForgottenPasswordHash' => $request->getVar('code')))->first()) {
            $response = array(
                'status'  => 'success',
                'message' => 'All good',
            );
        } else {
            $response = array(
                'status'  => 'error',
                'message' => 'Sorry, the code you entered seems to be wrong',
            );
        }

        echo json_encode($response);

    }

    public function ForgottenPasswordReset($request)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if ($member = Member::get()->filter(array('Email' => $request->getVar('email'), 'ForgottenPasswordHash' => $request->getVar('code')))->first()) {
            $member->Password = $request->getVar('password');
            $member->write();
            $response = array(
                'status'  => 'success',
                'message' => 'All good',
            );
        } else {
            $response = array(
                'status'  => 'error',
                'message' => 'Sorry, the code you entered seems to be wrong',
            );
        }

        echo json_encode($response);

    }

    public function generateRandomString($length = 10)
    {
        $characters       = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString     = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function getAraCourses()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        return json_encode(AraCourse::GetList());
    }

    public function createMember($request)
    {

        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if ($objNew = json_decode($request->getBody())) {

            if (property_exists($objNew, 'Email') && property_exists($objNew, 'Surname') && property_exists($objNew, 'FirstName') && property_exists($objNew, 'Password')) {

                $member = Member::get()->filter(array('Email' => $objNew->Email))->first();

                if ($member) {
                    $error = array(
                        'status'  => 'error',
                        'message' => 'This email address is already taken',
                    );
                    echo json_encode($error);
                } else {
                    $member            = new Member();
                    $member->FirstName = $objNew->FirstName;
                    $member->Surname   = $objNew->Surname;
                    $member->Email     = $objNew->Email;
                    $member->Password  = $objNew->Password;

                    if (property_exists($objNew, 'AraCourseID')) {
                        $member->AraCourseID = $objNew->AraCourseID;
                    }

                    if (property_exists($objNew, 'IsStudent')) {
                        $member->IsStudent = $objNew->IsStudent;
                    }

                    if (property_exists($objNew, 'IsTutor')) {
                        $member->IsTutor = $objNew->IsTutor;
                    }
                    if (property_exists($objNew, 'IsOrganization')) {
                        $member->IsOrganization = $objNew->IsOrganization;
                    }

                    // Is Organization
                    if (property_exists($objNew, 'Organization')) {
                        $member->Organization = $objNew->Organization;
                    }
                    if (property_exists($objNew, 'OrganizationSize')) {
                        $member->OrganizationSize = $objNew->OrganizationSize;
                    }

                    if (property_exists($objNew, 'OrganizationJobTitle')) {
                        $member->OrganizationJobTitle = $objNew->OrganizationJobTitle;
                    }

                    if (property_exists($objNew, 'SelectedCourses')) {
                        foreach ($objNew->SelectedCourses as $courseRaw) {
                            $course = AraCourse::get()->filter(array('ID' => $courseRaw->ID))->first();
                            $member->AraCourses()->add($course);
                        }
                    }

                    //Generate a confirm code
                    $confirmCode         = md5(uniqid(rand()));
                    $member->ConfirmCode = $confirmCode;
                    $member->Confirmed   = 0;
                    $member->write();

                    $group = null;

                    if ($member->IsStudent) {
                        $group = Group::get()->filter(array('Code' => 'students'))->first();
                    } else if ($member->IsTutor) {
                        $group = Group::get()->filter(array('Code' => 'tutors'))->first();
                    } else if ($member->IsOrganization) {
                        $group = Group::get()->filter(array('Code' => 'organizations'))->first();
                    }
                    $group->Members()->add($member);

                    if ($course = AraCourse::get()->filter(array('ID' => $member->AraCourseID))->first()) {
                        foreach ($course->Quests() as $quest) {
                            if ($quest->DefaultQuest) {
                                $studentQuest           = new StudentQuest();
                                $studentQuest->Status   = 'started';
                                $studentQuest->MemberID = $member->ID;
                                $studentQuest->QuestID  = $quest->ID;
                                $studentQuest->write();
                            }
                        }
                    }
                    // Send email

                    $from  = 'support@mygps.co.nz';
                    $to    = $member->Email;
                    $sub   = 'Welcome to MyGPS';
                    $email = new Email($from, $to, $sub);
                    $email->setTemplate('MemberConfirm');
                    $email->populateTemplate(new ArrayData(array(
                        'Member'      => $member,
                        'ConfirmCode' => $confirmCode,
                    )));
                    $email->send();

                    /* email */
                    /*
                    $from = "nimeso@gmail.com";
                    $to = $member->Email;
                    $sub = "Welcome to Blippar";
                    $email = new Email($from,$to,$sub);
                    $email->setTemplate("MemberConfirm");
                    $email->populateTemplate(new ArrayData(array(
                    'Member' => $member
                    )));
                    $email->send();
                     */

                    $error = array(
                        'status'  => 'success',
                        'message' => 'All good',
                    );
                    echo json_encode($error);
                }
            } else {
                $error = array(
                    'status'  => 'error',
                    'message' => 'Opps! seems your missing some details',
                );
                echo json_encode($error);
            }

        }

    }
    // Verify the user email when he clicks on the verification link
    public function verifyEmail()
    {
        if (isset($_GET['code'])) {
            $member = Member::get()->filter(array('ConfirmCode' => $_GET['code']))->first();
            if ($member) {
                $member->Confirmed = 1;
                $member->write();
                //$member->logIn();
                /* return $this->customise(new ArrayData(array(
                'Content' => '<h3>Successfully verified the email address.</h3>'
                )))->renderWith(array('Page')); */

                return $this->redirect('https://app.mygps.co.nz/#!/login?verify=success');
            }
        }
        return $this->redirect('https://app.mygps.co.nz/#!/login?verify=fail');
    }
    //Get Confirmed status
    public function getConfirmStatus()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if (isset($_GET['email'])) {
            $member = Member::get()->filter(array('Email' => $_GET['email']))->first();
            if ($member) {
                if ($member->Confirmed == 1) {
                    $error = array(
                        'status'  => 'confirm',
                        'message' => 'Login successfull',
                    );
                    echo json_encode($error);
                }
                if ($member->Confirmed == 0) {
                    $error = array(
                        'status'  => 'unconfirm',
                        'message' => 'The user not confirmed yet!',
                    );
                    echo json_encode($error);
                }
            }
        } else {
            $error = array(
                'status'  => 'unconfirm',
                'message' => 'The user does not exist!',
            );
            echo json_encode($error);
        }
    }

    /*
     * AraLogin()
     * named it this as it this stage this is very specific to the ARA authentication system.
     * In future we may extrapolate this out and allow authentication against multiple tertiary APIs
     * Or more likely have other functions [ i.e. MasseyLogin() ] and control which function gets called based on the email
     * entered by the user from the app side.
     */
    public function AraLogin(SS_HTTPRequest $request)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        //default output
        $response = array(
            'status'  => 'fail',
            'message' => "Whoops! It's seems your username or password are incorrect, please try again.",
        );

        $username = $request->requestVar('user');
        $password = $request->requestVar('pwd');

        if ($username && $password) {

            //-------------------------check the tutors database
            $auth     = new AraStudentAuth('staff');
            $tutor_id = $auth->AuthenticateTutor($username, $password); //temporary method because we have no details endpoint

            if ($tutor_id !== false) {
                //Successful login

                //Is this coming from a conversion login?
                if ($request->requestVar('member_id')) {
                    //Grab the previous MemberID and change fields required to link this to the new ARA account
                    $member = Member::get()->filter(array('ID' => $request->requestVar('member_id')))->first();
                } else {
                    //not a conversion login:

                    //Does tutor ID exist in members table? Grab that record and return along with login token
                    $member = Member::get()->filter(array('TutorID' => $tutor_id))->first();
                }

                if (!$member) {
                    //new user!
                    $course_id = $request->requestVar('course_id');

                    //new student needs to select their study area before we can create their profile
                    if (!$course_id) {
                        $response = array(
                            'status'  => 'newuser',
                            'message' => 'Need a course ID to proceed in new user creation',
                            'courses' => AraCourse::GetList(),
                        );
                    } else {
                        //Tutor ID doesn't exist in Members table? Create a new one!
                        $member = Student::CreateTutor([
                            'FirstName'   => 'Ara',
                            'LastName'    => 'staff',
                            'TutorID'     => $tutor_id,
                            'AraCourseID' => $course_id,
                        ]);
                    }
                }

                //by now we either have a legit member record to log into or we are returning an error or progress response code
                if ($member) {
                    //set up the tokens etc and return
                    $authenticator = new MygpsRESTfulAPI_TokenAuthenticator();
                    $response      = $authenticator->forceMemberLogin($member);
                }

                return json_encode($response);
            }

            //-------------------------IF not a tutor then check against students database

            $auth = new AraStudentAuth('students');

            //first check against the ARA database
            $student = $auth->AuthenticateStudent($username, $password);

            if ($student) {
                //Successful login

                //Is this coming from a conversion login?
                if ($request->requestVar('member_id')) {
                    //Grab the previous MemberID and change fields required to link this to the new ARA account
                    $member = Member::get()->filter(array('ID' => $request->requestVar('member_id')))->first();
                } else {
                    //not a conversion login:

                    //Does student ID exist in members table? Grab that record and return along with login token
                    $member = Member::get()->filter(array('StudentID' => $student->studentID))->first();

                    if (!$member) {
                        //fall back to emails (just in case someone didn't link their old login!)
                        $member = Member::get()->whereAny(array('Email' => $student->personalEmail, 'Email' => $student->institutionEmail))->first();
                    }

                }

                if (!$member) {
                    //new user!
                    $course_id = $request->requestVar('course_id');

                    //new student needs to select their study area before we can create their profile
                    if (!$course_id) {
                        $response = array(
                            'status'  => 'newuser',
                            'message' => 'Need a course ID to proceed in new user creation',
                            'courses' => AraCourse::GetList(),
                        );
                    } else {
                        //Student ID doesn't exist in Members table? Create a new one!
                        $member = Student::CreateStudent([
                            'FirstName'   => $student->firstName,
                            'LastName'    => $student->lastName,
                            'Email'       => $student->institutionEmail,
                            'StudentID'   => $student->studentID,
                            'AraCourseID' => $course_id,
                        ]);
                    }
                }

                //by now we either have a legit member record to log into or we are returning an error or progress response code
                if ($member) {
                    if (AraStudentAuth::SyncMember($member, $student)) {
                        //set up the tokens etc and return
                        $authenticator = new MygpsRESTfulAPI_TokenAuthenticator();
                        $response      = $authenticator->forceMemberLogin($member);
                    } else {
                        $response = array(
                            'status'  => 'fail',
                            'message' => 'A user profile already exists for this ARA account, please contact us to resolve this issue.',
                        );
                    }
                }

            } else {
                //login credentials don't match ARA database

                //Check whether user exists in Members table:
                $member = MemberAuthenticator::authenticate(array(
                    'Email'    => $username,
                    'Password' => $password,
                ));

                if ($member) {
                    //User does exist in Members table and login matches? Return user ID and "conversion login" status
                    $response = array(
                        'status'    => 'conversion',
                        'member_id' => $member->ID,
                        'message'   => 'Needs to match deprecated login!',
                    );
                }
                //User doesn't exist at all? return login fail message by default (set at top of function)
            }
        }

        return json_encode($response);
    }

    //Update user Confirmed status,Note: first time user login is not validated
    public function updateConfirmStatus()
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control');
        header('Access-Control-Allow-Methods: GET, POST, PUT');
        header('Content-Type: application/json');

        if (isset($_GET['email'])) {
            $member = Member::get()->filter(array('Email' => $_GET['email']))->first();
            if ($member && $member->Confirmed == 2) {
                $member->Confirmed = 0;
                $member->write();
            }
        }
        $error = array(
            'status' => 'success',
        );
        echo json_encode($error);
        die();
    }

}
