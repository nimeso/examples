<?php

class HolderPage extends Page {

    public static $db = array(
    );

    public function getCMSFields()  {
        $fields = parent::getCMSFields();

        return $fields;
    }

}

class HolderPage_Controller extends Page_Controller {
    public function init() {
        parent::init();
    }
}
