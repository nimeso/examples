<?php

class HomePage extends Page {

    public static $db = array(
        'IntroText' => 'Varchar(255)'
    );
  /*private static $has_many = [
    'HomePageFeatures' => 'HomePageFeature',
  ];*/

  public function getCMSFields()
  {
    $fields = parent::getCMSFields();

    $fields->addFieldToTab('Root.Main', TextField::create('IntroText'), "Content"); 

    /*$fields->addFieldToTab('Root.Features', GridField::create(
      'HomePageFeatures',
      'Features',
      $this->HomePageFeatures(),
      GridFieldConfig_RecordEditor::create()
        ->addComponent(new GridFieldSortableRows('SortID'))
        ->removeComponentsByType('GridFieldPaginator')
        ->removeComponentsByType('GridFieldPageCount')
    ));*/

    // $fields->removeByName("Content");

    return $fields;
  }

}

class HomePage_Controller extends Page_Controller
{
  public function init()
  {
    parent::init();
  }

  public function GetSortedFeatures()
  {
    return DataObject::get('GrowthCategory');
  }
}


/*class HomePageFeature extends DataObject{

  private static $db = [
    'Title'   => 'Text',
    'Content' => 'Text',
    'SortID'  => 'Int'
  ];

  private static $has_one = [
    'Icon'     => 'Image',
    'HomePage' => 'HomePage',
  ];

  private static $summary_fields = [
    'Icon'    => 'Icon',
    'Title'   => 'Title',
    'Content' => 'Content',
  ];

  public function getCMSFields()
  {
    $fields = FieldList::create(
      TextField::create('Header'),
      TextareaField::create('Content'),
      $uploader = UploadField::create('Icon', 'Icon')
    );

    $uploader->setFolderName('Homepage-Icons');
    $uploader->setAllowedFileCategories('image');

    return $fields;
  }

}*/
