<?php
class SignupPage extends Page
{

}