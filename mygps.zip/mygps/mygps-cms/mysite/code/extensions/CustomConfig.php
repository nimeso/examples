<?php
class CustomConfig extends DataExtension {
	
	private static $db = array(
		"ColourTheme" => "Varchar(128)",
		"AppleStoreLink" => "Varchar(256)",
		"GoogleStoreLink" => "Varchar(256)"
	);
	
	private static $has_one = array(
		"DefaultAvatar" => "Image"
	);
	
	private static $has_many = array(
		
	);
	
	private static $many_many = array(

	);
	
	public function updateCMSFields(FieldList $fields) {
		
		$fields->addFieldsToTab("Root.MyGpsSettings",new UploadField("DefaultAvatar","Default Avatar"));
		$fields->addFieldsToTab("Root.MyGpsSettings",new TextField("AppleStoreLink","Apple Store Link"));
		$fields->addFieldsToTab("Root.MyGpsSettings",new TextField("GoogleStoreLink","Google Store Link"));
		
	}

}
