<?php
class MygpsRESTfulAPI_TokenAuthenticator extends RESTfulAPI_TokenAuthenticator
{

    public function forceMemberLogin($member)
    {

        $response = array();
        if ($member) {
            $tokenData = $this->generateToken();

            $tokenDBColumn  = $this->tokenConfig['DBColumn'];
            $expireDBColumn = $this->tokenConfig['expireDBColumn'];

            $member->{$tokenDBColumn}  = $tokenData['token'];
            $member->{$expireDBColumn} = $tokenData['expire'];
            $member->write();
            $member->logIn();

            $response['status']  = 'success';
            $response['message'] = 'Logged in.';
            $response['code']    = self::AUTH_CODE_LOGGED_IN;
            $response['token']   = $tokenData['token'];
            $response['expire']  = $tokenData['expire'];
            $response['userID']  = $member->ID;

        } else {
            $response['status']  = 'fail';
            $response['message'] = 'Authentication fail.';
            $response['code']    = self::AUTH_CODE_LOGIN_FAIL;
        }

        return $response;
    }

    /**
     * Generates an encrypted random token
     * and an expiry date
     *
     * @param  boolean $expired Set to true to generate an outdated token
     * @return array            token data array('token' => HASH, 'expire' => EXPIRY_DATE)
     */
    private function generateToken($expired = false)
    {
        $life = $this->tokenConfig['life'];

        if (!$expired) {
            $expire = time() + $life;
        } else {
            $expire = time() - ($life * 2);
        }

        $generator   = new RandomGenerator();
        $tokenString = $generator->randomToken();

        $e     = PasswordEncryptor::create_for_algorithm('blowfish'); //blowfish isn't URL safe and maybe too long?
        $salt  = $e->salt($tokenString);
        $token = $e->encrypt($tokenString, $salt);

        return array(
            'token'  => substr($token, 7),
            'expire' => $expire,
        );
    }
}
