<?php
class Student extends DataExtension
{

    private static $db = array(
        'UID'                   => 'Varchar(128)',
        'Phone'                 => 'Varchar(128)',
        'Misson'                => 'Varchar(256)',
        'Reference'             => 'Varchar(512)',
        'ReferenceName'         => 'Varchar(128)',
        'ReferencePosition'     => 'Varchar(128)',
        'LinkedInURL'           => 'Varchar(256)',
        'TwitterURL'            => 'Varchar(256)',
        'FacebookURL'           => 'Varchar(256)',
        'PortfolioURL'          => 'Varchar(256)',
        'BlogURL'               => 'Varchar(256)',
        'PersonalityType'       => 'Varchar(256)',
        'StudentID'             => 'Varchar(128)',
        'TutorID'               => 'Varchar(128)', //a seperate field because ARA didn't get back to my question regarding these being unique compared with student IDs
        'ForgottenPasswordHash' => 'Varchar(8)',
        'FirstTime'             => 'Boolean',
        'ConfirmCode'           => 'Varchar(256)',
        'Confirmed'             => 'Int',
        'IsStudent'             => 'Boolean',
        'IsTutor'               => 'Boolean',
        'IsOrganization'        => 'Boolean',
        'OrganizationSize'      => 'Varchar(256)',
        'Organization'          => 'Varchar(256)',
        'OrganizationJobTitle'  => 'Varchar(256)',
        'AllowOrganizations'    => 'Boolean',
        'AllowPublicProfile'    => 'Boolean',
    );

    private static $has_one = array(
        'Photo'     => 'Image',
        'CV'        => 'File',
        'AraCourse' => 'AraCourse',
    );

    private static $has_many = array(
        'StudentQuests' => 'StudentQuest',
    );

    private static $many_many = array(
        'AraCourses'       => 'AraCourse',
        'FavoriteStudents' => 'Member',
    );

    private static $unique_identifier_field = 'StudentID';

    private static $indexes = array(
        'StudentID' => array('type' => 'unique', 'value' => 'StudentID', 'ignoreNulls' => true),
    );

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();
        return $fields;
    }

    public function getAraCourseTitle()
    {

        if ($course = AraCourse::get()->where(array('ID' => $this->owner->AraCourseID))->exists()) {
            return AraCourse::get()->where(array('ID' => $this->owner->AraCourseID))->first()->Title;
        }

        return 'No course choosen';
    }

    public function getFullName()
    {
        return $this->owner->FirstName . ' ' . $this->owner->Surname;
    }

    public function getEmailAddress()
    {
        return $this->owner->Email;
    }

    public function onBeforeWrite()
    {

        if (!$this->owner->UID) {
            $uid              = $this->owner->generate_uuid();
            $this->owner->UID = $uid;
        }

    }

    public function generate_uuid()
    {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    public function onAfterSerialize(&$formattedDataObjectMap)
    {

        if ($this->owner->Photo()->exists()) {
            $formattedDataObjectMap['PhotoLink'] = $this->owner->Photo()->CroppedImage(256, 256)->getAbsoluteURL();
        } else {
            $siteConfig                          = SiteConfig::current_site_config();
            $formattedDataObjectMap['PhotoLink'] = $siteConfig->DefaultAvatar()->CroppedImage(320, 320)->getAbsoluteURL();
        }

        if ($this->owner->Photo()->exists()) {
            $formattedDataObjectMap['PhotoLinkFileName'] = $this->owner->Photo()->Name;
        }

        if ($this->owner->CV()->exists()) {
            $formattedDataObjectMap['CVFileName'] = $this->owner->CV()->Name;
            $formattedDataObjectMap['CVFileURL']  = $this->owner->CV()->getAbsoluteURL();
        }

        if ($this->owner->AraCourse()->exists()) {
            $formattedDataObjectMap['AraCourseName'] = $this->owner->AraCourse()->Title;
        }

    }

    public static function CreateStudent($student = [])
    {

        /* returns
        (
        [FirstName] => Carl
        [LastName] => Wright
        [Email] => caw482@arastudent.ac.nz
        [StudentID] => 11600683
        [AraCourseID] => 6
        )
         */
        $student = (object) $student;

        if (empty($student->StudentID) || empty($student->FirstName) || empty($student->Email)) {
            //required fields
            return false;
        } else {

            $member = Member::get()->filter(array('StudentID' => $student->StudentID))->first();

            if (!$member) {

                $member = new Member();

                $member->FirstName = $student->FirstName;
                $member->Surname   = $student->LastName;
                $member->Email     = $student->Email;
                //$member->Password    = $student->Password; TODO: check with devart
                $member->IsStudent = 1;
                $member->Confirmed = 1;

                if (isset($student->AraCourseID)) {
                    $member->AraCourseID = $student->AraCourseID;
                }

                $member->write();

                $group = Group::get()->filter(array('Code' => 'students'))->first();
                $group->Members()->add($member);

                if (isset($student->AraCourseID) && $course = AraCourse::get()->filter(array('ID' => $member->AraCourseID))->first()) {

                    foreach ($course->Quests() as $quest) {

                        if ($quest->DefaultQuest) {
                            $studentQuest           = new StudentQuest();
                            $studentQuest->Status   = 'started';
                            $studentQuest->MemberID = $member->ID;
                            $studentQuest->QuestID  = $quest->ID;
                            $studentQuest->write();
                        }

                    }

                }

            }

            return $member;
        }

    }

    public static function CreateTutor($student = [])
    {
        $student = (object) $student;

        if (empty($student->TutorID) || empty($student->FirstName)) {
            //required fields
            return false;
        } else {

            $member = Member::get()->filter(array('TutorID' => $student->TutorID))->first();

            if (!$member) {

                $member = new Member();

                $member->FirstName = $student->FirstName;
                $member->LastName  = $student->LastName;
                $member->TutorID   = $student->TutorID;
                $member->IsStudent = 1;
                $member->IsTutor   = 1;
                $member->Confirmed = 1;

                if (isset($student->AraCourseID)) {
                    $member->AraCourseID = $student->AraCourseID;
                }

                $member->write();

                $group = Group::get()->filter(array('Code' => 'students'))->first();
                $group->Members()->add($member);

                $group = Group::get()->filter(array('Code' => 'tutors'))->first();
                $group->Members()->add($member);

                if (isset($student->AraCourseID) && $course = AraCourse::get()->filter(array('ID' => $member->AraCourseID))->first()) {

                    foreach ($course->Quests() as $quest) {

                        if ($quest->DefaultQuest) {
                            $studentQuest           = new StudentQuest();
                            $studentQuest->Status   = 'started';
                            $studentQuest->MemberID = $member->ID;
                            $studentQuest->QuestID  = $quest->ID;
                            $studentQuest->write();
                        }

                    }

                }

            }

            return $member;
        }

    }

}
