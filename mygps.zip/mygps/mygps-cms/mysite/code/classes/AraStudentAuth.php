<?php

/**
 * Interaction between this app and the ARA student authentication
 */
class AraStudentAuth
{
    private $host;
    private $username;
    private $password;

    public function __construct($endpoint = 'students')
    {
        $this->host     = Config::inst()->get('AraStudentAuth', 'host')[SS_ENVIRONMENT_TYPE] . "$endpoint/";
        $this->username = Config::inst()->get('AraStudentAuth', 'username')[SS_ENVIRONMENT_TYPE];
        $this->password = Config::inst()->get('AraStudentAuth', 'password')[SS_ENVIRONMENT_TYPE];
    }

    public function AuthenticateStudent($username, $password)
    {
        $post = '{"username": "' . $username . '", "password": "' . $password . '"}';
        $url  = $this->host . 'auth';

        $result = $this->make_request($url, $post);

        if ($result->authenticated) {
            return $this->getStudentFromID($result->id);
        } else {
            return false;
        }
    }

    public function AuthenticateTutor($username, $password)
    {
        $post = '{"username": "' . $username . '", "password": "' . $password . '"}';
        $url  = $this->host . 'auth';

        $result = $this->make_request($url, $post);

        if ($result->authenticated) {
            return $result->id; //this is the only difference between this function and AuthenticateStudent as we don't have a tutor endpoint yet to work with
        } else {
            return false;
        }
    }

    public function getStudentFromID($id = false)
    {
        if (empty($id)) {
            return false;
        }

        $url = $this->host . 'mygps/' . $id;

        $student = $this->make_request($url);

        if ($student) {
            $student->studentID = $id;
            return $student;
        }

        return false;
    }

    private function make_request($url, $post = false)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $headers   = array();
        $headers[] = 'Authorization: Basic ' . base64_encode($this->username . ':' . $this->password);
        $headers[] = 'Accept: application/json';
        $headers[] = 'Content-Type: application/json';

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        if ($post) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }

        $result = curl_exec($ch);

        if (curl_errno($ch)) {
            return false;
        }

        curl_close($ch);

        return json_decode($result);
    }

    public static function SyncMember($member, $student)
    {
        //ensure data is consistent with ARA
        $member->StudentID = $student->studentID;
        if (empty($member->FirstName)) {
            $member->FirstName = $student->firstName;
            $member->Surname   = $student->lastName;
        }
        $member->Email     = $student->institutionEmail;
        $member->Password  = null; //remove for security
        $member->Confirmed = 1;

        try {
            $member->write();
        } catch (Exception $e) {
            return false;
        }

        return true;
    }
}
