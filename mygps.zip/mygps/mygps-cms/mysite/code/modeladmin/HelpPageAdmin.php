<?php
class HelpPageAdmin extends ModelAdmin{

	private static $menu_title = "Help Pages";
	private static $url_segment = "help-pages";
	private static $menu_priority = 3;

	private static $managed_models = array(
		'HelpPage'
	);

}