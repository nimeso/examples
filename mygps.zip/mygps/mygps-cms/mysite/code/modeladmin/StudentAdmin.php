<?php
class StudentAdmin extends ModelAdmin{

	private static $menu_title = "Students";
	private static $url_segment = "students";
	private static $menu_priority = 2;

	private static $managed_models = array(
		'Member'
	);
	
	public function getList() {
        $list = parent::getList();
		$list = Member::get()->where( array("IsStudent" => 1) );
        return $list;
    }

}