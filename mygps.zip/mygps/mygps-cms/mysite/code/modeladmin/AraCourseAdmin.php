<?php
class AraCourseAdmin extends ModelAdmin{

	private static $menu_title = "Ara Courses";
	private static $url_segment = "AraCourses";
	private static $menu_priority = 3;

	private static $managed_models = array(
		'AraCourse'
	);

}