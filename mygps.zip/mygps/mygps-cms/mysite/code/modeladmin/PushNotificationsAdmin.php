<?php

class PushNotificationsAdmin extends LeftAndMain {
	private static $menu_title = "Push Notifications";
	private static $url_segment = "PushNotifications";
	private static $menu_priority = 3;

    public function getEditForm($id = null, $fields = null){

		$EditForm = parent::getEditForm($id, $fields);

		$EditForm->Fields()->add(LiteralField::create('AsfunD', '
		<div id="Root_Main" class="tab  ui-tabs-panel ui-corner-bottom" aria-labelledby="ui-id-7" role="tabpanel" aria-expanded="true" aria-hidden="false">
			<p id="Form_ItemEditForm_error" class="message" style="width:97%;display:none;">aa</p>

			<div id="Form_ItemEditForm_Title_Holder" class="field text">
				<label class="left" for="pn_title">Title</label>
				<div class="middleColumn">
					<input required type="text" name="pn_title" id="pn_title" class="text" placeholder="Notification Title" value="MyGPS Notification">
				</div>
			</div>

			<div id="Form_ItemEditForm_Title_Holder" class="field text">
				<label class="left" for="pn_message">Message</label>
				<div class="middleColumn">
					<textarea required name="pn_message" id="pn_message" cols="30" rows="10" placeholder="Write you message"></textarea>
				</div>
			</div>

			<div id="Form_ItemEditForm_Title_Holder" class="field text">
				<label class="left" for="pn_send">&nbsp;</label>
				<div class="middleColumn">
					<button onClick="func_pn_send();" id="pn_send" name="pn_send" class="action ss-ui-action-constructive ss-ui-button ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-primary">Send</button>
				</div>
			</div>
		</div>

		<style>
			.cms-content-actions{
				border:0px solid #fff !important;
			}
			.cms-edit-form, .cms-content-header{
				width:100% !important;
			}
			.cms-content-fields{
				padding-top:12px !important;
			}
		</style>
		<script>
			function func_pn_send(){
				if(confirm("Are you sure you want to perform this action?") === true){
					var title = document.getElementById("pn_title").value;
					var message = document.getElementById("pn_message").value;
					if(message !== ""){
						send_message_api(message, title);
					} else {
						alert("Please enter message to send.");
					}
				}
			}

			function send_message_api(message, title) {
				var send_btn = document.getElementById("pn_send");
				send_btn.style.display = "none";
				var notice_div = document.getElementById("Form_ItemEditForm_error");
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						var res = JSON.parse(this.responseText);
						send_btn.style.display = "block";
						notice_div.style.display = "block";
						if(res == 1){
							notice_div.classList.remove("bad");
							notice_div.classList.add("good");
							notice_div.innerHTML = "Notification has been sent successfully to all users.";
						} else {
							notice_div.classList.remove("good");
							notice_div.classList.add("bad");
							notice_div.innerHTML = "Opps!! Something went wrong. Please try again later.";
						}
					}
				};
				var baseUrl = window.location.origin; // for live
				//var getUrl = window.location; // for local
				//var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split(\'/\')[1]; // for local
				xhttp.open("GET", baseUrl+"/home/SendNotificationToAll?msg="+message+"&title="+title, true);
				xhttp.send();
			}
		</script>
		'));
		return $EditForm;
	}
}
?>
