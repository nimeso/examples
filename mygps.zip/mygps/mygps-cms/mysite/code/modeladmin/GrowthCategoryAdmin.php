<?php
class GrowthCategoryAdmin extends ModelAdmin{

	private static $menu_title = "Focus Areas";
	private static $url_segment = "focusareas";
	private static $menu_priority = 3;

	private static $managed_models = array(
		'GrowthCategory'
	);

}