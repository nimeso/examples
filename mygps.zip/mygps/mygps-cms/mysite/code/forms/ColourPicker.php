<?php
class ColourPicker extends TextField {
	/**
	 * {@inheritdoc}
	 */
	public function Type() {
		return 'colour picker';
	}

	/**
	 * {@inheritdoc}
	 */
	public function getAttributes() {
		return array_merge(
			parent::getAttributes(),
			array(
				'type' => 'color',
			)
		);
	}
}