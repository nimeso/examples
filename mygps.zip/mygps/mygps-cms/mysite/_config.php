<?php

global $project;
$project = 'mysite';


global $databaseConfig;
$databaseConfig = array(
	'type' => 'MySQLDatabase',
	'server' => 'localhost',
	'username' => 'mygps',
	'password' => 'mygps',
	'database' => 'mygps',
	'path' => ''
);


Security::setDefaultAdmin("nimeso","nimeso");
Director::set_environment_type("dev");

Email::setAdminEmail('aaron@devart.nz');
Email::bcc_all_emails_to('aaron@devart.nz');

HtmlEditorConfig::get('cms')->setOption('content_css', project() . '/editor.css');

Config::inst()->update('Director', 'rules', ['api' => 'MygpsRESTfulAPI']);

// Set the site locale
i18n::set_locale('en_NZ');



//require_once 'conf/ConfigureFromEnv.php';
