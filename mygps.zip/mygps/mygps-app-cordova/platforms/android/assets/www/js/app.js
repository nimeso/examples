'use strict';

/* App Module */

var env = {};
// Import variables if present (from env.js)
if(window){
  Object.assign(env, window.mygps_env);
}

var mygps = angular.module('mygps', [
  'ngRoute',
  'mygpsControllers',
  'ngAnimate',
  'ngMessages',
  'ui.bootstrap',
  'ngFileUpload',
  'ngTouch'
]);


mygps.value('baseURL', env.baseURL);
mygps.value('assetsURL', env.assetsURL);
mygps.value('openApiPageName', env.openApiPageName);


mygps.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.when('/login', {
        templateUrl: 'templates/login.html',
        controller:  'Login_Controller'
      })
      .when('/profile', {
        templateUrl: 'templates/profile.html',
        controller:  'Profile_Controller'
      })
      .when('/edit-profile', {
        templateUrl: 'templates/profile.html',
        controller:  'Profile_Controller'
      })
      .when('/my-profile', {
        templateUrl: 'templates/my-profile.html',
        controller:  'MyProfile_Controller'
      })
      .when('/sign-up', {
        templateUrl: 'templates/register.html',
        controller:  'Register_Controller'
      })
      .when('/dashboard', {
        templateUrl: 'templates/dashboard.html',
        controller:  'Dashboard_Controller'
      })
      .when('/dashboard/:tab', {
        templateUrl: 'templates/dashboard.html',
        controller:  'Dashboard_Controller'
      })
      .when('/quest-details/:ID', {
        templateUrl: 'templates/quest-details.html',
        action:      "edit",
        controller:  'QuestDetails_Controller'
      })
      .when('/quest-details/:ID', {
        templateUrl: 'templates/quest-details.html',
        action:      "edit",
        controller:  'QuestDetails_Controller'
      })
      .when('/new-quest/:ID', {
        templateUrl: 'templates/new-quest-details.html',
        action:      "create",
        controller:  'QuestDetails_Controller'
      })
      .when('/completed/:ID', {
        templateUrl: 'templates/completed.html',
        controller:  'Completed_Controller'
      })
      .when('/completed-tips/:ID', {
        templateUrl: 'templates/completed-tips.html',
        controller:  'CompletedTips_Controller'
      })
      .when('/home', {
        templateUrl: 'templates/home.html',
        controller:  'Home_Controller'
      })
      .when('/help', {
        templateUrl: 'templates/help.html',
        controller:  'Help_Controller'
      })
      .when('/forgotten-password', {
        templateUrl: 'templates/forgotten-password.html',
        controller:  'ForgottenPassword_Controller'
      })
      .when('/forgotten-password-code', {
        templateUrl: 'templates/forgotten-password-code.html',
        controller:  'ForgottenPasswordCode_Controller'
      })
      .when('/forgotten-password-reset', {
        templateUrl: 'templates/forgotten-password-reset.html',
        controller:  'ForgottenPasswordReset_Controller'
      })
      .when('/footer-page/:ID', {
        templateUrl: 'templates/footer-page.html',
        controller:  'FooterPage_Controller'
      })
      .when('/public-profile/:UID', {
        templateUrl: 'templates/public-profile.html',
        controller:  'PublicProfile_Controller'
      })
      .otherwise({
        redirectTo: '/login'
      });
  }
]);