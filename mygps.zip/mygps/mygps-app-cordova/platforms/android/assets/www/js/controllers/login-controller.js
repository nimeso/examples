mygpsControllers.controller('Login_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI, loginService) {

	$scope.loginError = false;
	$scope.loggingIn = true;

	// show back button
	$scope.$parent.showBackButton("#!/home");
	
	var verify = $location.search().verify;
	
	if(verify == 'success')
		$scope.message = 'Successfully verified email address.';
	
	if(verify == 'fail')
		$scope.message = 'Could not verify email address,please try again.';

	$scope.login = function(isVaild){

		$scope.loginError = false;
		$scope.loggingIn = true;

		loginService.login($scope.loginForm.Email,$scope.loginForm.Password,function(result){
			console.log("login");
			console.log(result);
			if(result.status == 'unconfirm'){
				$scope.$parent.isLoggedIn = false;
				$scope.loginError = "Whoops! It's seems your email is not verified yet.";
				$scope.loggingIn = false;
			}else if(!result.result){
				$scope.$parent.isLoggedIn = false;
				$scope.loginError = "Whoops! It's seems your email or password are incorrect, please try again.";
				$scope.loggingIn = false;
			}else{
				console.log("good login");
				 mygpsAPI.getObjects("Member/"+result.userID).then(function(data){
					 $scope.$parent.student = data;
					 $scope.$parent.isLoggedIn = true;
					 $location.path('/dashboard');
				 });
			}
		});

	}

});


mygps.factory('loginService', function(mygpsAPI) {
    return {
        login: function(email,pwd,callback) {

        	console.log("email = "+email);
        	console.log("pass = "+pwd);
        	
        	mygpsAPI.loginPre(email,callback).then(function(datapre){
        	
        		var resultpre = datapre.data;
        		
        		if(resultpre.status == 'confirm'){
        	
        			mygpsAPI.login(email,pwd,callback).then(function(data){
        			
        				console.log(data);
        			
        				var result = data.data;
        				if(!result.result){
        					console.log("BAD LOGIN");
        					window.localStorage.removeItem("mygpsStudentToken");
        					window.localStorage.removeItem("mygpsStudentID");
        				}else{
        					console.log(result);
        					window.localStorage.setItem("mygpsStudentToken", result.token);
        					window.localStorage.setItem("mygpsStudentID", result.userID);
        				}

        				callback(result);

        			});
        		}else{

        			callback(resultpre);
        		
        		}
        	
           });

        }
    };
});