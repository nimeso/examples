mygpsControllers.controller('ForgottenPasswordCode_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI, forgotPasswordCodeService) {
	
	console.log($scope.$parent.studentEmail);
	
	$scope.forgotPasswordCode = function(isVaild){

		forgotPasswordCodeService.forgotPasswordCode($scope.$parent.studentEmail, $scope.forgotPasswordCodeForm.Code, function(result){
			
			if(result == "fail"){
				$scope.failed = true;
			}else{
				$scope.$parent.studentCode = $scope.forgotPasswordCodeForm.Code;
				$location.path("/forgotten-password-reset");
			}
			
		});
		
	}
	
});

mygps.factory('forgotPasswordCodeService', function(mygpsAPI) {
    return {
    	forgotPasswordCode: function(email, code, callback) {
    		
    		mygpsAPI.forgottenPasswordCode(email, code, callback).then(function(data){
    			
    			console.log(data);
    			
    			var result = "";
    			if(data.data.status == "success"){
    				result = "success";
    			}else{
    				result = "fail";
    			}
    			callback(result);
    			
    		});
    		
        }
    };
});