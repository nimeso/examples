mygpsControllers.controller('Home_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI) {
	// hide back button 
	$scope.$parent.hideBackButton();
});