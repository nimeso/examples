mygps.factory('mygpsAPI', function($http, baseURL, assetsURL, openApiPageName) {

	var requests = [];

	return{
		//variables & strings
		baseURL:assetsURL,
		assetsURL:assetsURL,

		loginPre:loginPre,
		login:login,
		updateConfirmStatus:updateConfirmStatus,
		logout:logout,
		forgottenPassword:forgottenPassword,
		forgottenPasswordCode:forgottenPasswordCode,
		forgottenPasswordReset:forgottenPasswordReset,

		isDataLoading:isDataLoading,


		getFile:getFile,
		updateFile:updateFile,

		updateMember:updateMember,
		createMember:createMember,

		getObjects:getObjects,
		getCourses:getCourses,
		getQuests:getQuests,
		getSingleStudentQuest:getSingleStudentQuest,
		getCompletedQuests:getCompletedQuests,
		getQuestsYourDoing:getQuestsYourDoing,
		getQuestsUnstarted:getQuestsUnstarted,
		createObject:createObject,
		deleteObject:deleteObject,

		deleteAllStudentTasks:deleteAllStudentTasks,
		getTotalGrowthCategoryQuestsByAraCourse:getTotalGrowthCategoryQuestsByAraCourse,
		getDoneGrowthCategoryQuestsByAraCourse:getDoneGrowthCategoryQuestsByAraCourse,

		getCompletedQuestsByGrowthCategory:getCompletedQuestsByGrowthCategory,

		codeCheck:codeCheck,

		getFooterPages:getFooterPages,
		getFooterPage:getFooterPage,

		getPublicStudent:getPublicStudent,
		checkStudentID: checkStudentID
	}

	function checkStudentID(id){

		requests.push('task');
		return $http({
			'url': assetsURL+openApiPageName+'/StudentIDCheck?studentID='+id,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function getFooterPages(){
		requests.push('task');
		return $http({
			'url': assetsURL+openApiPageName+'/GetFooterPages',
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function getFooterPage(ID){
		requests.push('task');
		return $http({
			'url': assetsURL+openApiPageName+'/GetFooterPage/'+ID,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function getPublicStudent(uid){
		requests.push('task');
		return $http({
			'url': assetsURL+openApiPageName+'/GetStudentPublic/'+uid,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function codeCheck(userCode,taskID){

		var url = baseURL+"CodeCheck?Code="+userCode+"&TaskID="+taskID;

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function getCompletedQuestsByGrowthCategory(growthCategoryID){

		var url = baseURL+"GetCompletedQuestsByGrowthCategory?GrowthCategory="+growthCategoryID+"&StudentID="+window.localStorage.getItem("mygpsStudentID");

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);

	}

	function getDoneGrowthCategoryQuestsByAraCourse(courseID){

		var url = baseURL+"GetDoneGrowthCategoryQuestsByAraCourse?GrowthCategory="+courseID+"&StudentID="+window.localStorage.getItem("mygpsStudentID");

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function getTotalGrowthCategoryQuestsByAraCourse(courseID){

		var url = baseURL+"GetTotalGrowthCategoryQuestsByAraCourse?GrowthCategory="+courseID+"&StudentID="+window.localStorage.getItem("mygpsStudentID");



		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	}

	function getQuests(studentCourseID,studentID){

		var url = baseURL+"GetQuests?courseid="+studentCourseID+"&studentid="+studentID;

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function getCompletedQuests(studentCourseID,studentID){

		var url = baseURL+"GetCompletedQuests?courseid="+studentCourseID+"&studentid="+studentID;

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function getQuestsUnstarted(studentCourseID,studentID){

		var url = baseURL+"GetQuestsUnstarted?courseid="+studentCourseID+"&studentid="+studentID;

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function getSingleStudentQuest(StudentQuestID){
		var url = baseURL+"GetFullStudentQuest?id="+StudentQuestID;

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function getQuestsYourDoing(studentCourseID,studentID){

		var url = baseURL+"GetQuestsYourDoing?courseid="+studentCourseID+"&studentid="+studentID;

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function deleteAllStudentTasks(questID){

		var url = baseURL+"DeleteAllStudentTasks?StudentQuestID="+questID;

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function getObjects(className,query){

		if(query){
			var url = baseURL+className+query;
		}else{
			var url = baseURL+className;
		}

		requests.push('task');
		return $http({
			'url': url,
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	if(member.ID){
		var method = "PUT";
		var url = baseURL+'Member/'+window.localStorage.getItem("mygpsStudentID")
	}else{
		method = "POST";
		url = baseURL+'Member/';
	}

	function createObject(className,object,objectID){

		if(objectID){
			method = "PUT";
			url = baseURL+className+"/"+objectID;
		}else{
			method = "POST";
			url = baseURL+className;
		}

		requests.push('task');
		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(object),
	        'headers': {
			     'Content-Type': 'application/json',
		        'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);



	}

	function deleteObject(className,object,objectID){

		method = "DELETE";
		url = baseURL+className+"/"+objectID;

		requests.push('task');
		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(object),
	        'headers': {
			     'Content-Type': 'application/json',
		        'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);



	}

	function getCourses(){

		requests.push('task');
		return $http({
			'url': assetsURL+openApiPageName+"/getAraCourses",
			'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}
	
	
	function loginPre(email){
		requests.push('task');
		
		return $http({
			'url': assetsURL+openApiPageName+'/getConfirmStatus?email='+email,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			//alert(response.status);
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}
	
	function login(email,pwd){
		requests.push('task');
		return $http({
			'url': baseURL+'auth/login?email='+email+'&pwd='+pwd,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			//updateConfirmStatus();
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}
	
	function updateConfirmStatus(email){
		return $http({
			'url': assetsURL+openApiPageName+'/updateConfirmStatus?email='+email,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function logout(email){

		if(window.localStorage.getItem("mygpsStudentToken") && window.localStorage.getItem("mygpsStudentID")){
			requests.push('task');
			return $http({
				'url': baseURL+'auth/logout?email='+email,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function forgottenPassword(email){
		requests.push('task');
		return $http({
			'url': assetsURL+openApiPageName+'/ForgottenPassword?email='+email,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function forgottenPasswordCode(email,code){
		requests.push('task');
		return $http({
			'url': assetsURL+openApiPageName+'/ForgottenPasswordCode?email='+email+"&code="+code,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function forgottenPasswordReset(email,code,password){
		requests.push('task');
		return $http({
			'url': assetsURL+openApiPageName+'/ForgottenPasswordReset?email='+email+"&code="+code+"&password="+password,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
			subRequest();
			return response; //in data requests we return response.data so have to do this seperately.
		}
	}

	function getFile(id){
		requests.push('task');
		return $http({
			'url': baseURL+'File/'+id,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	}

	function updateFile(file){
		requests.push('task');
		return $http({
			'url': baseURL+'File/'+file.ID,
	        'method': 'PUT',
	        'data': JSON.stringify(file),
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
	        }
    	}).then(getDataComplete).catch(getDataFailed);


	}

	function updateMember(member){

		if(window.localStorage.getItem("mygpsStudentToken") && window.localStorage.getItem("mygpsStudentID")){

			if(member.ID){
				var method = "PUT";
				var url = baseURL+'Member/'+window.localStorage.getItem("mygpsStudentID")
			}else{
				method = "POST";
				url = baseURL+'Member/';
			}

			requests.push('task');
			return $http({
				'url': url,
		        'method': method,
		        'data': JSON.stringify(member),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': window.localStorage.getItem("mygpsStudentToken")
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	}

	function createMember(member){

		method = "POST";
		url = assetsURL+openApiPageName+'/createMember?token=gyyy28875yrfFGHns435';

		requests.push('task');
		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(member),
	        'headers': {
			      'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);



	}

	function getDataComplete(response) {
		subRequest();
	    return response.data;
	}

	function getDataFailed(error) {
		subRequest();
	    // mygpsErrorHandler.error('XHR Failed for getAppData.' + error.data); this isn't working
	}

	function subRequest() {
		requests.pop();
		if (requests.length == 0) {
		}
	}

	function isDataLoading() {
		return (requests.length > 0);
	}

});

angular.module('app.core.mygpsErrorHandler', [
	'mygps'
])

//Just console log for now, later we can add more functionality to communicate with unity, analytics etc.
.factory('mygpsErrorHandler', function(){
	return{
		error: function(msg,error){
			console.log(msg);
			console.log(error);
		}
	}
})