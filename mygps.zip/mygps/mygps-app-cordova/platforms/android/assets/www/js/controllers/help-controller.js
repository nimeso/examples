mygpsControllers.controller('Help_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI) {
	// hide back button
	$scope.$parent.hideBackButton();

	// help screens
	$scope.active = 0;
	$scope.myInterval = 0;
	$scope.noWrapSlides = true;
	var slides = $scope.slides = [];

	mygpsAPI.getObjects("HelpPage").then( function(data){
		var counter = 0;
		$.each(data,function(){
			this.ID = counter++; //carousel fails if index doesn't start from 0
			this.active = false;
			slides.push(this);
		});
	$scope.$watch('active', function (active) {
		if (active == (slides.length - 1)) {
			//use has gone to the last slide
			$('.carousel-indicators').fadeOut(800);
			$timeout(function(){
				$('a.help-gohome').fadeIn(800);
			},800);

		}
	  });


	});

});