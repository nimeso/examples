'use strict';

/* Controllers */
var mygpsControllers = angular.module('mygpsControllers', []);
