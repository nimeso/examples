mygpsControllers.controller('Dashboard_Controller', function($scope, $location, $timeout, $routeParams, $log, $window, $http, $sce, baseURL, assetsURL, mygpsAPI) {

	
	/* url string check */
	
	 $scope.learnRegExp = function(s) {    
	      var regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
	      return regexp.test(s);    
	 }
	
	$scope.URLilify = function(str){
		var rstr = "";
		if($scope.learnRegExp(str)){
			console.log("IS A URL");
			rstr = "<a href='"+str+"' target='_blank'>"+str+"</a>";
		}else{
			console.log("IS NOT URL");
			rstr = str;
		}
		return $sce.trustAsHtml(rstr);
	}
	
	
	$scope.excludeFilters = [];

	$scope.filterAddList = function(data,course,$event){
		var filter = $($event.currentTarget);
		var location = $scope.excludeFilters.indexOf(data)
		if (location !== -1) {
			//item is already 'active'
			filter
				.find('span').css({
					'background-color':course.LightColour
				})
				.find('img').attr('src',course.IconLight);

			$scope.excludeFilters.splice(location,1);
		} else {
			//category not active, so select it
			filter
				.find('span').css({
					'background-color':'white'
				})
				.find('img').attr('src',course.Icon);

			$scope.excludeFilters.push(data);
			// $scope.addFilterActive = course;
			// $scope.addFilter = data;
		}
	};
	
	$scope.orderList = function(data,course,$event){
		console.log(course.Title);
		var newList = [];
		for(var t=0; t<$scope.questsUnstarted.length; t++ ){
			console.log($scope.questsUnstarted[t]);
			if(course.Title == $scope.questsUnstarted[t].GrowthTitle){
				newList.push($scope.questsUnstarted[t]);
			}
		}
		for(t=0; t<$scope.questsUnstarted.length; t++ ){
			console.log($scope.questsUnstarted[t]);
			if(course.Title != $scope.questsUnstarted[t].GrowthTitle){
				newList.push($scope.questsUnstarted[t]);
			}
		}
		$scope.questsUnstarted = newList;
	}

	$scope.filterGrowthCatsID = null;
	$scope.filterGrowthCats = function(catID){
		$scope.filterGrowthCatsID = catID;
	}
	
	$scope.hideGrowthCatPanel = function(){
		console.log("raaaaa");
		$scope.filterGrowthCatsID = null;
	}

	// hide back button
	$scope.$parent.hideBackButton();

	// tabs
	$scope.showQuests = true;
	$scope.showProgess = false;
	$scope.showReport = false;
	$scope.showAddQuests = false;

	$scope.getQuestsActiveClass = "active";
	$scope.getProgressActiveClass = "";
	$scope.getReportActiveClass = "";
	$scope.getAddQuestsActiveClass = "";

	$(window).resize(function(){
		$scope.$apply(function(){
			 if(window.innerWidth > 970){
		    	$scope.showProgess = false;
				$scope.showQuests = true;
				$scope.showReport = false;
				$scope.showAddQuests = false;

				$scope.getQuestsActiveClass = "";
				$scope.getProgressActiveClass = "active";
				$scope.getReportActiveClass = "";
				$scope.getAddQuestsActiveClass = "";

		    }else{
		    	$scope.showProgess = false;
				$scope.showQuests = true;
				$scope.showReport = false;
				$scope.showAddQuests = false;

				$scope.getQuestsActiveClass = "active";
				$scope.getProgressActiveClass = "";
				$scope.getReportActiveClass = "";
				$scope.getAddQuestsActiveClass = "";
		    }
		});
	});

	$scope.showQuestsTab = function(){
		$scope.showProgess = false;
		$scope.showQuests = true;
		$scope.showReport = false;
		$scope.showAddQuests = false;

		$scope.getQuestsActiveClass = "active";
		$scope.getProgressActiveClass = "";
		$scope.getReportActiveClass = "";
		$scope.getAddQuestsActiveClass = "";
	};

	$scope.showProgressTab = function(){
		$scope.showProgess = true;
		$scope.showQuests = false;
		$scope.showReport = false;
		$scope.showAddQuests = false;

		$scope.getQuestsActiveClass = "";
		$scope.getProgressActiveClass = "active";
		$scope.getReportActiveClass = "";
		$scope.getAddQuestsActiveClass = "";
	};

	$scope.showReportTab = function(){
		$scope.showProgess = false;
		$scope.showQuests = false;
		$scope.showReport = true;
		$scope.showAddQuests = false;

		$scope.getQuestsActiveClass = "";
		$scope.getProgressActiveClass = "";
		$scope.getReportActiveClass = "active";
		$scope.getAddQuestsActiveClass = "";
	};

	$scope.showAddQuestsTab = function(){
		$scope.showProgess = false;
		$scope.showQuests = false;
		$scope.showReport = false;
		$scope.showAddQuests = true;

		$scope.getQuestsActiveClass = "";
		$scope.getProgressActiveClass = "";
		$scope.getReportActiveClass = "";
		$scope.getAddQuestsActiveClass = "active";
	};

	var tab = $routeParams.tab;
	if(tab == "myprofile"){
		$timeout($scope.showReportTab, 500);
	}

	var tab = $routeParams.tab;
	if(tab == "addquest"){
		$timeout($scope.showAddQuestsTab, 500);
	}

	$scope.courses = [];
	$scope.growthCatTotalQuests = [];
	$scope.growthCatTotalDoneQuests = [];

	mygpsAPI.getObjects("GrowthCategory",null).then(function(data){

		$scope.courses = data;


		for(var i=0; i<$scope.courses.length; i++){
			mygpsAPI.getTotalGrowthCategoryQuestsByAraCourse($scope.courses[i].ID).then(function(data){

				var growthTotal = {
					"GrowthCategoryID": data.GrowthCategoryID,
					"Value": data.Value
				};
				$scope.growthCatTotalQuests.push(growthTotal);
			});

			mygpsAPI.getCompletedQuestsByGrowthCategory($scope.courses[i].ID).then(function(data){

				var doneTotal = {
					"GrowthCategoryID": data.GrowthCategoryID,
					"Value": data.Value
				};
				$scope.growthCatTotalDoneQuests.push(doneTotal);
			});
		};

	});

	$scope.getQuestsDoneByGrowthCat = function(growthCategoryID){
		var completed = [];
		for(var t=0; t<$scope.growthCatTotalDoneQuests.length; t++ ){
			if($scope.growthCatTotalDoneQuests[t].GrowthCategoryID == growthCategoryID){
				return $scope.growthCatTotalDoneQuests[t].Value;
			}
		}

	}


	$scope.getTotalQuests = function(growthCategoryID){
		for(var i=0; i<$scope.growthCatTotalQuests.length; i++){
			if($scope.growthCatTotalQuests[i].GrowthCategoryID == growthCategoryID){
				return $scope.growthCatTotalQuests[i].Value;
			}
		}
	}

	$scope.quests = [];
	$scope.questsUnstarted = [];
	$scope.yourQuests = [];
	$scope.completedQuests = [];

	//mygpsAPI.getQuests($scope.$parent.student).

	$scope.$parent.$watch('student', function(){
		if (!$scope.student.ID) { //no undefined ajax calls
			return;
		}
		mygpsAPI.getQuests($scope.student.AraCourse,$scope.student.ID).then(function(data){
			$scope.quests = data;
		});
		mygpsAPI.getCompletedQuests($scope.student.AraCourse,$scope.student.ID).then(function(data){
			console.log("completed quests");
			console.log(data);
			$scope.completedQuests = data;
		});
		mygpsAPI.getQuestsUnstarted($scope.student.AraCourse,$scope.student.ID).then(function(data){
			$scope.questsUnstarted = data;
		});
		mygpsAPI.getQuestsYourDoing($scope.student.AraCourse,$scope.student.ID).then(function(data){
			$scope.yourQuests = data;
		});
	}, true);
	
	$scope.showHideEvidence = function(quest){
		console.log(quest);
		if(quest.active){
			quest.active = false;
		}else{
			quest.active = true;
		}
	}



});