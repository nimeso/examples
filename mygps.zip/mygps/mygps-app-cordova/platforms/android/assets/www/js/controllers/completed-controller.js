mygpsControllers.controller('Completed_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI) {

	// hide back button
	$scope.$parent.showBackButton("#!/dashboard");
	$scope.quest = {};

	mygpsAPI.getObjects("Quest","/"+$routeParams.ID).then(function(data){
		$scope.quest = data;
		$scope.tasks = $scope.quest.Tasks;

		mygpsAPI.getObjects("Quest","/"+$scope.quest.ID).then(function(data){
			$scope.quest = data;
			mygpsAPI.getObjects("GrowthCategory","/"+$scope.quest.GrowthCategory).then( function(data){
				$scope.growthCat = data;
			});
		});

	});

});