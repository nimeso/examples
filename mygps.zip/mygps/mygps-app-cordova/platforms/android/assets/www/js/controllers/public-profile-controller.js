mygpsControllers.controller('PublicProfile_Controller', function($window, $scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI, Upload) {
	
	mygpsAPI.getPublicStudent($routeParams.UID).
		then(function(data){
			console.log("good profile page");
			console.log(data.data);
			
			$scope.publicStudent = data.data;
		})
		.catch(function(data){
			console.log("bad profile page");
		});
	
});