'use strict';

angular.module('mygps')
.controller('mainController', [
	'$attrs', '$scope', '$routeParams', '$window', '$location', '$templateCache', '$timeout', '$sce', '$http', 'mygpsAPI',
	function($attrs, $scope, $routeParams, $window, $location, $templateCache, $timeout, $sce, $http, mygpsAPI) {

		$scope.pageName = "";

		$scope.isLoggedIn = false;
		$scope.isLoading = true;
		$scope.student = [];

		$scope.isDataLoading = mygpsAPI.isDataLoading;

		$scope.footerPages;
		//$scope.isDataLoading = true;

		mygpsAPI.getFooterPages().
			then(function(data){
				$scope.footerPages = data.data;
			})
			.catch(function(data){
			});

		$scope.$on('$routeChangeSuccess', function(e, current, pre) {
			var split = $location.path().split("/");
		    $scope.pageName = split[1];
		});

		/* set student first time */
		$scope.setStudentFirstTime = function(){
			$scope.student.FirstTime = 1;
			var data = {
				"FirstTime": 1	
			}
			mygpsAPI.createObject("Member",data,$scope.student.ID);
		}

		if( window.localStorage.getItem("mygpsStudentToken") && window.localStorage.getItem("mygpsStudentID") ){


			var token = window.localStorage.getItem("mygpsStudentToken");
			var id = window.localStorage.getItem("mygpsStudentID");

		    mygpsAPI.getObjects("Member","/"+id).
				then(function(data){

					if(data.code == 2){
						$location.path('/login');
						$scope.isLoading = false;
					}

					$scope.student = data;
					$scope.isLoggedIn = true;
					$scope.isLoading = false;

					var split = $location.path().split("/");
				    var pageName = split[1];

				    if(pageName == "footer-page" || pageName == "public-profile" || pageName == "sign-up"){
				    	$location.path( $location.path() );
				    }else{
				    	//uncomment this for production
				    	$location.path('/dashboard');
				    }



				})
				.catch(function(data){
					var split = $location.path().split("/");
				    var pageName = split[1];
					if(pageName == "footer-page" || pageName == "public-profile" || pageName == "sign-up"){
				    	$location.path( $location.path() );
				    }else{
				    	$location.path('/login');
				    }
					$scope.isLoading = false;
				});
		}else{

			var split = $location.path().split("/");
		    var pageName = split[1];
		    console.log(pageName);
			if(pageName == "footer-page" || pageName == "public-profile" || pageName == "sign-up"){
		    	$location.path( $location.path() );
		    }else{
		    	$location.path('/login');
		    }

			$scope.isLoading = false;
		}

		// back button //
		$scope.backShowing = false;
		$scope.backLocation = null;

		$scope.showBackButton = function(location){
			$scope.backShowing = true;
			$scope.backLocation = location;
		}

		$scope.hideBackButton = function(){
			$scope.backShowing = false;
		}

		// open close side menu
		$scope.openSideMenu = function(){
			angular.element('#SideNav').css({"right":"0px"});
		};

		$scope.closeSideMenu = function(){
			angular.element('#SideNav').css({"right":"-300px"});
		};

		$scope.logout = function(){
			if($scope.student){
				mygpsAPI.logout($scope.student.Email).then(function(){
					window.localStorage.removeItem("mygpsStudentToken");
    				window.localStorage.removeItem("mygpsStudentID");
					$location.path('/login');
					window.location.reload();
				});
			}
		}

		/* sanitize stuff */
		$scope.trustedHtml = function (plainText) {
            return $sce.trustAsHtml(plainText);
        }

	}
]);
