mygpsControllers.controller('Profile_Controller', function($window, $scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI, Upload) {
	
	console.log("profile");
	
	
	$scope.emailError = false;
	
	$scope.profileForm = {};
	$scope.profileForm = angular.copy($scope.$parent.student);
	
	console.log("STUDENT INFO");
	console.log($scope.$parent.student);
	
	$scope.updateProfile = function(isVaild){

		var member = {
			"ID": $scope.profileForm.ID,
			"FirstName": $scope.profileForm.FirstName,
			"Surname": $scope.profileForm.Surname,
			"Email": $scope.profileForm.Email,
			"Phone": $scope.profileForm.Phone,
			"Password": $scope.profileForm.Password,
			"Misson": $scope.profileForm.Misson,
			"Reference": $scope.profileForm.Reference,
			"ReferenceName": $scope.profileForm.ReferenceName,
			"ReferencePosition": $scope.profileForm.ReferencePosition,
			"LinkedInURL": $scope.profileForm.LinkedInURL,
			"FacebookURL": $scope.profileForm.FacebookURL,
			"TwitterURL": $scope.profileForm.TwitterURL,
			"PortfolioURL": $scope.profileForm.PortfolioURL,
			"BlogURL": $scope.profileForm.BlogURL,
			"PersonalityType": $scope.profileForm.PersonalityType,
			"PhotoID": $scope.$parent.student.PhotoID,
			"CVID": $scope.$parent.student.CVID,
			"FirstTime": 1
		};
		
		
		mygpsAPI.updateMember(member).then(function(data){
    		var studentID = $scope.$parent.student.ID;
    		
    		mygpsAPI.getObjects("Member","/"+studentID).then(function(data){
    			$scope.$parent.student = data;
    			console.log("Student Updated");
    			console.log(data);
    			$location.path('/dashboard/myprofile');
    		});
    	});
    	

	};
	
	
	// photo upload fields
	$scope.photoUploadProgress = 0;

	$scope.uploadPhoto = function(file,taskID) {

		file.upload = Upload.upload({
			url: assetsURL+'/home/UploadFile',
			data: {file: file}
		});

		file.upload.then(function (response) {
			console.log("uploaded photo");
			console.log(response.data);
			$scope.$parent.student.PhotoID = response.data;
		}, function (response) {
			if (response.status > 0){
				$scope.errorMsg = response.status + ': ' + response.data;
			}
		});

		file.upload.progress(function (evt) {
			$scope.photoUploadProgress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
		});
	};
	
	// cv upload fields
	$scope.cvUploadProgress = 0;

	$scope.uploadCV = function(file,taskID) {

		file.upload = Upload.upload({
			url: assetsURL+'/home/UploadFile',
			data: {file: file}
		});

		file.upload.then(function (response) {
			console.log("uploaded cv");
			console.log(response.data);
			$scope.$parent.student.CVID = response.data;
		}, function (response) {
			if (response.status > 0){
				$scope.errorMsg = response.status + ': ' + response.data;
			}
		});

		file.upload.progress(function (evt) {
			$scope.cvUploadProgress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
		});
	};
	
	
});