mygpsControllers.controller('ForgottenPasswordReset_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI, forgotPasswordResetService, loginResetService) {
	
	$scope.forgotPasswordReset = function(isVaild){
		
		console.log("reset password");
		console.log($scope.$parent.studentEmail);
		console.log($scope.$parent.studentCode);
		console.log($scope.forgotPasswordResetForm.password);
		console.log($scope.forgotPasswordResetForm.passwordConfirm);
		
		if($scope.forgotPasswordResetForm.password == $scope.forgotPasswordResetForm.passwordConfirm){
			forgotPasswordResetService.forgottenPasswordReset($scope.$parent.studentEmail, $scope.$parent.studentCode, $scope.forgotPasswordResetForm.password, function(result){

				console.log(result);
				
				if(result == "fail"){
					$scope.failed = true;
				}else{

					loginResetService.loginReset($scope.$parent.studentEmail,$scope.forgotPasswordResetForm.password,function(result){
						console.log("login");
						console.log(result);
						if(!result.result){
							$scope.$parent.isLoggedIn = false;
							$scope.loginError = "Whoops! It's seems your email or password are incorrect, please try again.";
							$scope.loggingIn = false;
						}else{
							console.log("good login");
							 mygpsAPI.getObjects("Member/"+result.userID).then(function(data){
								 $scope.$parent.student = data;
								 $scope.$parent.isLoggedIn = true;
								 $location.path('/dashboard');
							 });
						}
					});

				}
				
			});
		}else{
			$scope.badMatch = true;
		}
		
		
		
	}
	
});

mygps.factory('forgotPasswordResetService', function(mygpsAPI) {
    return {
    	forgottenPasswordReset: function(email, code, password, callback) {
    		
    		mygpsAPI.forgottenPasswordReset(email, code, password, callback).then(function(data){
    			
    			var result = "";
    			
    			if(data.data.status == "success"){
    				result = "success";
    			}else{
    				result = "fail";
    			}
    			callback(result);
    			
    		});
    		
        }
    };
});

mygps.factory('loginResetService', function(mygpsAPI) {
    return {
        loginReset: function(email,pwd,callback) {

        	console.log("email = "+email);
        	console.log("pass = "+pwd);

        	mygpsAPI.login(email,pwd,callback).then(function(data){

        		console.log(data);

    			var result = data.data;
    			if(!result.result){
    				console.log("BAD LOGIN");
    				window.localStorage.removeItem("mygpsStudentToken");
    				window.localStorage.removeItem("mygpsStudentID");
    			}else{
    				console.log(result);
    				window.localStorage.setItem("mygpsStudentToken", result.token);
    				window.localStorage.setItem("mygpsStudentID", result.userID);
    			}

    			callback(result);

    		});

        }
    };
});