mygpsControllers.controller('CompletedTips_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI) {

	// hide back button
	$scope.quest = {};
	$scope.growthCat = {};

	mygpsAPI.getObjects("Quest","/"+$routeParams.ID).then(function(data){
		$scope.quest = data;
		$scope.tasks = $scope.quest.Tasks;

		mygpsAPI.getObjects("Quest","/"+$scope.quest.ID).then(function(data){

			$scope.quest = data;
			$scope.$parent.showBackButton("#!/completed/"+$scope.quest.ID);
			mygpsAPI.getObjects("GrowthCategory","/"+$scope.quest.GrowthCategory).then( function(data){
				$scope.growthCat = data;
				console.log($scope.growthCat);
			});

		});

	});
});