'use strict';

/* Services */
var mygpsServices = angular.module('mygpsServices', []);
