mygpsControllers.controller('Register_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, $uibModal, baseURL, assetsURL, mygpsAPI, signupService) {

	
	// terms
	
	var $ctrl = this;
	$ctrl.animationsEnabled = true;
	
	$scope.openTerms = function (size, parentSelector) {
	    var parentElem = parentSelector ? 
	      angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
	    var modalInstance = $uibModal.open({
	      animation: $ctrl.animationsEnabled,
	      ariaLabelledBy: 'modal-title',
	      ariaDescribedBy: 'modal-body',
	      templateUrl: 'myModalContent.html',
	      controller: 'ModalInstanceCtrl',
	      controllerAs: '$ctrl',
	      size: size,
	      appendTo: parentElem,
	      resolve: {
	        items: function () {
	          return $ctrl.items;
	        }
	      }
	    });
	}
	
	// show back button
	$scope.$parent.showBackButton("#!/home");

	$scope.loggingIn = false;
	$scope.loginError = false;
	$scope.courses = [];


	$scope.noCourse = function(){
		if(!$scope.signupForm.AraCourse){
			return true;
		}else{
			return false;
		}
	}


	mygpsAPI.getCourses().then(function(data){

		console.log("get courses");
		console.log( data );

		$scope.courses = data;
	});

	$scope.signup = function(isVaild){

		console.log($scope.signupForm.Age);

		var lEmail = $scope.signupForm.Email;
		var lPwd = $scope.signupForm.Password;

		mygpsAPI.checkStudentID($scope.signupForm.StudentID).then(function(data){
			if(data.data == 'success'){
				console.log("yes! vaild student id");
				signupService.signup($scope.signupForm.FirstName,$scope.signupForm.Surname,$scope.signupForm.Email,$scope.signupForm.StudentID,$scope.signupForm.Gender,$scope.signupForm.AraCourse,$scope.signupForm.Age,$scope.signupForm.Password,function(result){
					if(result.status == "success"){

						signupService.login(lEmail,lPwd,function(result){
							console.log(result)
							if(!result.result){

								$scope.loginError = "Whoops! It's seems your email or password are incorrect, please try again.";
								$scope.loggingIn = false;
								setTimeout(function(){
									console.log("time");
								}, 1000);
							}else{
								mygpsAPI.getObjects("Member/"+result.userID).then(function(data){
									 $scope.$parent.student = data;
									 $scope.$parent.isLoggedIn = true;
									 $location.path('/help');
								 });
							}
						});

					}else{
						$scope.loginError = result.message;
					}
				});
			}else{
				$scope.loginError = "Sorry, we can't find that student ID";
			}
		});

	};

});

mygps.factory('signupService', function(mygpsAPI) {
    return {
    	signup: function(firstName,surname,email,studentID,gender,course,age,pwd,callback) {

        	var member = {
        		"FirstName": firstName,
        		"Surname": surname,
        		"Email": email,
        		"StudentID": studentID,
        		"Password": pwd,
        		"Gender": gender,
        		"AraCourseID": course,
        		"Age": age
        	};

        	mygpsAPI.createMember(member).then(function(data){
    			var result = data;
    			console.log(data);
    			callback(result);
    		});


        },
        login: function(email,pwd,callback) {

        	console.log("email = "+email);
        	console.log("pass = "+pwd);

        	mygpsAPI.login(email,pwd,callback).then(function(data){

        		console.log(data);

    			var result = data.data;
    			if(!result.result){
    				console.log("BAD LOGIN");
    				//$cookies.remove('blipparMemberToken');
    				//$cookies.remove('blipparMemberID');
    				window.localStorage.removeItem("mygpsStudentToken");
    				window.localStorage.removeItem("mygpsStudentID");
    			}else{
    				console.log(result);
    				//$cookies.put('blipparMemberToken', result.token);
    				//$cookies.put('blipparMemberID', result.userID);
    				window.localStorage.setItem("mygpsStudentToken", result.token);
    				window.localStorage.setItem("mygpsStudentID", result.userID);
    			}
    			callback(result);
    		});

        }
    };
});

mygpsControllers.controller('ModalInstanceCtrl', function ($uibModalInstance, items) {
	  var $ctrl = this;
	  $ctrl.items = items;
	 
	  $ctrl.ok = function () {
	    $uibModalInstance.close($ctrl.selected.item);
	  };

	  $ctrl.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	  };
	});