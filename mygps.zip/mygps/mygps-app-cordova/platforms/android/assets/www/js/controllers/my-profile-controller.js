mygpsControllers.controller('MyProfile_Controller', function($window, $scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI, Upload) {

	$scope.completedQuests = [];

	//mygpsAPI.getQuests($scope.$parent.student).

	$scope.$parent.$watch('student', function(){

		mygpsAPI.getCompletedQuests($scope.student.AraCourse,$scope.student.ID).then(function(data){
			console.log("completed quests");
			console.log(data);
			$scope.completedQuests = data;
		});
		
	}, true);
	
});