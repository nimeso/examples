mygpsControllers.controller('FooterPage_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI) {
	
	mygpsAPI.getFooterPage($routeParams.ID).
		then(function(data){
			console.log("good footer page");
			console.log(data.data);
			$scope.page = data.data;
		})
		.catch(function(data){
			console.log("bad footer page");
		});
});