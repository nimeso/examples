mygpsControllers.controller('QuestDetails_Controller', function($scope, $route, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI, Upload ) {

	$scope.quest = [];
	$scope.tasks = [];
	$scope.studentQuest = [];
	$scope.studentTasks = [];
	$scope.questForm = [];
	$scope.questForm.Task = [];

	$scope.codesAreCorrect = false;
	$scope.formCodesAreCorrect = false;

	$scope.clearAllCodeInputs = true;

	// show back button
	$scope.$parent.showBackButton("#!/dashboard");

	var action = $route.current.action;
	var id = $routeParams.ID;
	
	switch (action) {
		case 'edit' :
			editQuest(id);
			break;

		case 'create' :
			newQuest(id);
			break;
	}

	function editQuest(StudentQuestID){
		mygpsAPI.getObjects("StudentQuest","/"+StudentQuestID).then(function(data){ //this could all be done in a single ajax call: getSingleStudentQuest, but code incomplete, needs to be revisited if budget allows
			$scope.studentQuest = data;
			console.log($scope.studentQuest);
			mygpsAPI.getObjects("Quest","/"+data.Quest).then(function(data){
				$scope.quest = data;
				$scope.tasks = $scope.quest.Tasks;

				angular.forEach($scope.tasks, function(value, key) {
					mygpsAPI.getObjects("StudentTask","?StudentQuestID="+$scope.studentQuest.ID+"&TaskID="+value.ID).then(function(data){
						if(data[0]){
							$scope.questForm.Task[data[0].Task] = data[0].Value; // needs fixing
						}
					});
				});
			});
		});

		return;
	}

	function newQuest(QuestID){
		mygpsAPI.getObjects("Quest","/"+QuestID).then(function(data){
			$scope.quest = data;
		});
	}

	// function saveNewQuest(){
	// 	// get current quest and tasks
	// 	mygpsAPI.getObjects("Quest","/"+$routeParams.ID).then(function(data){
	// 		$scope.quest = data;
	// 		$scope.tasks = $scope.quest.Tasks;

	// 		mygpsAPI.getObjects("StudentQuest","?QuestID="+$scope.quest.ID+"&MemberID="+$scope.$parent.student.ID).then(function(data){
	// 			$scope.studentQuest = data[0];
	// 			$scope.questForm.Task = [];
	// 			angular.forEach($scope.tasks, function(value, key) {
	// 				mygpsAPI.getObjects("StudentTask","?StudentQuestID="+$scope.studentQuest.ID+"&TaskID="+value.ID).then(function(data){
	// 					if(data[0]){
	// 						$scope.questForm.Task[data[0].Task] = data[0].Value;
	// 					}
	// 				});
	// 			});
	// 			$scope.startTest();
	// 		});
	// 		$scope.startTest();
	// 	});
	// }

	$scope.startQuest = function(){
		var studentQuestData = {
				Status: "started",
				MemberID: $scope.$parent.student.ID,
				QuestID: $scope.quest.ID
		};
		mygpsAPI.createObject("StudentQuest",studentQuestData,null).then(function(data){
			console.log("data", data);
			$location.path('/quest-details/'+data.ID);
		});
	};


	$scope.codeCheck = function(userValue,taskID){
		mygpsAPI.codeCheck(userValue,taskID).then(function(data){
			$scope.clearAllCodeInputs = false;
			if(data == "correct"){
				$scope.codesAreCorrect = true;
			}else{
				$scope.codesAreCorrect = false;
			}
		});
	};

	// file upload fields
	
	
	$scope.fileUploadProgress = 0;

	$scope.uploadFile = function(file,taskID) {


		file.upload = Upload.upload({
			url: assetsURL+'/home/UploadFile',
			data: {file: file}
		});

		file.upload.then(function (response) {
			if (!$scope.questForm) {
			  $scope.questForm = {};
			}
			if (!$scope.questForm.Task) {
			  $scope.questForm.Task = {};
			}
			if (!$scope.questForm.Task[taskID]) {
			  $scope.questForm.Task[taskID] = {};
			}
			$scope.questForm.Task[taskID].FileUploadID = response.data;
		}, function (response) {
			if (response.status > 0){
				$scope.errorMsg = response.status + ': ' + response.data;
			}
		});

		file.upload.progress(function (evt) {
			$scope.fileUploadProgress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
		});

	};


	$scope.unstartTest = function(){
		$scope.studentQuest.Status = "unstarted";
		if($scope.studentQuest){
			mygpsAPI.createObject("StudentQuest",$scope.studentQuest,$scope.studentQuest.ID).then(function(data){
			});
		}else{
			$scope.studentQuestData = {
					Status: "unstarted",
					MemberID: $scope.$parent.student.ID,
					QuestID: $scope.quest.ID
			};
			mygpsAPI.createObject("StudentQuest",$scope.studentQuestData,null).then(function(data){
			});
		}
	}

	$scope.submitQuest = function(isVaild){
		

		if(jQuery(".TaskCode").length > 0){
			if(!$scope.codesAreCorrect){
				$scope.formCodesAreCorrect = true;
				return;
			}
		}

		if($scope.studentQuest){
			$scope.studentQuest.Status = "completed";


			mygpsAPI.getObjects("StudentQuest","?QuestID="+$scope.quest.ID+"&MemberID="+$scope.$parent.student.ID).then(function(data){
				if(data.length > 0){
					console.log("old quest");
					mygpsAPI.createObject("StudentQuest",$scope.studentQuest,$scope.studentQuest.ID).then(function(data){
						mygpsAPI.deleteAllStudentTasks($scope.studentQuest.ID).then(function(data){
							$scope.createTasks();
						});

					});
				}else{
					mygpsAPI.createObject("StudentQuest",$scope.studentQuest,$scope.studentQuest.ID).then(function(data){
						$scope.studentQuest = data;
						$scope.formCodesAreCorrect = false;

						console.log("new quest");
						
						mygpsAPI.deleteAllStudentTasks($scope.studentQuest.ID).then(function(data){
							$scope.createTasks();
						});

					});
				}
			});

		}else{
			console.log("Create new");
			$scope.studentQuestData = {
					Status: "completed",
					MemberID: $scope.$parent.student.ID,
					QuestID: $scope.quest.ID
			};
			mygpsAPI.createObject("StudentQuest",$scope.studentQuestData,null).then(function(data){
				$scope.studentQuest = data;
				$scope.formCodesAreCorrect = false;
				// might be bung
				$scope.createTasks();
			});
		}
	}

	$scope.createTasks = function(){

		var saveCount = 0;
		var keys = Object.keys($scope.questForm.Task)
		var len = keys.length;
		console.log(saveCount);
		console.log(len);

		angular.forEach($scope.questForm.Task, function(value, key) {

			if(value["Value"] != undefined){
				var studentTask = {
					Value: value["Value"],
					TaskID: key,
					StudentQuestID: $scope.studentQuest.ID
				};
			}else{
				studentTask = {
					FileUploadID: value["FileUploadID"],
					TaskID: key,
					StudentQuestID: $scope.studentQuest.ID
				};
			}

			mygpsAPI.getObjects("Task","/"+key).then(function(taskData){
				if(taskData.ProfileField){
					var member = {};
					member["ID"] = $scope.$parent.student.ID;
					member[taskData.ProfileField] = value["Value"];
					mygpsAPI.updateMember(member).then(function(memberData){
						$scope.$parent.student = memberData;
						console.log(memberData);
					});
				}
			});
			
			mygpsAPI.createObject("StudentTask",studentTask,null).then(function(data){		
				saveCount++;
				if(saveCount == len){

					mygpsAPI.getObjects("Task","/"+key).then(function(taskData){
						if(taskData.ProfileField){
							var member = {};
							member["ID"] = $scope.$parent.student.ID;
							console.log("file = "+value["FileUploadID"]);
							console.log("value = "+value["value"]);
							if(value["Value"] != undefined){
								member[taskData.ProfileField] = value["Value"];
							}else{
								member[taskData.ProfileField] = value["FileUploadID"];
							}
							
							mygpsAPI.updateMember(member).then(function(memberData){
								$scope.$parent.student = memberData;
								console.log(memberData);
								$location.path('/completed/'+$scope.quest.ID);
							});
						}else{
							console.log("the end");
							$location.path('/completed/'+$scope.quest.ID);
						}
					});
				}
			});
			
		});
		
	}


});