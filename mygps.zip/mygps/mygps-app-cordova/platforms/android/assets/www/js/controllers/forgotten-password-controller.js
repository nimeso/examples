mygpsControllers.controller('ForgottenPassword_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, baseURL, assetsURL, mygpsAPI, forgotPasswordService) {
	
	$scope.forgotPassword = function(isVaild){
		
		forgotPasswordService.forgotPassword($scope.forgotPasswordForm.Email, function(result){

            console.log(result);

			if(result == "fail"){
				$scope.failed = true;
			}else{
				$scope.$parent.studentEmail = $scope.forgotPasswordForm.Email;
				$location.path("/forgotten-password-code");
			}
			
		});
		
	}
	
});

mygps.factory('forgotPasswordService', function(mygpsAPI) {
    return {
    	forgotPassword: function(email, callback) {
    		
    		console.log("forgot data 1");
    		
    		mygpsAPI.forgottenPassword(email,callback).then(function(data){

                console.log(data);

    			
    			var result = "";
    			
    			if(data.data.status == "success"){
    				result = "success";
    			}else{
    				result = "fail";
    			}
    			callback(result);
    			
    		});
    		
        }
    };
});