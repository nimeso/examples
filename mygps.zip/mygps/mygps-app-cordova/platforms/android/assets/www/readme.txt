Install by using Bower https://bower.io/

To install use the command:
bower install