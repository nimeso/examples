(function (window) {
  window.mygps_env = window.mygps_env || {};

 
  window.mygps_env.baseURL = 'https://www.mygps.co.nz/api/';
  window.mygps_env.assetsURL = 'https://www.mygps.co.nz';
  window.mygps_env.openApiPageName = '/home';
 

  /*
  window.mygps_env.baseURL = 'http://localhost/carl-mygps-cms/api/';
  window.mygps_env.assetsURL = 'http://localhost/carl-mygps-cms';
  window.mygps_env.openApiPageName = '/home';
  */
  
  

}(this));