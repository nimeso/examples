blipperControllers.controller('BlipperCart_Controller', function($timeout, $location, $scope, $location, $cookies, $window, $uibModal, memberID, blipperAPI) {

	//$cookies.remove('blipparMemberToken');
	//$cookies.remove('blipparMemberID');

	$scope.$on('event:google-plus-signin-success', function (event,authResult) {
	    // Send login to server or save into cookie
		var email = authResult.wc.hg;
		var firstName = authResult.wc.Za;
		var surname = authResult.wc.Na;
		console.log(event);
		console.log(authResult);
		console.log(email);
		console.log(firstName);
		console.log(surname);
		
		blipperAPI.memberCheck(email).then(function(data){
			if(data.status == "success"){ // already a member, login
				$cookies.put('blipparMemberToken',data.token);
				$cookies.put('blipparMemberID',data.id);
				window.location = '#/adverts';
			    window.location.reload();
			}else{ // not a member, signup / login
				console.log("new member");
				var data = {
					"FirstName": firstName,
					"Surname": surname,
					"Email": email,
					"ApiToken": authResult.hg.access_token,
					"ApiTokenExpire": authResult.hg.expires_at
				};
				console.log(data);
				blipperAPI.createMemberWithToken(data).then(function(data){
					console.log(data);
					$cookies.put('blipparMemberToken',data.token);
					$cookies.put('blipparMemberID',data.id);
					window.location = '#/adverts';
				    window.location.reload();
				});
			}
		});
	});
	
	$scope.$on('event:google-plus-signin-failure', function (event,authResult) {
	    // Auth failure or signout detected
		console.log(authResult);
	});
	
	$scope.globalShowHelp = function(){
		var path = $location.path();
		if(path == "/home"){
			return false;
		}else{
			return true;
		}
	}

	$scope.showHelp = false;
	
	$scope.memberDontShowHelp = function(){
		var simpleMember = {
			"ID": $scope.member.ID,
			"DontShowHelp": 1
		};
		blipperAPI.updateMember(simpleMember).then(function(data){
			console.log(data);
		});
		$scope.showHelp = false;
	}
	
	$scope.memberShowHelp = function(){
		var simpleMember = {
			"ID": $scope.member.ID,
			"DontShowHelp": 0
		};
		blipperAPI.updateMember(simpleMember).then(function(data){
			console.log(data);
		});
		$scope.showHelp = true;
	}
	
	$scope.closeHelpHint = function(){
		$scope.showHelpHint = false;
	}
	
	$scope.isMember = function(){
		if($scope.member){
			return true;
		}else{
			return false;
		}
	}
	
	$scope.getMember = function(){
		if($cookies.get('blipparMemberToken')){
			blipperAPI.getMember().then(function(data){
				$scope.member = data.data[0];
				if($scope.member.DontShowHelp == 0){
					$scope.showHelp = true;
				}
				console.log($scope.member);
			});
		}
	}
	
	$scope.getMember();

	$scope.logout = function(){
		if($scope.member){
			blipperAPI.logout($scope.member.Email).then(function(){
				$cookies.remove('blipparMemberToken');
				$cookies.remove('blipparMemberID');
				window.location = '#/home';
				window.location.reload();
			});
		}
	}
	
	$scope.getPageClass = function(){
		var url = $location.path().replace("/", "page-class-");
		return url;
	}
	
	$scope.getOrder = function(){
		blipperAPI.getOrder().then(function(data){
			if(data.data[0]){
				$scope.order = data.data[0];
				console.log($cookies.get('blipparMemberToken'));
				console.log($scope.order);
				if($scope.order.OrderItems){
					
					if(!$scope.PreviewOrderItems){
						$scope.PreviewOrderItems = [];
					}
					
					for(var u=0; u<$scope.order.OrderItems.length; u++){
						blipperAPI.getOrderItem($scope.order.OrderItems[u]).then(function(data){
							$scope.PreviewOrderItems.push(data.data);
						});
					}
					
				}
			}else{
				$scope.order = {};
			}
			console.log($scope.order);
		});
	}
	
	if($cookies.get('blipparMemberToken')){
		$scope.getOrder();
	}

	$scope.addItemToOrder = function(device,mediaItem,startDate,endDate,weeks,callback){

		var orderItem = {
			"DeviceTitle": device.Title,
			"DeviceCost": device.Cost,
			"DeviceLocation": device.Location,
			"MediaItemTitle": mediaItem.Title,
			"StartDate": startDate,
			"EndDate": endDate,
			"WeeksBooked": weeks,
			"Total": weeks * device.Cost,
			"Device": device.ID,
			"MediaItem": mediaItem.ID
		};

		blipperAPI.updateOrderItem(orderItem).then(function(data){
			
			$scope.orderItem = data;
			console.log($scope.orderItem);
			
			if(!$scope.PreviewOrderItems){
				$scope.PreviewOrderItems = [];
			}
			
			$scope.PreviewOrderItems.push($scope.orderItem);
			
			var itemIDs = [];
			for(var t=0; t<$scope.PreviewOrderItems.length; t++){
				itemIDs.push($scope.PreviewOrderItems[t].ID);
			}
			
			$scope.order.OrderItems = itemIDs;
			
			if(!$scope.order.Member){
				$scope.order.Member = $cookies.get('blipparMemberID');
			}
			
			blipperAPI.updateOrder($scope.order).then(function(data){
				$scope.order = data;
				console.log($scope.order);
				if(callback){
					callback();
				}
			});
			
			console.log(device);
			console.log(mediaItem);
			console.log($scope.orderItem);
			
		});

	}
	
	$scope.submitBuyForm = function(isValid) {
		
		console.log($scope.order);

		$scope.order.payment = {
    		"Currency": "NZD",
    		"Amount": $scope.OrderTotal(),
    		"Reference": $scope.order.ID
    	};

    	blipperAPI.buy($scope.order).then(function(back){
    		console.log(back.data);
    		window.location.assign(back.data);
    	});
		
	    // check to make sure the form is completely valid
	    if (isValid) {
	    	
	    }else{
	    	//alert("shit is bad");
	    }
	};
	
	$scope.OrderTotal = function () {
		if(($scope.PreviewOrderItems) && $scope.PreviewOrderItems.length > 0){
			var total = 0;
			for(var t=0; t<$scope.PreviewOrderItems.length; t++){
				total += parseInt($scope.PreviewOrderItems[t].Total);
			}
			return total;
		}
	}
	
	$scope.goBack = function(){
		$window.history.back();
	}
	
	$scope.openLoginModal = function () {
		var loginModal = $uibModal.open({
			size: "mm",
			animation: false,
			rootScope: $scope,
			templateUrl: 'login.html',
			controller: 'ModalLoginCtrl',
			resolve: {}
		});
	}

	$scope.openSignupModal = function () {
		var loginModal = $uibModal.open({
			size: "mm",
			animation: false,
			rootScope: $scope,
			templateUrl: 'signup.html',
			controller: 'ModalSignupCtrl',
			resolve: {}
		});
	}
	
	$scope.date = new Date();
	
	/* height helpers */
	
	$scope.positionFooter = function(){
		var footerHeight = jQuery("#Footer").height();
		var footerY = jQuery("#Footer").position().top;
		var winHeight = window.innerHeight;
		if( (footerHeight + footerY + 60) < winHeight){
			jQuery("#Footer").css({"position":"fixed", "bottom":"0px"});
		}
	}
	
	$scope.calculateDimensions = function(gesture) {
		$scope.dev_width = $window.innerWidth;
	    $scope.dev_height = $window.innerHeight;
	    
	    var footerHeight = jQuery("footer").height();
	    var contentHeight = jQuery(".fade-page").height();
	    
	    console.log(footerHeight+" - "+contentHeight);
	    
	}
	     
	angular.element($window).bind('resize', function(){
		$scope.$apply(function() {
			$scope.calculateDimensions();
			$scope.positionFooter();
		})       
	});
	     
	$scope.calculateDimensions();
	
	$timeout(function(){
		$scope.positionFooter();		
	}, 2000);	
	
	/* data helpers */
	
	$scope.getSimpleDate = function(startDate){

		var sDate = new Date(startDate),
	    	locale = "en-us",
	    	day = sDate.toLocaleString(locale, { day: "numeric" }),
	    	month = sDate.toLocaleString(locale, { month: "short" });
			year = sDate.toLocaleString(locale, { year: "numeric" });

		return $scope.getGetOrdinal(day)+" "+month+" "+year;
	}
	
	$scope.getSimpleDateWithTime = function(startDate){

		var sDate = new Date(startDate),
	    	locale = "en-us",
	    	day = sDate.toLocaleString(locale, { day: "numeric" }),
	    	month = sDate.toLocaleString(locale, { month: "short" });
			year = sDate.toLocaleString(locale, { year: "numeric" });

		return $scope.getGetOrdinal(day)+" "+month+" "+year+" @ "+$scope.getSimpleTime(sDate);
	}
	
	$scope.getSimpleSpanDate = function(startDate,endDate){

		var sDate = new Date(startDate),
	    	locale = "en-us",
	    	day = sDate.toLocaleString(locale, { day: "numeric" }),
	    	month = sDate.toLocaleString(locale, { month: "short" });
			year = sDate.toLocaleString(locale, { year: "numeric" });
		
		var eDate = new Date(endDate),
			elocale = "en-us",
	    	eday = eDate.toLocaleString(elocale, { day: "numeric" }),
	    	emonth = eDate.toLocaleString(elocale, { month: "short" });
			eyear = eDate.toLocaleString(elocale, { year: "numeric" });
			
		return $scope.getGetOrdinal(day)+" "+month+" "+year+" - "+$scope.getGetOrdinal(eday)+" "+emonth+" "+eyear;
	}
	
	$scope.getGetOrdinal = function(n) {
	    var s=["th","st","nd","rd"],
	    v=n%100;
	    return n+(s[(v-20)%10]||s[v]||s[0]);
	 }
	
	
	$scope.getSimpleTime = function(date) {
		  var hours = date.getHours();
		  var minutes = date.getMinutes();
		  var ampm = hours >= 12 ? 'pm' : 'am';
		  hours = hours % 12;
		  hours = hours ? hours : 12; // the hour '0' should be '12'
		  minutes = minutes < 10 ? '0'+minutes : minutes;
		  var strTime = hours + ':' + minutes + ' ' + ampm;
		  return strTime;
	}

	
});

blipperControllers.controller('ModalLoginCtrl', function ($scope, $route, $uibModal, $location, $uibModalInstance, blipperAPI, loginService) {
		
	$scope.loggingIn = false;
	$scope.loginError = false;
	
	$scope.submitLoginForm = function(isValid){
		
		$scope.loginError = false;
		$scope.loggingIn = true;
		
		loginService.login($scope.loginForm.Email,$scope.loginForm.Password,function(result){
			console.log(result);
			if(!result.result){
				$scope.loginError = "Whoops! It's seems your email or password are incorrect, please try again.";
				$scope.loggingIn = false;
			}else{
				$uibModalInstance.dismiss('cancel');
				window.location = '#/adverts';
			    window.location.reload();
			}
		});
	}
	
  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
  
  $scope.openSignupModal = function () {
	  $uibModalInstance.dismiss('cancel');
		var loginModal = $uibModal.open({
			size: "mm",
			animation: false,
			templateUrl: 'signup.html',
			controller: 'ModalSignupCtrl',
			resolve: {}
		});
	}
	  
});

blipperControllers.controller('ModalSignupCtrl', function ($scope, $location, $uibModalInstance, blipperAPI, memberID, loginService) {

	$scope.submitSignupForm = function(isValid){
		
		var lEmail = $scope.signupForm.Email;
		var lPwd = $scope.signupForm.Password;
		
		loginService.signup($scope.signupForm.FirstName,$scope.signupForm.Surname,$scope.signupForm.Email,$scope.signupForm.Password,function(result){
			if(result.status == "success"){
				
				loginService.login(lEmail,lPwd,function(result){
					if(!result.result){
						$scope.loginError = "Whoops! It's seems your email or password are incorrect, please try again.";
						$scope.loggingIn = false;
						setTimeout(function(){
							console.log("time");
						}, 1000);
					}else{

						//$scope.sendSignUpConfirmEmail($scope.signupForm.Email,$scope.signupForm.FirstName,$scope.signupForm.Surname);
						$uibModalInstance.dismiss('cancel');
						
						window.location = '#/adverts';
					    window.location.reload();
					}
				});
				
			}else{
				$scope.loginError = result.message;
			}
		});
	}
	
	/* mail */
	$scope.sendSignUpConfirmEmail = function(email,firstName,Surname){
		var html = '\r\n<table width=\"100%\">\r\n\t<tr>\r\n\t\t<td width=\"20%\"><\/td>\r\n\t\t<td width=\"60%\">\r\n\t\t\t<h1><a href=\"http:\/\/blippar.co.nz\/pub\/\"><img src=\"http:\/\/blippar.co.nz\/pub\/img\/mail_logo2.png\"\/><\/a><\/h1>\r\n\t         <h1 style=\"font-family: \'Helvetica Neue\', Helvetica, Arial, \'Lucida Grande\', sans-serif; font-size: 36px; line-height: 1.2em; color: #a51d13; font-weight: 200; margin: 0px 0 10px; padding: 0;\">\r\n\t         \tWelcome to Blippar\r\n\t         <\/h1>\r\n\t         <p style=\"color: #666; font-style: italic; margin-bottom: 0px;\">Hi '+firstName+',<\/p>\r\n\t         <p style=\"color: #666; font-family: \'Helvetica Neue\', \'Helvetica\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6em; font-weight: normal; margin: 0 0 10px; padding: 0;\">\r\n\t         \tNow that you\'ve created a Blippar account, here are some of the things you can do with it. \r\n\t         <\/p>\r\n\t         <h3 style=\"color: #666; font-family: \'Helvetica Neue\', Helvetica, Arial, \'Lucida Grande\', sans-serif; font-size: 18px; line-height: 1.2em; color: #111111; font-weight: 200; margin: 20px 0 10px; padding: 0;\">\r\n\t         \tManage media like a pro\r\n\t         <\/h3>\r\n\t         <ul style=\"color: #666; font-family: \'Helvetica Neue\', \'Helvetica\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6em; font-weight: normal; margin: 0 0 10px; padding: 0;\">\r\n\t         \t<li style=\"font-family: \'Helvetica Neue\', \'Helvetica\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6em; font-weight: normal; margin: 0 0 10px 20px; padding: 0;\">\r\n\t         \t\tBooking on multiple billboards is easy. It\'s as simple as picking how many weeks to book add add it to your shopping cart.\r\n\t         \t<\/li>\r\n\t         \t<li style=\"color: #666; font-family: \'Helvetica Neue\', \'Helvetica\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6em; font-weight: normal; margin: 0 0 10px 20px; padding: 0;\">\r\n\t         \t\tNeed to make quick changes? Now you can! all our billboards upddate once a day so you know changes happen quick.\r\n\t         \t<\/li>\r\n\t         \t<li style=\"color: #666; font-family: \'Helvetica Neue\', \'Helvetica\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6em; font-weight: normal; margin: 0 0 10px 20px; padding: 0;\">\r\n\t         \t\tWhat is my media going to look like in-site? Blippar gives you a preview of what your media will look like on a real life billboard! (VR soon)\r\n\t         \t<\/li>\r\n\t         <\/li>\r\n\t         <h3 style=\"color: #666; font-family: \'Helvetica Neue\', Helvetica, Arial, \'Lucida Grande\', sans-serif; font-size: 18px; line-height: 1.2em; color: #111111; font-weight: 200; margin: 20px 0 10px; padding: 0;\">\r\n\t         \tScale with our resources\r\n\t         <\/h3>\r\n\t         <p style=\"color: #666; font-family: \'Helvetica Neue\', \'Helvetica\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6em; font-weight: normal; margin: 0 0 10px; padding: 0;\">\r\n\t         \tYou can easily create your first email today, but Blippar\'s pro features will scale with your business when you\'re ready. \r\n\t         <\/p>\r\n\t         <p style=\"color: #666; font-family: \'Helvetica Neue\', \'Helvetica\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 1.6em; font-weight: normal; margin: 0 0 30px; padding: 0;\">\r\n\t         \tWhether you craft each campaign from start to finish or manage a team of collaborators, we offer support on everything from design to delivery to analysis. \r\n\t         <\/p>\r\n\t         <a href=\"http:\/\/blippar.co.nz\/pub\/#\/adverts\" style=\"font-family: \'Helvetica Neue\', \'Helvetica\', Helvetica, Arial, sans-serif; font-size: 100%; line-height: 2; color: #ffffff; border-radius: 4px; display: inline-block; cursor: pointer; font-weight: bold; text-decoration: none; background: #a51d13; margin: 0; padding: 0; border-color: #a51d13; border-style: solid; border-width: 10px 20px;\">\r\n\t        \t\tGet started! Make your first media item\r\n\t         <\/a>\r\n\t\t<\/td>\r\n\t\t<td width=\"20%\"><\/td>\r\n\t<\/tr>\r\n<\/table>';
		blipperAPI.mailTo(email,"info@blippar.co.nz","Welcome to Blippar",html).then(function(data){
			console.log(data);
		});
	}
	
	$scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	};
	  
});

blipper.factory('loginService', function($cookies, blipperAPI) {
    return {
        login: function(email,pwd,callback) {
        	
        	console.log("email = "+email);
        	console.log("pass = "+pwd);
        	
        	blipperAPI.login(email,pwd,callback).then(function(data){
    			var result = data.data;
    			if(!result.result){
    				console.log("BAD LOGIN");
    				$cookies.remove('blipparMemberToken');
    				$cookies.remove('blipparMemberID');
    			}else{
    				console.log(result);
    				$cookies.put('blipparMemberToken', result.token);
    				$cookies.put('blipparMemberID', result.userID);	
    			}
    			callback(result);
    		});
        	
        },
        signup: function(firstName,surname,email,pwd,callback) {
        	
        	var member = {
        		"FirstName": firstName,
        		"Surname": firstName,
        		"Email": email,
        		"Password": pwd
        	};
        	
        	blipperAPI.createMember(member).then(function(data){
    			var result = data;
    			callback(result);
    		});
        	
        }
    };
});
