'use strict';

/* App Module */

var blipper = angular.module('blipper', [
  'ngRoute',
  'blipperControllers',
  'blipperServices',
  'uiGmapgoogle-maps',
  'ngMap',
  'ngFileUpload',
  'ui.bootstrap',
  'ui.bootstrap.progressbar',
  'angular-sortable-view',
  'ui.select',
  'ngSanitize',
  'scheduler',
  'rorymadden.date-dropdowns',
  'ui.bootstrap.datepicker',
  'angular-country-picker',
  'validation.match',
  'ngCookies',
  'cropme',
  'directive.g+signin',
  'uiCropper'
]);

blipper.constant('baseURL', 'http://localhost/blipper/api/');
blipper.constant('assetsURL', 'http://localhost/blipper');

blipper.value('memberID', null);
//blipper.constant('memberID', null);

blipper.config(['$routeProvider','$locationProvider',
	function($routeProvider, $locationProvider) {
    	$routeProvider.
    	when('/home', {
 		   templateUrl: 'templates/home.html',
 		   controller: 'Home_Controller'
       }).when('/adverts', {
		   templateUrl: 'templates/advert_manager.html',
		   controller: 'AdvertManager_Controller'
      }).when('/advert-details/:ID', {
		   templateUrl: 'templates/advert_details.html',
		   controller: 'AdvertDetails_Controller'
      }).when('/advert-book/:ID', {
		   templateUrl: 'templates/advert_book.html',
		   controller: 'AdvertBook_Controller'
      }).when('/cart', {
		   templateUrl: 'templates/cart.html',
		   controller: 'Cart_Controller'
      }).when('/checkout', {
		   templateUrl: 'templates/checkout.html',
		   controller: 'Checkout_Controller'
      }).when('/profile', {
		   templateUrl: 'templates/profile.html',
		   controller: 'Profile_Controller'
      }).when('/account', {
		   templateUrl: 'templates/account.html',
		   controller: 'Account_Controller'
      }).when('/order-details/:ID', {
		   templateUrl: 'templates/order_details.html',
		   controller: 'OrderDetails_Controller'
      }).when('/book-device/:dID/:mID', {
		   templateUrl: 'templates/device_details.html',
		   controller: 'DeviceDetails_Controller'
      }).when('/book-device/:dID', {
		   templateUrl: 'templates/device_details.html',
		   controller: 'DeviceDetails_Controller'
      }).when('/billboards', {
		   templateUrl: 'templates/billboard_finder.html',
		   controller: 'BillboardFinder_Controller'
      }).when('/help', {
		   templateUrl: 'templates/help.html',
		   controller: 'Help_Controller'
      }).otherwise({
    	  redirectTo: '/home'
      });
}]);
