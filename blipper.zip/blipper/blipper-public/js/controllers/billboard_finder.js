blipperControllers.controller('BillboardFinder_Controller', function($scope, $cookies, $routeParams, $filter, $location, $route, $templateCache, $uibModal, $timeout, $http, memberID, uiGmapIsReady, baseURL, assetsURL, blipperAPI, Upload, NgMap) {
	
	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;

	$scope.showingMapView = true;
	$scope.showingGridView = false;

	$scope.devicesJson = [];
	$scope.hoverDevice = {};
	$scope.bounds = new google.maps.LatLngBounds();
	
	$scope.$parent.dashboardClass = "";
	$scope.$parent.billboardFinderClass = "active";
	
	$scope.$parent.helpHeading = "Finding the best billboards";
	$scope.$parent.helpContent = "Click on the map markers to view each billboard loactions details, photos and statistics. If you prefer you can use the serach box to find locations faster.";
	
	if(!$cookies.get('blipparDeviceView')){
		$cookies.put('blipparDeviceView', 'map');
	}
	
	$scope.toggleView = function(){
		
		if($cookies.get('blipparDeviceView') == 'map'){
			$cookies.put('blipparDeviceView', 'list');
			$scope.showingMapView = false;
			$scope.showingGridView = true;
		}else{
			$cookies.put('blipparDeviceView', 'map');
			$scope.showingMapView = true;
			$scope.showingGridView = false;
		}
		$scope.updateMapFilter();
	}
	
	if($cookies.get('blipparDeviceView') == 'list'){
		$scope.showingMapView = false;
		$scope.showingGridView = true;
	}else{
		$scope.showingMapView = true;
		$scope.showingGridView = false;
	}

	blipperAPI.getDevices().then(function(data){

		$scope.devices = data;
		for(var p=0; p<$scope.devices.length; p++){
			var lat = $scope.devices[p].Lat;
		    var lng = $scope.devices[p].Lng;
		    var data = {
		     'Position': [lat, lng],
		     'ID': $scope.devices[p].ID,
		     'Icon': "img/marker_"+$scope.devices[p].TrafficRating+".png",
		     "Title": $scope.devices[p].Title,
		     "Location": $scope.devices[p].Location,
		     "Cost": $scope.devices[p].Cost,
		     "Description": $scope.devices[p].Description,
		     "TotalScreens": $scope.devices[p].TotalScreens,
		     "MediaWidth": $scope.devices[p].MediaWidth,
		     "MediaHeight": $scope.devices[p].MediaHeight,
		     "TrafficRating": $scope.devices[p].TrafficRating
		    }

		    var imgs = [];
			
			if(($scope.devices[p].ResizedImages) && $scope.devices[p].ResizedImages.length > 0){
				for(var g=0; g<$scope.devices[p].ResizedImages.length; g++){
					imgs.push($scope.devices[p].ResizedImages[g]);
				}
			}
			
			data["Images"] = imgs;

		    $scope.devicesJson.push(data);

		    var latlng = new google.maps.LatLng(lat, lng);
	      	$scope.bounds.extend(latlng);
	      	NgMap.getMap().then(function(map) {
			  map.setCenter($scope.bounds.getCenter());
			  map.fitBounds($scope.bounds);
			  map.setZoom(map.getZoom());
			});
			
		}

		console.log($scope.devices);
		$scope.pageLoading = false;
		$scope.$parent.pageLoading = false;
	});

	$scope.markerOver = function(e,p){
		console.log(p);
		$scope.hoverDevice = p;
	}

	$scope.markerClick = function(e,p){
		console.log(p);
		$location.path("book-device/"+p.ID);
	}

	$scope.updateMapFilter = function(){
		if($scope.mapquery.length > 2){
			$scope.filteredMarkers = $filter("filter")($scope.map.markers, $scope.mapquery);
		}else{
			$scope.filteredMarkers = $scope.map.markers;
		}
		console.log($scope.filteredMarkers);
	}
	
	
});