blipperControllers.controller('AdvertManager_Controller', function($scope, $cookies, $location, $uibModal, $timeout, blipperAPI, memberID) {
	
	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;

	$scope.showingGridView = true;
	$scope.showingListView = false;
	
	$scope.$parent.dashboardClass = "active";
	$scope.$parent.billboardFinderClass = "";
	
	$scope.$parent.helpHeading = "Managing your media";
	$scope.$parent.helpContent = "This is where you create and upload images and videos. Get started by clicking on the big red button. You can also search your media items and view as a grid or list.";
	
	console.log("adverts page");
	
	if(!$cookies.get('blipparMediaView')){
		$cookies.put('blipparMediaView', 'grid');
	}
	
	$scope.toggleView = function(){
		if($cookies.get('blipparMediaView') == 'grid'){
			$cookies.put('blipparMediaView', 'list');
			$scope.showingGridView = false;
			$scope.showingListView = true;
		}else{
			$cookies.put('blipparMediaView', 'grid');
			$scope.showingGridView = true;
			$scope.showingListView = false;
		}
	}
	
	if($cookies.get('blipparMediaView') == 'grid'){
		$scope.showingListView = false;
		$scope.showingGridView = true;
	}else{
		$scope.showingListView = true;
		$scope.showingGridView = false;
	}
	

	$scope.mediaItems = [];
	
	blipperAPI.getMediaItems().then(function(data){
		$scope.mediaItems = data;
		console.log($scope.mediaItems);
		$timeout(function(){
			$scope.pageLoading = false;
			$scope.$parent.pageLoading = false;
		}, 500);
	});

	$scope.gotoDetails = function(mediaItem){
		$location.path("/advert-details/"+mediaItem.ID);
	}
	
	$scope.openDeleteModal = function (mediaItem) {

	    var deleteModal = $uibModal.open({
	      size: "sm",
	      animation: false,
	      templateUrl: 'delete.html',
	      controller: 'ModalDeleteCtrl',
	      resolve: {
	    	  mediaItem: function () {
	            return mediaItem;
	          },
	          mediaItems: function () {
		         return $scope.mediaItems;
		      }
	       }
	    });
	    
	    
	}
	
	$scope.previewMediaItem = function (mediaItem) {

	    var modal = $uibModal.open({
	    	size: "lg",
	      animation: false,
	      templateUrl: 'preview.html',
	      controller: 'ModalPreviewCtrl',
	      resolve: {
	    	  mediaItem: function () {
	            return mediaItem;
	          }
	       }
	    }); 
	}
	
	$scope.newAdvert = function () {

	    var modal = $uibModal.open({
	    	size: "lg",
	      animation: false,
	      templateUrl: 'new-advert.html',
	      controller: 'ModalNewAdvertCtrl',
	      resolve: {
	          mediaItems: function () {
		         return $scope.mediaItems;
		      }
	       }
	   }); 
	}
	
	//$scope.newAdvert ();
	
});

blipperControllers.controller('ModalDeleteCtrl', function ($scope, $uibModalInstance, mediaItem, mediaItems, blipperAPI) {
		
	$scope.mediaItem = mediaItem;
	$scope.mediaItems = mediaItems;
	
	  $scope.ok = function () {
		  
		  var index = $scope.mediaItems.indexOf(mediaItem);

		  //todo: not working
		  $scope.mediaItems.splice(index, 1);
		  
		  $uibModalInstance.close();
		  blipperAPI.deleteMediaItem($scope.mediaItem).then(function(data){
			  
		  });
	  };

	  $scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	  };
});

blipperControllers.controller('ModalPreviewCtrl', function ($scope, $uibModalInstance, mediaItem, blipperAPI) {
	
	$scope.mediaItem = mediaItem;
	
	$scope.close = function () {
		$uibModalInstance.close();
	};
	  
});

blipperControllers.controller('ModalNewAdvertCtrl', function ($scope, $location, $uibModalInstance, $http, $timeout, blipperAPI, Upload, baseURL, assetsURL, mediaItems) {
	
	$scope.mediaItems = mediaItems;
	$scope.loading = false;
	$scope.step = 1;
	
	$scope.createdMediaItem = {};
	
	$scope.currentNewStep = 1;
	$scope.currentMediaType = false;
	$scope.step1Class = "active";
	$scope.step2Class = "";
	$scope.step3Class = "";

	$scope.uploadMessage = '';
	$scope.progressMessage = "";


	
	/* cropping stuff */

	/// new
	$scope.myImage = 'blank';
	$scope.myCroppedImage = '';
	$scope.myCroppedImageBlob = "test";
	
	///
	$scope.canCrop = true;
	$scope.croppedImageLoaded = false;
	$scope.percentUploaded = 0;

	$scope.saveCroppedImage = function(){
		console.log($scope.myCroppedImage);
	}

	$scope.backToUpload = function(){
		
		$scope.myImage = 'blank';
		$scope.myCroppedImage = '';
		$scope.uploadMessage = '';
		$scope.progressMessage = "";

		$scope.gotoStepOne("image");

		console.log($scope.myImage);
	}

	
	 $scope.uploadImage = function (file) {
	 	$scope.uploadMessage = "";
	 	$scope.progressMessage = "";
        Upload.upload({
            url: assetsURL+'/home/upload',
            data: {file: file}
        }).then(function (resp) {
        	console.log(resp.data.URL);
        	$scope.myImage = resp.data.URL;
            console.log('Success ' + resp.config.data.file.name + 'uploaded. Response: ' + resp.data);
        }, function (resp) {
        	$scope.uploadMessage = "Sorry, something went wrong. Please try again.";
        	console.log(resp);
            console.log('Error status: ' + resp.status);
        }, function (evt) {
            $scope.progressMessage = parseInt(100.0 * evt.loaded / evt.total)+"%";
            console.log('progress: ' + progressPercentage + '% ' + evt.config.data.file.name);
        });
    };

    $scope.saveCroppedImage = function(){


    	console.log(jQuery("#CroppedImage")[0].src);

    	$http({
		  method: 'POST',
		  url: assetsURL+'/home/uploadcropped',
		  data: jQuery("#CroppedImage")[0].src
		}).then(function successCallback(response) {
		    console.log(response.data.ID);
		    $scope.createdMediaItem.ImageMediaID = response.data.ID;
		    $scope.createdMediaItem.ImageMediaPreview = response.data.URL;
	        $scope.gotoStepThree();
		}, function errorCallback(response) {
		    // called asynchronously if an error occurs
		    // or server returns response with an error status.
		});
       
    }
    
    /*
    $scope.uploadImage = function(file) {
    	console.log(file);
        $scope.f = file;
        $scope.errFile = errFiles && errFiles[0];
        if (file) {
            file.upload = Upload.upload({
                url: assetsURL+'/home/upload',
                data: {file: file}
            });

            file.upload.then(function (response) {
                $timeout(function () {
                    $scope.myImage = response.data.URL;
                });
            }, function (response) {
                if (response.status > 0)
                    $scope.uploadMessage = response.status + ': ' + response.data;
            }, function (evt) {
                $scope.progressMessage = parseInt(100.0 * evt.loaded / evt.total)+"%";
            });
        }   
    }
    */

	/*
	$scope.$on("cropme:loaded", function(ev, width, height, cropmeEl) { 
		$scope.croppedImageLoaded = true;
	});
	
	$scope.$on("cropme:done", function(ev, result, cropmeEl) {

		var blob = result.croppedImage;
       
		var xhr = new XMLHttpRequest;
        xhr.upload.onprogress = $scope.updateProgress;
        xhr.open("POST", assetsURL+'/home/uploadcropped', true);
        xhr.setRequestHeader("Content-Type", blob.type);
        
        xhr.onreadystatechange = function(e) {
            if (this.readyState === 4 && this.status === 200) {	
            	var r = JSON.parse(this.responseText);
            	if(r.ID){
	            	$scope.createdMediaItem.ImageMediaID = r.ID;
	            	blipperAPI.getResizedImage($scope.createdMediaItem.ImageMediaID,"width",820,100).then(function(dataBack){
	            		$scope.createdMediaItem.ImageMediaPreview = dataBack.url;
	            		$scope.gotoStepThree();
	            	});
            	}
            } else if (this.readyState === 4 && this.status !== 200) {
                return console.log("failed");
            }
        };
       
        xhr.send(blob);
	});
	*/


	
	$scope.updateProgress = function(evt) {
	   if (evt.lengthComputable) {  
		   $scope.$apply(function() { 
			   var p = parseInt((evt.loaded / evt.total)*100);
			   if(p != 100){
				   $scope.percentUploaded = p;
				   console.log($scope.percentUploaded);
			   }
		   });
	   }
	}   

	/* steps */
	
	$scope.gotoStepTwoFromButton = function(mediaType){
		$scope.currentMediaType = mediaType;
		$scope.gotoStepTwo(mediaType);
	}
	
	$scope.gotoStepOne = function(mediaType){
		$scope.currentNewStep = 1;
		
		$scope.step1Class = "active";
		$scope.step2Class = "";
		$scope.step3Class = "";
	}
	
	$scope.gotoStepTwo = function(mediaType){
		console.log(mediaType);
		if($scope.currentMediaType){
			$scope.percentUploaded = 0;
			$scope.currentNewStep = 2;
			$scope.step1Class = "";
			$scope.step2Class = "active";
			$scope.step3Class = "";
		}
	}
	
	$scope.gotoStepThree = function(){
		if($scope.currentMediaType && $scope.createdMediaItem.ImageMediaPreview){
			console.log(" --- NEW MEDIA ITEM --- ");
			console.log($scope.createdMediaItem);
			$scope.currentNewStep = 3;
			$scope.step1Class = "";
			$scope.step2Class = "";
			$scope.step3Class = "active";
		}
	}

	$scope.doCreateMediaItem = function(){
		if(!$scope.createdMediaItem.Title){
			$scope.createdMediaItem.Title = "Untitled Media";
		}
		blipperAPI.updateMediaItem($scope.createdMediaItem).then(function(data){
			$scope.createdMediaItem = data;
			mediaItems.unshift($scope.createdMediaItem);
			$uibModalInstance.close();
		});
	}
	
	$scope.close = function () {
		$uibModalInstance.close();
	};
	
	$scope.gotoMediaItemDetails = function(){
		if($scope.mediaItem){
			$location.path("/advert-details/"+$scope.mediaItem.ID);
			$uibModalInstance.close();
		}
	}
	
	$scope.hidePage1 = function(){
		if($scope.loading || $scope.step != 1){
			return true;
		}
	}
	
	$scope.hidePage2 = function(){
		if($scope.loading || $scope.step != 2){
			return true;
		}
	}
	
	
	
	$scope.newMediaItem = function(){
		console.log($scope.mediaItem);
		$scope.loading = true;
		blipperAPI.updateMediaItem($scope.mediaItem).then(function(data){
			$scope.mediaItem = data;
			mediaItems.push($scope.mediaItem);
			$scope.loading = false;
			$scope.step = 2;
		});
	}
	/*
	$scope.uploadMediaFile = function(mediaItem,errFiles) {
		
		if(mediaItem.TempFile){
			
			console.log("thanks gebas");
			
			$scope.mediaFilesLoading = true;
			$scope.showPreview = false;
			
			mediaItem.TempFile.upload = Upload.upload({
                url: assetsURL+'/home/upload',
                data: {file: mediaItem.TempFile}
            });
			
			mediaItem.TempFile.upload.then(function (response) {
				
				mediaItem.FileID = response.data;		
				
				blipperAPI.getFile(mediaItem.FileID).then(function(data){
					$scope.mediaFilesLoading = false;
        			$scope.showPreview = true;
        			
        			resArray = data.Filename.match(/\.[^.]+$/);
        			res = resArray[0].toLowerCase();

        			if(res == ".jpg" || res == ".png"){
        				console.log("image");
        				$scope.newPreviewImage = assetsURL + "/" + data.Filename;
        			}else if(res == ".mp4"){
        				console.log("video");
        				$scope.newPreviewImage = assetsURL + "/blipper/images/video_placeholder.png";
        			}else{
        				console.log("error");
        			}
				});

            }, function (response) {
                if (response.status > 0)
                $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
            	mediaItem.percentage = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
		}
	}
	*/
	  
});