blipperControllers.controller('DeviceDetails_Controller', function($scope, $routeParams, $window, $route, $templateCache, $location, $uibModal, $timeout, $http, uiGmapIsReady, baseURL, assetsURL, blipperAPI, Upload) {

	$scope.bookingDone = false;
	
	$scope.pageLoading = true;
	$scope.MediaLoading = true;
	$scope.$parent.pageLoading = true;
	
	$scope.$parent.dashboardClass = "active";
	$scope.$parent.billboardFinderClass = "";
	
	$scope.$parent.helpHeading = "Book this billboard?";
	$scope.$parent.helpContent = "If you think this is the billboard for you, choose how many weeks you want to book and your done!";

	$scope.createNewMediaItem = function(){
		console.log("clikck");
		$location.path("/adverts");
	}
	
	blipperAPI.getDevice($routeParams.dID).then(function(data){
		
		console.log(data);
		
		$scope.device = data;
		$scope.pageLoading = false;
		$scope.$parent.pageLoading = false;
		
		$scope.images = [];
		var index = 0;
		angular.forEach($scope.device.ResizedImages, function(image){
			
			var imageObj = {
				"index": index,
				"url": image
			};
			index++;
			$scope.images.push(imageObj);
			
		});
		
		if($routeParams.mID){
			blipperAPI.getMediaItem($routeParams.mID).then(function(data){
				$scope.mediaItem = data;
				$scope.MediaLoading = false;
			});
		}else{
			blipperAPI.getMediaItems().then(function(data){
				$scope.mediaItems = data;
				$scope.MediaLoading = false;
			});
		}
		
	});

	if($routeParams.mID){
		$scope.hasMediaItem = true;
	}else{
		$scope.hasMediaItem = false;
	}
	
	
	
	$scope.isActive = function(index){
		if(index == 0){
			return "active";
		}
	}
	$scope.getWeeks = function(i){	
		if(i == 1){
			return "Week";
		}else{
			return "Weeks";
		}
	}
	
	/* start date */
	$scope.format = 'dd MMMM yyyy';
	
	$scope.open = function() {
	    $scope.popup.opened = true;
	};
	
	// Disable weekend selection
	$scope.disabled = function(date, mode) {
	    return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
	};
	
	$scope.popup = {
		opened: false
	};
	
	$scope.nextWeek = function(num) {
		if($scope.startDate){
			console.log("yes = "+num);
			var firstDay = $scope.startDate;
			$scope.endDate = new Date(firstDay.getTime() + (num * 7) * 24 * 60 * 60 * 1000);
		}
	}
	
	/* add to cart */
	$scope.modalAddItemToOrder = function(device,mediaItem,startDate,endDate,weeks){
		if($scope.selectedMediaID){
			mediaItem = $scope.selectedMedia;
		}
		$scope.addItemToOrder(device,mediaItem,startDate,endDate,weeks);
		$scope.weeks = null;
		$scope.startDate = null;
		$scope.bookingDone = true;
	}
	
	$scope.selectMedia = function(mediaID){
		$scope.selectedMediaID = mediaID;
		$scope.hasMediaItem = true;
		blipperAPI.getMediaItem(mediaID).then(function(data){
			console.log(data);
			$scope.selectedMedia = data;
		});
	}
	
});