blipperControllers.controller('Home_Controller', function($scope, $window, $location, $templateCache, $uibModal, $timeout, $http, baseURL, assetsURL, blipperAPI, memberID) {

	Raphael.fn.roundedRectangle = function (x, y, w, h, r1, r2, r3, r4){
		var array = [];
		array = array.concat(["M",x,r1+y, "Q",x,y, x+r1,y]); //A
		array = array.concat(["L",x+w-r2,y, "Q",x+w,y, x+w,y+r2]); //B
		array = array.concat(["L",x+w,y+h-r3, "Q",x+w,y+h, x+w-r3,y+h]); //C
		array = array.concat(["L",x+r4,y+h, "Q",x,y+h, x,y+h-r4, "Z"]); //D
		return this.path(array);
	};
	
	var mouseScrollAnim = document.getElementById('mouse-scroll-anim')
	var paper = Raphael(mouseScrollAnim, 60, 95);
	
	var mouseOuter = paper.roundedRectangle(3, 3, 54, 88, 30, 30, 30, 30);
	mouseOuter.attr("stroke", "#a51d13");
	mouseOuter.attr("stroke-width", 6);
	
	var wheel = paper.roundedRectangle(27, 25, 6, 12, 3, 3, 3, 3);
	wheel.attr("stroke-width", 0);
	wheel.attr("fill", "#a51d13");
	wheel.attr("stroke", "#a51d13");
	
	animOut();
	
	function animOut(){
		wheel.animate({ stroke: "#a51d13", "stroke-width": 7, "stroke-opacity": 1}, 1000, "<>", animIn);
	}
	
	function animIn(){
		wheel.animate({ stroke: "#a51d13", "stroke-width": 0, "stroke-opacity": 1}, 1000, "<>", animOut);
	}
	
	setInterval(function(){
		var doc = document.documentElement;
		var top = (window.pageYOffset || doc.scrollTop)  - (doc.clientTop || 0);
		$("header .logo svg").css({"transform":"rotate("+(top/3)+"deg)"})
		if(top > 3){
			$("header").addClass("header-is-red");
		}else{
			$("header").removeClass("header-is-red");
		}
	}, 50);
	
	/* features anims */

	var featureMarkerPos = [{"xpos":94,"ypos":199.015625},{"xpos":98,"ypos":213.015625},{"xpos":92,"ypos":202.015625},{"xpos":76,"ypos":202.015625},{"xpos":115,"ypos":173.015625},{"xpos":124,"ypos":177.015625},{"xpos":119,"ypos":160.015625},{"xpos":112,"ypos":157.015625},{"xpos":162,"ypos":131.015625},{"xpos":161,"ypos":71.015625},{"xpos":158,"ypos":67.015625},{"xpos":151,"ypos":48.015625},{"xpos":154,"ypos":55.015625},{"xpos":149,"ypos":49.015625},{"xpos":69,"ypos":220.015625},{"xpos":65,"ypos":211.015625}];
	var featureMarkers = [];
	function makeMap(){
		var numMarkers = featureMarkerPos.length;
		for(var t=0; t<numMarkers; t++){
			
			var img = "<img class='feature-map-marker' src='img/feature-map-marker.png' style='left:"+featureMarkerPos[t].xpos+"px; top:"+featureMarkerPos[t].ypos+"px;' />";
			$("#FeatureMap").append(img);
			featureMarkers.push($("#FeatureMap img:last-child"));
			
			featureMarkers[t].addClass("marker-hidden");
			featureMarkers[t].sizeIt = function(){
				var img = featureMarkers[t];
				setInterval(function(){
					if(img.hasClass("marker-hidden")){
						img.removeClass("marker-hidden");
					}else{
						img.addClass("marker-hidden");
					}
				}, Math.random()*3000 + 2000);
			}
			
			featureMarkers[t].sizeIt();
		}
	}
	
	
	var points = [];
	$('#FeatureMap').click(function (e) { //Relative ( to its parent) mouse position 
		var pos = [];
        var posX = $(this).position().left;
        var posY = $(this).position().top;
        
        points.push({xpos: e.pageX - posX, ypos: e.pageY - posY});
    });
	
	makeMap();
	
	/* caleneder */
	var cd = 1000;
	$(".feature-calender-tick").each(function(){
		var m = $(this);

		setTimeout(function(){
			setInterval(function(){
				if(m.hasClass("show")){
					m.removeClass("show");
				}else{
					m.addClass("show");
				}
			}, 2000);
		}, cd);
		cd += 400;
		
	});
	
	/* piggy */
	var cd = 1000;
	$(".feature-piggy-money").each(function(){
		var m = $(this);
		setTimeout(function(){
			setInterval(function(){
				var f = Math.random()*1;
				if(m.hasClass("in")){
					m.removeClass("in");
				}else{
					m.addClass("in");
				}
				m.removeClass("rot-neg");
				m.removeClass("rot-pos");
				if(f > .5){
					m.addClass("rot-neg");
				}else{
					m.addClass("rot-pos");
				}
			}, 2000);
		}, cd);
		cd += 500;
		
	});
	
	/* tech */
	$(".feature-key").each(function(){
		var m = $(this);
		var reset = Math.random()*800 + 100;
		setInterval(function(){
			if(m.hasClass("off")){
				m.removeClass("off");
			}else{
				m.addClass("off");
			}
			reset = Math.random()*800 + 100;
		}, reset);
		
	});
	
	
});
