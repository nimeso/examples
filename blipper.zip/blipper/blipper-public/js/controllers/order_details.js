blipperControllers.controller('OrderDetails_Controller', function($scope, $routeParams, $window, $route, $templateCache, $uibModal, $timeout, $http, uiGmapIsReady, baseURL, assetsURL, blipperAPI, Upload) {

	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;
	
	$scope.$parent.dashboardClass = "";
	$scope.$parent.billboardFinderClass = "";
	
	$scope.paymentSuccess = false;

	if($routeParams.paymentsuccess){
		$scope.paymentSuccess = true;
	}
	
	blipperAPI.getOrderByReferance($routeParams.ID).then(function(data){
		$scope.order = data.data[0];
		$scope.order.items = [];
		for(var t=0; t<$scope.order.OrderItems.length; t++){
			blipperAPI.getOrderItem($scope.order.OrderItems[t]).then(function(data){
				$scope.order.items.push(data.data);
				$scope.pageLoading = false;
				$scope.$parent.pageLoading = false;
			});
		}
	});
	
	$scope.closeSuccessMessage = function(){
		$scope.paymentSuccess = false;
	}

});