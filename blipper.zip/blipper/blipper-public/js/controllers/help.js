blipperControllers.controller('Help_Controller', function($scope, $routeParams, $window, $route, $templateCache, $uibModal, $timeout, $http, uiGmapIsReady, baseURL, assetsURL, blipperAPI, Upload) {

	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;
	
	$scope.$parent.dashboardClass = "";
	$scope.$parent.billboardFinderClass = "";
	
	$timeout(function(){
		$scope.pageLoading = false;
		$scope.$parent.pageLoading = false;
	}, 500);

});