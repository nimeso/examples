blipperControllers.controller('AdvertDetails_Controller', function($scope, $sce, $routeParams, $location, $route, $templateCache, $uibModal, $timeout, $http, baseURL, memberID, assetsURL, blipperAPI, Upload) {

	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;
	
	$scope.$parent.dashboardClass = "active";
	$scope.$parent.billboardFinderClass = "";
	
	$scope.$parent.helpHeading = "Manage and book this media item";
	$scope.$parent.helpContent = "This is where you can rename or change your media. Once your happy with it start finding billboards to book by clicking the big red button below.";

	$scope.percentUploaded = 0;
	$scope.canCrop = false;
	$scope.canCropNum = 0;
	
	$scope.$on("cropme:loaded", function(ev, width, height, cropmeEl) { 
		if($scope.canCropNum == 0){
			$scope.canCropNum ++;
		}else{
			console.log("bad cropper!!!");
			$scope.canCrop = true;
		}
		
	});
	
	$scope.$on("cropme:done", function(ev, result, cropmeEl) {
		var blob = result.croppedImage;
       
		var xhr = new XMLHttpRequest;
        xhr.upload.onprogress = $scope.updateProgress;
        xhr.open("POST", assetsURL+'/home/uploadcropped', true);
        xhr.setRequestHeader("Content-Type", blob.type);
        
        xhr.onreadystatechange = function(e) {
        	console.log(this.responseText);
            if (this.readyState === 4 && this.status === 200) {	
            	
            	var r = JSON.parse(this.responseText);
            	if(r.ID){
            		$scope.canCropNum = 0;
            		$scope.canCrop = false;
            		console.log("turn off cropper - should be first!!!");
            		$scope.mediaItem.ImageMediaID = r.ID;
	            	blipperAPI.getResizedImage($scope.mediaItem.ImageMediaID,"width",1280,100).then(function(dataBack){
	            		//$scope.currentImage = dataBack.url;
	            		console.log(dataBack.url);
	            		$scope.currentImage = $sce.trustAsResourceUrl(dataBack.url);
	            		$scope.percentUploaded = 0;
	            	});
            	}
            } else if (this.readyState === 4 && this.status !== 200) {
                return console.log("failed");
            }
        };
       
        xhr.send(blob);
	});
	
	$scope.updateProgress = function(evt) {
	   if (evt.lengthComputable) {  
		   $scope.$apply(function() { 
			   var p = parseInt((evt.loaded / evt.total)*100);
			   if(p != 100){
				   $scope.percentUploaded = p;
				   console.log($scope.percentUploaded);
			   }
		   });
	   }
	} 
	
	/* image view */
	$scope.imagePreviewClass = "active";
	$scope.imageChangeClass = "";
	
	$scope.toggleView = function(){
		console.log("changed");
		if($scope.imagePreviewClass == "active"){
			$scope.imagePreviewClass = "";
			$scope.imageChangeClass = "active";
		}else{
			$scope.imagePreviewClass = "active";
			$scope.imageChangeClass = "";
		}
	}
	
	blipperAPI.getMediaItem($routeParams.ID).then(function(data){
		
		$scope.mediaItem = data;
		$scope.mainImage = $scope.mediaItem.MainImage;
		
		$scope.currentImage = $sce.trustAsResourceUrl($scope.mediaItem.PreviewImage);

		$timeout(function(){
			$scope.pageLoading = false;
			$scope.$parent.pageLoading = true;
		}, 500);
		
	});
	
	$scope.confirmUpdatedFileChange = function () {

	    var modal = $uibModal.open({
	      size: "sm",
	      animation: false,
	      templateUrl: 'fileupdate.html',
	      controller: 'ModalUpdateFileCtrl',
	      resolve: {
	    	  mediaItem: function () {
	            return $scope.mediaItem;
	          },
	    		pageLoading: function () {
	    			return $scope.pageLoading;
	    		}
	       }
	    }); 
	}
	
	blipperAPI.getTimeSlotsByMediaItem($routeParams.ID).then(function(data){
		console.log(data);
		$scope.timeSlots = data;
	});

	
	$scope.cancel = function(){
		var currentPageTemplate = $route.current.templateUrl;
		$templateCache.remove(currentPageTemplate);
		$route.reload();
	}
	
	$scope.update = function(){
		if($scope.mediaItem.UpdatedFileID){
			$scope.confirmUpdatedFileChange();
		}else{
			$scope.pageLoading = true;
			blipperAPI.updateMediaItem($scope.mediaItem).then(function(data){
				$scope.pageLoading = false;
			});
		}
	}
	
	$scope.uploadMediaFile = function(mediaItem,errFiles) {
		
		if(mediaItem.UpdatedTempFile){
		
			$scope.mediaFilesLoading = true;
			$scope.showPreview = false;
			
			mediaItem.UpdatedTempFile.upload = Upload.upload({
                url: assetsURL+'/home/upload',
                data: {file: mediaItem.UpdatedTempFile}
            });
			
			mediaItem.UpdatedTempFile.upload.then(function (response) {
				
				mediaItem.UpdatedFileID = response.data;

				blipperAPI.getFile(mediaItem.UpdatedFileID).then(function(data){
					$scope.mediaFilesLoading = false;
        			$scope.showPreview = true;
        			$scope.mainImage = assetsURL + "/" + data.Filename;
				});

            }, function (response) {
                if (response.status > 0)
                $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
            	mediaItem.percentage = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
		}
		
	}
	
});

blipperControllers.controller('ModalUpdateFileCtrl', function ($scope, $location, $uibModalInstance, mediaItem, pageLoading, blipperAPI) {
	
	$scope.mediaItem = mediaItem;
	
	$scope.close = function () {
		$uibModalInstance.close();
	};
	
	$scope.ok = function(){
		console.log("yes sending");
		console.log($scope.mediaItem.ID);
		
		blipperAPI.updateMediaItem($scope.mediaItem).then(function(data){
			console.log(data); // todo: need to update the UpdatedBigListingImage in main scope and refresh image
			$scope.mediaItem = data;
		});
		
		$uibModalInstance.close();
	}
	  
});