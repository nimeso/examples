blipperControllers.controller('Checkout_Controller', function($scope, $routeParams, $window, $route, $templateCache, $uibModal, $timeout, $http, uiGmapIsReady, baseURL, assetsURL, blipperAPI, Upload) {

	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;
	
	$scope.$parent.dashboardClass = "";
	$scope.$parent.billboardFinderClass = "";
	
	$scope.paymentfailed = false;
	if($routeParams.paymentfailed){
		$scope.paymentfailed = true;
	}
	
	$timeout(function(){
		$scope.pageLoading = false;
		$scope.$parent.pageLoading = false;
	}, 500);
	
	$scope.closeFailedMessage = function(){
		$scope.paymentfailed = false;
	}
	
});