blipperControllers.controller('Profile_Controller', function($scope, $cookies, $routeParams, $window, $route, $templateCache, $uibModal, $timeout, $http, uiGmapIsReady, baseURL, assetsURL, blipperAPI, memberID, Upload) {

	$scope.$parent.dashboardClass = "";
	$scope.$parent.billboardFinderClass = "";
	
	$scope.pageLoading = true;
	
	
	$timeout(function(){
		$scope.pageLoading = false;
		$scope.$parent.pageLoading = false;
	}, 500);
	
	$scope.submitProfileForm = function() {

		var simpleMember = {
			"ID": $scope.$parent.member.ID,
			"FirstName": $scope.$parent.member.FirstName,
			"Surname": $scope.$parent.member.Surname
		};
		blipperAPI.updateMember(simpleMember).then(function(data){
			console.log(data);
			//$scope.$parent.member = data.data;
		});
	};

});