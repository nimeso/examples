blipperControllers.controller('Account_Controller', function($scope, $routeParams, $window, $route, $templateCache, $uibModal, $timeout, $http, uiGmapIsReady, baseURL, assetsURL, blipperAPI, Upload) {

	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;
	$scope.pageloadCount = 0;
	
	$scope.$parent.dashboardClass = "";
	$scope.$parent.billboardFinderClass = "";
	
	$scope.readyToShow = function(){
		$scope.pageloadCount ++;
		if($scope.pageloadCount == 3){
			$scope.pageLoading = false;
			$scope.$parent.pageLoading = false;
		}
	}
	
	blipperAPI.getPendingOrders().then(function(data){
		$scope.readyToShow();
		$scope.pendingOrders = data.data;
	});
	
	blipperAPI.getCompletedOrders().then(function(data){
		$scope.readyToShow();
		$scope.completedOrders = data.data;
	});
	
	blipperAPI.getCancelledOrders().then(function(data){
		$scope.readyToShow();
		$scope.cancelledOrders = data.data;
	});

});