blipperControllers.controller('AdvertBook_Controller', function($scope, $cookies, $filter, $routeParams, $location, $route, $templateCache, $uibModal, $timeout, $http, memberID, uiGmapIsReady, baseURL, assetsURL, blipperAPI, Upload) {
	
	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;

	$scope.showingMapView = true;
	$scope.showingGridView = false;
	
	$scope.$parent.dashboardClass = "active";
	$scope.$parent.billboardFinderClass = "";
	
	$scope.$parent.helpHeading = "Finding billboards to book";
	$scope.$parent.helpContent = "Now your happy with your media it's time to find some cool billboards to book! Click on the map markers to view each billboard loactions details, photos and statistics but most importantly where you can book the billboard.";

	if(!$cookies.get('blipparDeviceView')){
		$cookies.put('blipparDeviceView', 'map');
	}
	
	$scope.toggleView = function(){
		if($cookies.get('blipparDeviceView') == 'map'){
			$cookies.put('blipparDeviceView', 'list');
			$scope.showingMapView = false;
			$scope.showingGridView = true;
		}else{
			$cookies.put('blipparDeviceView', 'map');
			$scope.showingMapView = true;
			$scope.showingGridView = false;
		}
		$scope.updateMapFilter();
	}
	
	if($cookies.get('blipparDeviceView') == 'list'){
		$scope.showingMapView = false;
		$scope.showingGridView = true;
	}else{
		$scope.showingMapView = true;
		$scope.showingGridView = false;
	}
	
	blipperAPI.getMediaItem($routeParams.ID).then(function(data){
		
		$scope.mediaItem = data;
		$scope.mainImage = $scope.mediaItem.MainImage;
		
		blipperAPI.getDevices().then(function(data){
			$scope.devices = data;
			
			for(var p=0; p<$scope.devices.length; p++){
				var imgs = "";
				
				if(($scope.devices[p].ResizedImages) && $scope.devices[p].ResizedImages.length > 0){
					for(var g=0; g<$scope.devices[p].ResizedImages.length; g++){
						imgs += $scope.devices[p].ResizedImages[g]+",";
					}
				}
				
				$scope.devices[p].images = imgs;
			}
			
			console.log($scope.devices);
			$scope.createMap();
		});
		
		$timeout(function(){
			$scope.pageLoading = false;
			$scope.$parent.pageLoading = false;
		}, 500);
		
	});
	
	$scope.markerClick = function(marker){
		
		console.log(marker);

		$location.path("book-device/"+marker.model.id+"/"+$scope.mediaItem.ID);
		/*
		 var modal = $uibModal.open({
		      size: "lg",
		      animation: false,
		      scope: $scope,
		      templateUrl: 'devicedetails.html',
		      controller: 'ModalDeviceDetailsCtrl',
		      resolve: {
		    	  device: function () {
		            return marker.model;
		          },
		          mediaItem: function () {
		            return $scope.mediaItem;
		          }
		       }
		 }); 
		 */
	}
	
	$scope.openDevice = function(device){

		var newDevice = {
				id: device.ID,
		        title: device.Title,
		        location: device.Location,
		        cost: device.Cost,
		        description: device.Description,
		        totalScreens: device.TotalScreens,
		        mediaWidth: device.MediaWidth,
		        mediaHeight: device.MediaHeight,
		        trafficRating: device.TrafficRating,
		        images: device.images
		};

		 var modal = $uibModal.open({
		      size: "lg",
		      animation: false,
		      scope: $scope,
		      templateUrl: 'devicedetails.html',
		      controller: 'ModalDeviceDetailsCtrl',
		      resolve: {
		    	  device: function () {
		            return newDevice;
		          },
		          mediaItem: function () {
		            return $scope.mediaItem;
		          }
		       }
		 }); 
	}

	$scope.createMap = function(){
		
		if( typeof _.contains === 'undefined' ) {
	      _.contains = _.includes;
	    }
	    if( typeof _.object === 'undefined' ) {
	      _.object = _.zipObject;
		}
	    
	    var styleArray = [{"elementType":"geometry","stylers":[{"hue":"#ff4400"},{"saturation":-68},{"lightness":-4},{"gamma":0.72}]},{"featureType":"road","elementType":"labels.icon"},{"featureType":"landscape.man_made","elementType":"geometry","stylers":[{"hue":"#0077ff"},{"gamma":3.1}]},{"featureType":"water","stylers":[{"hue":"#00ccff"},{"gamma":0.44},{"saturation":-33}]},{"featureType":"poi.park","stylers":[{"hue":"#44ff00"},{"saturation":-23}]},{"featureType":"water","elementType":"labels.text.fill","stylers":[{"hue":"#007fff"},{"gamma":0.77},{"saturation":65},{"lightness":99}]},{"featureType":"water","elementType":"labels.text.stroke","stylers":[{"gamma":0.11},{"weight":5.6},{"saturation":99},{"hue":"#0091ff"},{"lightness":-86}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"lightness":-48},{"hue":"#ff5e00"},{"gamma":1.2},{"saturation":-23}]},{"featureType":"transit","elementType":"labels.text.stroke","stylers":[{"saturation":-64},{"hue":"#ff9100"},{"lightness":16},{"gamma":0.47},{"weight":2.7}]}];

	     $scope.options = {
	        styles: styleArray,
	        scrollwheel: false,
	        maxZoom: 12,
	        minZoom: 3
	     };



		angular.extend($scope, {
		    map: {
		      //control: {},
		      center: {
		        latitude: 45,
		        longitude: -73
		      },
		      options: {
		        panControl: false,
		        maxZoom: 20,
		        minZoom: 3
		      },
		      zoom: 3,
		      dragging: false,
		      //bounds: {},
		      markerEvents: {
		        click:function(gMarker, eventName, model){
		          model.doShow = true;
		      }
		    }}
		  });

		return;

		
		
		 var createMarker = function(marker, idKey) {

		      if (idKey == null) {
		        idKey = "id";
		      }

		      var ret = {
		    	id: marker.ID,
		        latitude: marker.Lat,
		        longitude: marker.Lng,
		        title: marker.Title,
		        location: marker.Location,
		        cost: marker.Cost,
		        description: marker.Description,
		        totalScreens: marker.TotalScreens,
		        mediaWidth: marker.MediaWidth,
		        mediaHeight: marker.MediaHeight,
		        trafficRating: marker.TrafficRating,
		        icon: "img/marker_"+marker.TrafficRating+".png"
		        
		      };
		      
		      
		      if(marker.ResizedImages){
		    	  
		    	  ret.images = "";
		    	  imgs = "";
		    	  var l = marker.ResizedImages.length;
		    	  for(var t=0; t<l; t++){
		    		  imgs += marker.ResizedImages[t]+",";
		    		  ret.images = imgs;
			      }
		      }
		      ret[idKey] = marker.ID;
		      return ret;
		};
		
	    
	    $scope.map.markers = [];
	    
	    // Get the bounds from the map once it's loaded
	    $scope.$watch(function() {
	    	return $scope.map.bounds;
	    }, function(nv, ov) {
	    	// Only need to regenerate once
	    	if (!ov.southwest && nv.southwest) {
	    		var markers = [];
	    		
	    		for (var i = 0; i < $scope.devices.length; i++) {
	    			markers.push(createMarker($scope.devices[i]))
	    		}
	    		$scope.map.markers = markers;
	    		$scope.filteredMarkers = markers;
	    		
	    	}
	    }, true);

	}
	
	$scope.updateMapFilter = function(){
		if($scope.mapquery.length > 2){
			$scope.filteredMarkers = $filter("filter")($scope.map.markers, $scope.mapquery);
		}else{
			$scope.filteredMarkers = $scope.map.markers;
		}
		console.log($scope.filteredMarkers);
	}

});

blipperControllers.controller('ModalDeviceDetailsCtrl', function ($rootScope, $scope, $location, $controller, $uibModalInstance, $uibModal, device, mediaItem, blipperAPI) {

	$scope.device = device;
	$scope.mediaItem = mediaItem;
	$scope.bookingDone = false;
	
	$scope.modalAddItemToOrder = function(device,mediaItem,startDate,endDate,weeks){
		$scope.addItemToOrder(device,mediaItem,startDate,endDate,weeks,$scope.modalOrderUpdated);
		$scope.weeks = null;
		$scope.startDate = null;
		$scope.bookingDone = true;
	}
	
	$scope.gotoCheckout = function(){
		$uibModalInstance.close();
		$location.path("cart");
	}
	
	$scope.modalOrderUpdated = function(){
		console.log("COMPLETED");
	}
	
	console.log($scope.device);
	
	if(device.images){
		var images = device.images.split(",");
		images.pop();
	
		var newImages = [];
		for(var t=0; t<images.length; t++){
			if(t == 0){
				newImages.push(
					{
						"url":images[t],
						"index":t,
						"class":"active"
					}
				);
			}else{
				newImages.push(
					{
						"url":images[t],
						"index":t,
						"class":"not"
					}
				);
			}
		}
		$scope.newImages = newImages;
	}
	
	 $('.carousel').carousel({
         interval: 5000,
         pause: "hover",
         wrap: true
     })
     .on('click', '.carousel-control', handle_nav);
		var handle_nav = function(e) {
		 e.preventDefault();
		 var nav = $(this);
		 nav.parents('.carousel').carousel(nav.data('slide'));
	 }

	$scope.getWeeks = function(i){	
		if(i == 1){
			return "Week";
		}else{
			return "Weeks";
		}
	}
	
	/* start date */
	$scope.format = 'dd MMMM yyyy';
	
	$scope.open = function() {
	    $scope.popup.opened = true;
	};
	
	// Disable weekend selection
	$scope.disabled = function(date, mode) {
	    return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
	};
	
	$scope.popup = {
		opened: false
	};
	
	$scope.nextWeek = function(num) {
		
		console.log($scope.startDate);
		
		if($scope.startDate){
			console.log("yes = "+num);
			var firstDay = $scope.startDate;
			$scope.endDate = new Date(firstDay.getTime() + (num * 7) * 24 * 60 * 60 * 1000);
		}
	}
	
	
	
	  
});


angular.module('blipper')
.filter('range', function(){
  return function(n) {
    var res = [];
    for (var i = 1; i <= n; i++) {
      res.push(i);
    }
    return res;
  };
});