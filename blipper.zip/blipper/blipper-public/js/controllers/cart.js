blipperControllers.controller('Cart_Controller', function($scope, $routeParams, $window, $route, $templateCache, $uibModal, $timeout, $http, uiGmapIsReady, baseURL, assetsURL, blipperAPI, Upload) {

	//$scope.pageLoading = true;
	$scope.pageLoading = true;
	$scope.$parent.pageLoading = true;
	
	$scope.$parent.dashboardClass = "";
	$scope.$parent.billboardFinderClass = "";

	$timeout(function(){
		$scope.pageLoading = false;
		$scope.$parent.pageLoading = false;
	}, 500);

	$scope.openDeleteModal = function (orderItem) {
		
		$scope.orderItem = orderItem;

	    var deleteModal = $uibModal.open({
	      size: "sm",
	      animation: false,
	      templateUrl: 'deleteitem.html',
	      controller: 'OrderItemDeleteCtrl',
	      resolve: {
	    	  orderItem: function () {
	            return $scope.orderItem;
	          },
	          orderItems: function () {
		         return $scope.PreviewOrderItems;
		      }
	       }
	    });

	}
	
	  
});

blipperControllers.controller('OrderItemDeleteCtrl', function ($scope, $uibModalInstance, orderItem, orderItems, blipperAPI) {
	
	$scope.orderItem = orderItem;
	$scope.orderItems = orderItems;
	
	  $scope.ok = function () {
		  
		  var index = $scope.orderItems.indexOf(orderItem);

		  //todo: not working
		  $scope.orderItems.splice(index, 1);
		  
		  $uibModalInstance.close();
		  blipperAPI.deleteOrderItem($scope.orderItem).then(function(data){
			  
		  });
	  };

	  $scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	  };
});