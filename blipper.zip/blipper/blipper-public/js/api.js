blipper.factory('blipperAPI', function($http, $cookies, baseURL, assetsURL, memberID) {
	
	return{
		//variables & strings
		
		
		baseURL:assetsURL,
		assetsURL:assetsURL,
		
		login:login,
		logout:logout,
		
		getDevices:getDevices,
		getDevicesByPlaylist:getDevicesByPlaylist,
		getDevice:getDevice,
		updateDevice:updateDevice,
		deleteDevice:deleteDevice,
		deleteDeviceImage:deleteDeviceImage,
		
		getFile:getFile,
		
		getMediaItems:getMediaItems,
		getCurrentPlayingMediaItems:getCurrentPlayingMediaItems,
		
		getMediaItem:getMediaItem,
		updateMediaItem:updateMediaItem,
		deleteMediaItem:deleteMediaItem,
		
		getTimeSlotsByPlayList:getTimeSlotsByPlayList,
		getTimeSlotsByMediaItem:getTimeSlotsByMediaItem,
		updateTimeSlot:updateTimeSlot,
		deleteTimeSlot:deleteTimeSlot,
		
		getPlaylists:getPlaylists,
		getPlaylist:getPlaylist,
		updatePlaylist:updatePlaylist,
		deletePlaylist:deletePlaylist,
		
		updateFile:updateFile,
		
		getImage:getImage,
		getResizedImage:getResizedImage,
		
		getMember:getMember,
		updateMember:updateMember,
		createMember:createMember,
		memberCheck:memberCheck,
		createMemberWithToken:createMemberWithToken,
		
		getPendingOrders: getPendingOrders,
		getCompletedOrders: getCompletedOrders,
		getCancelledOrders: getCancelledOrders,
		getOrder:getOrder,
		updateOrder:updateOrder,
		getOrderItem:getOrderItem,
		getOrderByReferance:getOrderByReferance,
		updateOrderItem:updateOrderItem,
		deleteOrderItem:deleteOrderItem,

		buy:buy,
		
		mailTo:mailTo
	}
	
	function mailTo(to,from,subject,body){
		
		var data = {
			to: to,
			from: from,
			subject: subject,
			body: body
		};
		
		console.log(data);
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'MailTo',
		        'method': 'POST',
		        'data': JSON.stringify(data),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function login(email,pwd){
		return $http({
			'url': baseURL+'auth/login?email='+email+'&pwd='+pwd,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function logout(email){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'auth/logout?email='+email,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function buy(data){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Buy?token='+$cookies.get('blipparMemberToken'),
		        'method': 'POST',
		        'data': JSON.stringify(data),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getMember(){

		console.log("MEMBER LOAD");

		if($cookies.get('blipparMemberToken')){
			console.log($cookies.get('blipparMemberToken'));
			return $http({
				'url': baseURL+'Member?ApiToken='+$cookies.get('blipparMemberToken'),
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		
			function getDataComplete(response) {
				return response;
			}
		
			function getDataFailed(error) {
			    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
			}
		}
		
	}
	
	function updateMember(member){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			
			if(member.ID){
				var method = "PUT";
				var url = baseURL+'Member/'+$cookies.get('blipparMemberID');
			}else{
				method = "POST";
				url = baseURL+'Member/';
			}

			return $http({
				'url': url,
		        'method': method,
		        'data': JSON.stringify(member),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
			
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function createMember(member){

		method = "POST";
		url = assetsURL+'/home/createMember';

		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(member),
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
			
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function createMemberWithToken(member){

		method = "POST";
		url = assetsURL+'/home/createMemberFromGoogle';

		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(member),
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
			
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function memberCheck(email){
		
		var data = {"email":email};
		
		method = "POST";
		url = assetsURL+'/home/membercheck';

		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(data),
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
			
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function getPendingOrders(){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Order?MemberID='+$cookies.get('blipparMemberID')+'&Status=Pending',
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getCompletedOrders(){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Order?MemberID='+$cookies.get('blipparMemberID')+'&Status=Completed',
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			console.log(response);
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getCancelledOrders(){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Order?MemberID='+$cookies.get('blipparMemberID')+'&Status=Cancelled',
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getOrderByReferance(Referance){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Order?MemberID='+$cookies.get('blipparMemberID')+'&Referance='+Referance,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getOrder(){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Order?MemberID='+$cookies.get('blipparMemberID')+'&Status=Created',
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function updateOrder(order){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			if(order.ID){
				var method = "PUT";
				var url = baseURL+'Order/'+order.ID;
			}else{
				method = "POST";
				url = baseURL+'Order/';
			}
	
			return $http({
				'url': url,
		        'method': method,
		        'data': JSON.stringify(order),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function getOrderItem(orderItemID){
		
		if($cookies.get('blipparMemberToken')){
			return $http({
				'url': baseURL+'OrderItem/'+orderItemID,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
			return response;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updateOrderItem(orderItem){
		
		console.log(orderItem);
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			if(orderItem.ID){
				var method = "PUT";
				var url = baseURL+'OrderItem/'+orderItem.ID;
			}else{
				method = "POST";
				url = baseURL+'OrderItem/';
			}
	
			return $http({
				'url': url,
		        'method': method,
		        'data': JSON.stringify(orderItem),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function deleteOrderItem(orderItem){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'OrderItem/'+orderItem.ID,
		        'method': 'DELETE',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        },
		        'data': JSON.stringify(orderItem)
	    	}).then(getDataComplete).catch(getDataFailed);
		}

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getResizedImage(fileID, method, width, height){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'ResizedImage/'+fileID+'?ResizeMethod='+method+'&Width='+width+'&Height='+height,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
		
		function getDataComplete(response) {
			return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getImage(fileID){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': assetsURL+'/home/image?fileid='+fileID,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {

		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getTimeSlotsByPlayList(playlistID){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'TimeSlot?PlaylistID='+playlistID,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getTimeSlotsByMediaItem(mediaItemID){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'TimeSlot?MediaItemID='+mediaItemID,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	

	function updateTimeSlot(timeSlot){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			if(timeSlot.ID){
				var method = "PUT";
				var url = baseURL+'TimeSlot/'+timeSlot.ID;
			}else{
				method = "POST";
				url = baseURL+'TimeSlot/';
			}
			
			return $http({
				'url': url,
		        'method': method,
		        'data': JSON.stringify(timeSlot),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function deleteTimeSlot(timeSlot){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'TimeSlot/'+timeSlot.ID,
		        'method': 'DELETE',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        },
		        'data': JSON.stringify(timeSlot)
	    	}).then(getDataComplete).catch(getDataFailed);
		}

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getDevices(){
		
		//2e0623a050452766955bdeHRd.j.TWftahVdOwjLVVE1Wn/SSIl86
		
		//if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': assetsURL+'/home/devices',
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json'
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		//}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getDevicesByPlaylist(playlistID){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Device?PlaylistID='+playlistID,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getDevice(id){
		
		//if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': assetsURL+'/home/device/'+id,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json'
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		//}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updateDevice(device){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			if(device.ID){
				var method = "PUT";
				var url = baseURL+'Device/'+device.ID;
			}else{
				method = "POST";
				url = baseURL+'Device/';
			}
			
			if(device.selectedPlaylist){
				device.Playlist = device.selectedPlaylist.ID;
			}

			return $http({
				'url': url,
		        'method': method,
		        'data': JSON.stringify(device),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function clone(obj) {
	    if (null == obj || "object" != typeof obj) return obj;
	    var copy = obj.constructor();
	    for (var attr in obj) {
	        if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
	    }
	    return copy;
	}
	
	function deleteDevice(device){
		return $http({
			'url': baseURL+'Device/'+device.ID,
	        'method': 'DELETE',
	        'headers': {
	        	'Content-Type': 'application/json',
	        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
	        },
	        'data': JSON.stringify(device)
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function deleteDeviceImage(file){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'File/'+file.ID,
		        'method': 'DELETE',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getFile(id){

		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'File/'+id,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updateFile(file){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'File/'+file.ID,
		        'method': 'PUT',
		        'data': JSON.stringify(file),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getMediaItems(){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'MediaItem?MemberID='+$cookies.get('blipparMemberID'),
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getCurrentPlayingMediaItems(memberID){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'MediaItem?MemberID='+$cookies.get('blipparMemberID'),
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getMediaItem(id){

		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'MediaItem/'+id,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updateMediaItem(mediaItem){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			
			mediaItem.MemberID = $cookies.get('blipparMemberID'); //todo:
			
			if(mediaItem.TempFile){
				mediaItem.TempFile = null;
			}
			
			if(mediaItem.UpdatedTempFile){
				mediaItem.UpdatedTempFile = null;
			}
			
			if(mediaItem.ID){
				var method = "PUT";
				var url = baseURL+'MediaItem/'+mediaItem.ID;
			}else{
				method = "POST";
				url = baseURL+'MediaItem/';
			}
			
			return $http({
				'url': url,
		        'method': method,
		        'data': JSON.stringify(mediaItem),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function deleteMediaItem(mediaItem){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'MediaItem/'+mediaItem.ID,
		        'method': 'DELETE',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        },
		        'data': JSON.stringify(mediaItem)
	    	}).then(getDataComplete).catch(getDataFailed);
		}

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	/* playlists */
	
	function getPlaylists(){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Playlist/',
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getPlaylist(id){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Playlist/'+id,
		        'method': 'GET',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updatePlaylist(playlist){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			
			if(playlist.ID){
				var method = "PUT";
				var url = baseURL+'Playlist/'+playlist.ID;
			}else{
				method = "POST";
				url = baseURL+'Playlist/';
			}
			
			if(playlist.selectedDevices){
				var devices = [];
				for(var t=0; t<playlist.selectedDevices.length; t++){
					devices.push(playlist.selectedDevices[t].ID);
				}
				playlist.Devices = devices;
			}

			return $http({
				'url': url,
		        'method': method,
		        'data': JSON.stringify(playlist),
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        }
	    	}).then(getDataComplete).catch(getDataFailed);
		}
			
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function deletePlaylist(playlist){
		
		if($cookies.get('blipparMemberToken') && $cookies.get('blipparMemberID')){
			return $http({
				'url': baseURL+'Playlist/'+playlist.ID,
		        'method': 'DELETE',
		        'headers': {
		        	'Content-Type': 'application/json',
		        	'X-Silverstripe-Apitoken': $cookies.get('blipparMemberToken')
		        },
		        'data': JSON.stringify(playlist)
	    	}).then(getDataComplete).catch(getDataFailed);
		}

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
});

angular.module('app.core.blipperErrorHandler', [
	'blipper'
])

//Just console log for now, later we can add more functionality to communicate with unity, analytics etc.
.factory('blipperErrorHandler', function(){
	return{
		error: function(msg,error){
			console.log(msg);
			console.log(error);
		}
	}
})