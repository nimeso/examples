'use strict';

/* Directives */