blipper.factory('blipperAPI', function($http, baseURL, assetsURL) {
	
	return{
		//variables & strings
		baseURL:assetsURL,
		assetsURL:assetsURL,
		
		getDevices:getDevices,
		getDevicesByPlaylist:getDevicesByPlaylist,
		getDevice:getDevice,
		updateDevice:updateDevice,
		deleteDevice:deleteDevice,
		deleteDeviceImage:deleteDeviceImage,
		
		getFile:getFile,
		
		getMediaItems:getMediaItems,
		getMediaItem:getMediaItem,
		updateMediaItem:updateMediaItem,
		deleteMediaItem:deleteMediaItem,
		
		getTimeSlotsByPlayList:getTimeSlotsByPlayList,
		updateTimeSlot:updateTimeSlot,
		deleteTimeSlot:deleteTimeSlot,
		
		getPlaylists:getPlaylists,
		getPlaylist:getPlaylist,
		updatePlaylist:updatePlaylist,
		deletePlaylist:deletePlaylist,
		
		updateFile:updateFile
	}
	
	function getTimeSlotsByPlayList(playlistID){
		return $http({
			'url': baseURL+'TimeSlot?PlaylistID='+playlistID,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	

	function updateTimeSlot(timeSlot){
		
		if(timeSlot.ID){
			var method = "PUT";
			var url = baseURL+'TimeSlot/'+timeSlot.ID;
		}else{
			method = "POST";
			url = baseURL+'TimeSlot/';
		}
		
		console.log(timeSlot);
		
		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(timeSlot),
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function deleteTimeSlot(timeSlot){
		return $http({
			'url': baseURL+'TimeSlot/'+timeSlot.ID,
	        'method': 'DELETE',
	        'headers': {
	        	'Content-Type': 'application/json'
	        },
	        'data': JSON.stringify(timeSlot)
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getDevices(){
		return $http({
			'url': baseURL+'Device/',
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getDevicesByPlaylist(playlistID){
		return $http({
			'url': baseURL+'Device?PlaylistID='+playlistID,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getDevice(id){
		return $http({
			'url': baseURL+'Device/'+id,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updateDevice(device){
		
		if(device.ID){
			var method = "PUT";
			var url = baseURL+'Device/'+device.ID;
		}else{
			method = "POST";
			url = baseURL+'Device/';
		}
		
		if(device.selectedPlaylist){
			device.Playlist = device.selectedPlaylist.ID;
		}
		
		console.log(device);
		
		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(device),
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function clone(obj) {
	    if (null == obj || "object" != typeof obj) return obj;
	    var copy = obj.constructor();
	    for (var attr in obj) {
	        if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
	    }
	    return copy;
	}
	
	function deleteDevice(device){
		return $http({
			'url': baseURL+'Device/'+device.ID,
	        'method': 'DELETE',
	        'headers': {
	        	'Content-Type': 'application/json'
	        },
	        'data': JSON.stringify(device)
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function deleteDeviceImage(file){
		
		return $http({
			'url': baseURL+'File/'+file.ID,
	        'method': 'DELETE',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getFile(id){
		console.log(id);
		return $http({
			'url': baseURL+'File/'+id,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updateFile(file){
		return $http({
			'url': baseURL+'File/'+file.ID,
	        'method': 'PUT',
	        'data': JSON.stringify(file),
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getMediaItems(){
		return $http({
			'url': baseURL+'MediaItem/',
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getMediaItem(id){
		return $http({
			'url': baseURL+'MediaItem/'+id,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updateMediaItem(mediaItem){
		
		console.log("before saved");
		console.log(mediaItem);
		
		if(mediaItem.ID){
			var method = "PUT";
			var url = baseURL+'MediaItem/'+mediaItem.ID;
		}else{
			method = "POST";
			url = baseURL+'MediaItem/';
		}
		
		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(mediaItem),
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function deleteMediaItem(mediaItem){
		return $http({
			'url': baseURL+'MediaItem/'+mediaItem.ID,
	        'method': 'DELETE',
	        'headers': {
	        	'Content-Type': 'application/json'
	        },
	        'data': JSON.stringify(mediaItem)
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	/* playlists */
	
	function getPlaylists(){
		return $http({
			'url': baseURL+'Playlist/',
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function getPlaylist(id){
		return $http({
			'url': baseURL+'Playlist/'+id,
	        'method': 'GET',
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
	function updatePlaylist(playlist){
		
		if(playlist.ID){
			var method = "PUT";
			var url = baseURL+'Playlist/'+playlist.ID;
		}else{
			method = "POST";
			url = baseURL+'Playlist/';
		}
		
		if(playlist.selectedDevices){
			var devices = [];
			for(var t=0; t<playlist.selectedDevices.length; t++){
				devices.push(playlist.selectedDevices[t].ID);
			}
			playlist.Devices = devices;
		}
		
		console.log(playlist);
		
		return $http({
			'url': url,
	        'method': method,
	        'data': JSON.stringify(playlist),
	        'headers': {
	        	'Content-Type': 'application/json'
	        }
    	}).then(getDataComplete).catch(getDataFailed);
	
		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
		
	}
	
	function deletePlaylist(playlist){
		return $http({
			'url': baseURL+'Playlist/'+playlist.ID,
	        'method': 'DELETE',
	        'headers': {
	        	'Content-Type': 'application/json'
	        },
	        'data': JSON.stringify(playlist)
    	}).then(getDataComplete).catch(getDataFailed);

		function getDataComplete(response) {
		    return response.data;
		}
	
		function getDataFailed(error) {
		    blipperErrorHandler.error('XHR Failed for getAppData.' + error.data);
		}
	}
	
});

angular.module('app.core.blipperErrorHandler', [
	'blipper'
])

//Just console log for now, later we can add more functionality to communicate with unity, analytics etc.
.factory('blipperErrorHandler', function(){
	return{
		error: function(msg,error){
			console.log(msg);
			console.log(error);
		}
	}
})