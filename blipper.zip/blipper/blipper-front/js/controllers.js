'use strict';

/* Controllers */
var blipperControllers = angular.module('blipperControllers', []);
