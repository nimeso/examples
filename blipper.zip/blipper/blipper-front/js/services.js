'use strict';

/* Services */
var blipperServices = angular.module('blipperServices', ['ngResource']);
