blipperControllers.controller('PlaylistsList_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, $uibModal, Upload, uiGmapIsReady, baseURL, assetsURL, blipperAPI) {
	
	blipperAPI.getPlaylists().then(function(data){
		$scope.playlists = data;
	});
	
	
	$scope.deletePlaylist = function(playlist){
		var index = $scope.playlists.indexOf(playlist);
		if (confirm("Are you sure you want to delete "+$scope.playlists[index].Title)) {
			blipperAPI.deletePlaylist(playlist);
			$scope.playlists.splice(index, 1);
		}
	}
	
});