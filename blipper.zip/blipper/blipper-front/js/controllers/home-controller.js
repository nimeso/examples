blipperControllers.controller('Home_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, $uibModal, Upload, uiGmapIsReady, baseURL, assetsURL, blipperAPI) {
	
});
