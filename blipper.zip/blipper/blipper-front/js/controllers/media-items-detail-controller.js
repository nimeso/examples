blipperControllers.controller('MediaItemsDetail_Controller', function($scope, $location, $routeParams, $timeout, $http, Upload, baseURL, assetsURL, blipperAPI) {

	blipperAPI.getMediaItem($routeParams.ID).then(function(data){
		$scope.mediaItem = data;
		console.log($scope.mediaItem);
		if($scope.mediaItem.File){
			blipperAPI.getFile($scope.mediaItem.File).then(function(data){
				console.log("PREVIEW IMAGE");
				$scope.mediaFilesLoading = false;
    			$scope.showPreview = true;
    			$scope.newPreviewImage = assetsURL + "/" + data.Filename;
			});
		}
	});
	
	$scope.uploadMediaFile = function(mediaItem,errFiles) {
		
		if(mediaItem.TempFile){
			
			console.log("thanks gebas");
			
			$scope.mediaFilesLoading = true;
			$scope.showPreview = false;
			
			mediaItem.TempFile.upload = Upload.upload({
                url: assetsURL+'/home/upload',
                data: {file: mediaItem.TempFile}
            });
			
			mediaItem.TempFile.upload.then(function (response) {
				
				mediaItem.FileID = response.data;		

				$http({
        		    url: baseURL+'File/'+mediaItem.FileID,
        		    method: "GET",
        		    headers: {'Content-Type': 'application/json'}
        		}).success(function (data, status, headers, config) {
        			//console.log(assetsURL + "/" + data.Filename);
        			$scope.mediaFilesLoading = false;
        			$scope.showPreview = true;
        			$scope.newPreviewImage = assetsURL + "/" + data.Filename;
        			console.log($scope.newPreviewImage);
        		}).error(function (data, status, headers, config) {
        		    $scope.status = status + ' ' + headers;
        		});

            }, function (response) {
                if (response.status > 0)
                $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
            	mediaItem.percentage = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
		}
		
	}
	
	$scope.mediaItemSubmitForm = function() {
		$scope.mediaItem.TempFile = null;
		blipperAPI.updateMediaItem($scope.mediaItem).then(function(data){
			$location.path("mediaitems/"+data.ID);
			$scope.success = true;
			$timeout(function(){
				$scope.success = false;
			}, 2000);
		});
	}

});