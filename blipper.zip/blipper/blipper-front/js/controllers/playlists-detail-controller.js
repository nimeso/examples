blipperControllers.controller('PlaylistsDetail_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, $uibModal, Upload, uiGmapIsReady, baseURL, assetsURL, blipperAPI) {
	
	blipperAPI.getMediaItems().then(function(data){
		$scope.mediaItems = data;
	});
	
	$scope.addMediaItemAsTimeSlot = function(){
		console.log($scope.playlist.selectedMediaItem);
		var timeSlot = {
			"Title": $scope.playlist.selectedMediaItem.Title,
			"MediaItemID": $scope.playlist.selectedMediaItem.Title,
			"PlaylistID": $routeParams.ID
		};
		
		blipperAPI.updateTimeSlot(timeSlot).then(function(data){
			$scope.timeSlots.push(data);
		});
	}
	
	blipperAPI.getPlaylist($routeParams.ID).then(function(data){
		$scope.playlist = data;
		
		blipperAPI.getDevicesByPlaylist($scope.playlist.ID).then(function(data){
			$scope.playlist.selectedDevices = data;
		});
		
		blipperAPI.getTimeSlotsByPlayList($scope.playlist.ID).then(function(data){
			$scope.timeSlots = data;
		});
		
	});

	blipperAPI.getDevices().then(function(data){
		$scope.devices = data;
	});
	
	$scope.playlistSubmitForm = function() {
		blipperAPI.updatePlaylist($scope.playlist).then(function(data){
			$location.path("playlists/"+data.ID);
			$scope.success = true;
			$timeout(function(){
				$scope.success = false;
			}, 2000);
		});
	}
	
	$scope.newTimeSlot = {};
	
	$scope.addTimeSlot = function(){
		if($scope.newTimeSlot.Title){
			$scope.newTimeSlot.PlaylistID = $scope.playlist.ID;
			blipperAPI.updateTimeSlot($scope.newTimeSlot).then(function(data){
				$scope.timeSlots.push(data);
				$scope.newTimeSlot.Title = "";
				$scope.newTimeSlot.TempFile = {};
				$scope.showPreview = false;
    			$scope.newPreviewImage = "";
			});
		}
	}
	
	$scope.deleteTimeSlot = function(timeSlot){
		var index = $scope.timeSlots.indexOf(timeSlot);
		//if (confirm("Are you sure you want to delete "+$scope.timeSlots[index].Title)) {
			blipperAPI.deleteTimeSlot(timeSlot);
			$scope.timeSlots.splice(index, 1);
		//}
	}
	
	$scope.uploadMediaFile = function(mediaItem,errFiles) {
		
		if(mediaItem.TempFile){
			
			console.log("thanks gebas");
			
			$scope.mediaFilesLoading = true;
			$scope.showPreview = false;
			
			mediaItem.TempFile.upload = Upload.upload({
                url: assetsURL+'/home/upload',
                data: {file: mediaItem.TempFile}
            });
			
			mediaItem.TempFile.upload.then(function (response) {
				
				mediaItem.FileID = response.data;		

				$http({
        		    url: baseURL+'File/'+mediaItem.FileID,
        		    method: "GET",
        		    headers: {'Content-Type': 'application/json'}
        		}).success(function (data, status, headers, config) {

        			$scope.mediaFilesLoading = false;
        			$scope.showPreview = true;
        			$scope.newPreviewImage = assetsURL + "/" + data.Filename;

        			var mediaItem = {
        				"FileID": data.ID
        			}
        			if($scope.newTimeSlot.Title){
        				mediaItem.Title = $scope.newTimeSlot.Title;
        			}else{
        				mediaItem.Title = data.Name;
        			}
        			
        			blipperAPI.updateMediaItem(mediaItem).then(function(data){
        				$scope.newTimeSlot.MediaItemID = data.ID;
        				
        			});
        			
        		}).error(function (data, status, headers, config) {
        		    $scope.status = status + ' ' + headers;
        		});

            }, function (response) {
                if (response.status > 0)
                $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
            	mediaItem.percentage = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
		}
		
	}
	
	$scope.reOrder = function($item, $part, $index) {
		setTimeout(function(){
			$part.forEach(function(part, i){
	
				$item.SortOrder = i+1;
				$part[i].SortOrder = i+1;
				
				console.log($part[i]);
				
				$http({
				    url: baseURL+'TimeSlot/'+$part[i].ID,
				    method: "PUT",
				    data: JSON.stringify($part[i]),
				    headers: {'Content-Type': 'application/json'}
				}).success(function (data, status, headers, config) {
					console.log("reordered");
				}).error(function (data, status, headers, config) {
				    $scope.status = status + ' ' + headers;
				});
			});
		}, 1000);
	}
	/*
	blipperAPI.getTimeSlots().then(function(data){
		$scope.slots = [];
		for(var t=0; t<data.length; t++){
			var slot = {
				start: parseInt(data[t].Start),
				stop: parseInt(data[t].Stop),
				day: 0,
				title: data[t].Title
			};
			$scope.slots.push(slot);
			console.log($scope.slots);
		}
	});
	
	 $scope.slots = [
         {start: 300, stop: 420, day: 1},
         {start: 60, stop: 120, day: 1}
     ];
     */
	
});