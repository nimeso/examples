blipperControllers.controller('DevicesList_Controller', function($scope, $timeout, $http, uiGmapIsReady, baseURL, assetsURL, blipperAPI) {

	blipperAPI.getDevices().then(function(data){
		
		console.log(data);
		
		$scope.devices = data;
		$scope.createMap();
	});
	
	$scope.deleteDevice = function(device){
		var index = $scope.devices.indexOf(device);
		if (confirm("Are you sure you want to delete "+$scope.devices[index].Title)) {
			blipperAPI.deleteDevice(device);
			$scope.devices.splice(index, 1);
		}
	}
	
	$scope.createMap = function(){
		
		if( typeof _.contains === 'undefined' ) {
	      _.contains = _.includes;
	    }
	    if( typeof _.object === 'undefined' ) {
	      _.object = _.zipObject;
		}

		angular.extend($scope, {
		    map: {
		      control: {},
		      center: {
		        latitude: 45,
		        longitude: -73
		      },
		      options: {
		        panControl: false,
		        maxZoom: 20,
		        minZoom: 3
		      },
		      zoom: 3,
		      dragging: false,
		      bounds: {},
		      markerEvents: {
		        click:function(gMarker, eventName, model){
		          model.doShow = true;
		      }
		    }}
		  });
		
		 var createMarker = function(marker, idKey) {

		      if (idKey == null) {
		        idKey = "id";
		      }

		      var ret = {
		        latitude: marker.Lat,
		        longitude: marker.Lng,
		        title: marker.Title,
		        location: marker.Location,
		        description: marker.Description,
		        totalScreens: marker.TotalScreens,
		        mediaWidth: marker.MediaWidth,
		        mediaHeight: marker.MediaHeight,
		        trafficRating: marker.TrafficRating,
		        icon: "img/marker_"+marker.TrafficRating+".png"
		        
		      };
		      
		      
		      if(marker.Images){
		    	  ret.images = "";
		    	  imgs = "";
		    	  var l = marker.Images.length;
		    	  for(var t=0; t<l; t++){
		    		  blipperAPI.getFile(marker.Images[t]).then(function(data){
		    			  imgs += "<a href='"+assetsURL+"/"+data.Filename+"' target='_blank'><img class='map-img' src='"+assetsURL+"/"+data.Filename+"' /></a>";
		    			  console.log(data);
		    			  ret.images = imgs;
		    		  });
			      }
		    	  console.log(ret);
		      }
		      console.log(ret);
		      ret[idKey] = marker.ID;
		      return ret;
		};
		
	    
	    $scope.map.markers = [];
	    
	    // Get the bounds from the map once it's loaded
	    $scope.$watch(function() {
	    	return $scope.map.bounds;
	    }, function(nv, ov) {
	    	// Only need to regenerate once
	    	if (!ov.southwest && nv.southwest) {
	    		var markers = [];
	    		for (var i = 0; i < $scope.devices.length; i++) {
	    			markers.push(createMarker($scope.devices[i]))
	    		}
	    		$scope.map.markers = markers;
	    	}
	    }, true);

	}

});