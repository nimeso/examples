blipperControllers.controller('DevicesDetail_Controller', function($scope, $location, $timeout, $routeParams, $log, $http, $uibModal, Upload, uiGmapIsReady, baseURL, assetsURL, blipperAPI) {

	$scope.createMap = function(){
		/* map */
		if( typeof _.contains === 'undefined' ) {
	        _.contains = _.includes;
	    }
	    if( typeof _.object === 'undefined' ) {
	        _.object = _.zipObject;
	    }
	    $scope.map = {
			  center: {
	              latitude: -41.0456965,
	              longitude: 173.9247652
	          },
	          zoom: 6,
	          markers: [],
	          events: {
		          click: function (map, eventName, originalEventArgs) {
		              var e = originalEventArgs[0];
		              var lat = e.latLng.lat(),lon = e.latLng.lng();
	
		              $scope.device.Lat = lat;
		          	  $scope.device.Lng = lon;
		              
		              var marker = {
		                  id: Date.now(),
		                  coords: {
		                      latitude: lat,
		                      longitude: lon
		                  }
		              };
		              $scope.map.markers = [];
		              $scope.map.markers.push(marker);
		              $scope.$apply();
		          }
	          }
	    }
	    if($scope.device.Lat && $scope.device.Lng && $scope.device.Lat != 'test' && $scope.device.Lng != 'test'){
	    	  $scope.map.center = {
	              latitude: $scope.device.Lat,
	              longitude: $scope.device.Lng
	          }
	    	  $scope.map.zoom = 8;
	    	  var marker = {
	                  id: Date.now(),
	                  coords: {
	                      latitude: $scope.device.Lat,
	                      longitude: $scope.device.Lng
	                  }
	          };
	    	  $scope.map.markers.push(marker);
	    }
	    
	}

	
	$scope.uploadFiles = function(files, errFiles) {
		
		if (files){
			
			if (!files.length) {
				$scope.filesLoading = false;
			    return;
			}else{
				$scope.filesLoading = true;
			}
	
			var current = files.shift();

			current.upload = Upload.upload({
	            url: assetsURL+'/home/upload',
	            data: {file: current}
	        }).then(function(response){
	        	
	        	blipperAPI.getFile(response.data).then(function(data){

	        		data.Device = $scope.device.ID;

        			var image = {
        				"ID": data.ID,
        				"Filename": assetsURL+"/"+data.Filename
        			};
        			
        			$scope.previewImages.push(image);
        			if(!$scope.device.Images){
        				$scope.device.Images = [];
        			}
        			$scope.device.Images.push(data.ID);
        			blipperAPI.updateFile(data);
	        		
	        		$scope.uploadFiles(files,errFiles);
	            });
	        	
	        	
	        });
			
		}
		
	}
	
	$scope.deleteDeviceImage = function(file){
		var index = $scope.previewImages.indexOf(file);
		if (confirm("Are you sure you want to delete "+$scope.previewImages[index].Filename)) {
			blipperAPI.deleteDeviceImage(file);
			$scope.previewImages.splice(index, 1);
			$scope.device.Images = null;
		}
	}
	
	$scope.createPreviewImages = function(){
		$scope.previewImages = [];
		for(y in $scope.device.Images){
			blipperAPI.getFile($scope.device.Images[y]).then(
        		function(data){
        			var image = {
        				"ID": data.ID,
        				"Filename": assetsURL+"/"+data.Filename
        			};
        			$scope.previewImages.push(image);
        		}
        	);
		}
	}
	
	$scope.reOrder = function($item, $part, $index) {
		
		setTimeout(function(){
			$part.forEach(function(part, i){
	
				$item.SortOrder = i+1;
				$part[i].SortOrder = i+1;
				
				$http({
				    url: baseURL+'MediaItem/'+$part[i].ID,
				    method: "PUT",
				    data: JSON.stringify($part[i]),
				    headers: {'Content-Type': 'application/json'}
				}).success(function (data, status, headers, config) {
					console.log("reordered");
				}).error(function (data, status, headers, config) {
				    $scope.status = status + ' ' + headers;
				});
			});
		}, 1000);
	}
	
	$scope.setApproved = function(mediaItem, isApproved){
		
		if(isApproved){
			console.log("disprove this");
			mediaItem.Approved = 0;
		}else{
			console.log("approve this");
			mediaItem.Approved = 1;
		}
		
		$http({
		    url: baseURL+'MediaItem/'+mediaItem.ID,
		    method: "PUT",
		    data: JSON.stringify(mediaItem),
		    headers: {'Content-Type': 'application/json'}
		}).success(function (data, status, headers, config) {
			
		}).error(function (data, status, headers, config) {
		    $scope.status = status + ' ' + headers;
		});
	}
	
	$scope.uploadNewMediaFile = function(newMediaItem,errFiles) {
		
		if(newMediaItem.TempFile){
			
			$scope.mediaFilesLoading = true;
			$scope.showPreview = false;
			
			newMediaItem.TempFile.upload = Upload.upload({
                url: assetsURL+'/home/upload',
                data: {file: newMediaItem.TempFile}
            });
			
			newMediaItem.TempFile.upload.then(function (response) {
				
				newMediaItem.FileID = response.data;		

				$http({
        		    url: baseURL+'File/'+newMediaItem.FileID,
        		    method: "GET",
        		    headers: {'Content-Type': 'application/json'}
        		}).success(function (data, status, headers, config) {
        			//console.log(assetsURL + "/" + data.Filename);
        			$scope.mediaFilesLoading = false;
        			$scope.showPreview = true;
        			$scope.newPreviewImage = assetsURL + "/" + data.Filename;
        		}).error(function (data, status, headers, config) {
        		    $scope.status = status + ' ' + headers;
        		});

            }, function (response) {
                if (response.status > 0)
                $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
            	newMediaItem.percentage = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
		}
		
	}
	
	$scope.showPreview = false;
	$scope.addMediaItem = function(mediaItem){
		
		if(!$scope.device.MediaItems){
			$scope.device.MediaItems = [];
		}
		
		mediaItem.DeviceID = $routeParams.ID;
		mediaItem.SortOrder = 99999;
		mediaItem.TempFile = null;

		$http({
		    url: baseURL+'MediaItem/',
		    method: "POST",
		    data: JSON.stringify(mediaItem),
		    headers: {'Content-Type': 'application/json'}
		}).success(function (data, status, headers, config) {
			$scope.device.MediaItems.push(data);
			$scope.newMediaItem.Title = "";
			$scope.showPreview = false;
			$scope.newPreviewImage = "";
		}).error(function (data, status, headers, config) {
		    $scope.status = status + ' ' + headers;
		});
		
	}

	$scope.deleteMediaItem = function(mediaItem){
		var index = $scope.device.MediaItems.indexOf(mediaItem);
		if (confirm("Are you sure you want to delete "+$scope.device.MediaItems[index].Title)) {

			var itemID = $scope.device.MediaItems[index].ID;
			
			$http.delete(baseURL+'MediaItem/'+itemID).success(function(data) {
		        console.log(data);
		    });
			
			$scope.device.MediaItems.splice(index, 1);
		}
	}

	  $scope.animationsEnabled = true;

	  $scope.open = function(mediaItem, size) {

	    var modalInstance = $uibModal.open({
	      animation: $scope.animationsEnabled,
	      templateUrl: 'templates/includes/model.html',
	      controller: 'ModalInstanceCtrl',
	      size: size,
	      resolve: {
	    	  mediaItem: function () {
	            return mediaItem;
	          }
	        }
	    });
	  };

	  $scope.toggleAnimation = function () {
	    $scope.animationsEnabled = !$scope.animationsEnabled;
	  };
	  
	  // boot up and get device from API
	  if($routeParams.ID){
			blipperAPI.getDevice($routeParams.ID).then(function(data){
				$scope.device = data;
				
				blipperAPI.getPlaylists().then(function(data){
					$scope.playlists = data;
					
					if($scope.device.Playlist){
						var playlist;
						for(var e=0; e<$scope.playlists.length; e++){
							if($scope.playlists[e].ID == $scope.device.Playlist){
								playlist = $scope.playlists[e];
							}
						}
						$scope.device.selectedPlaylist = playlist;
					}
				});

				$scope.items = $scope.device.MediaItems;
				$scope.createPreviewImages();
				$scope.createMap();
			});
		}else{
			$scope.device = {};
			$scope.createPreviewImages();
			$scope.createMap();
		}

		$scope.deviceSubmitForm = function() {
			blipperAPI.updateDevice($scope.device).then(function(data){
				$location.path("devices/"+data.ID);
				$scope.success = true;
				$timeout(function(){
					$scope.success = false;
				}, 2000);
			});
		}
	
});

blipperControllers.controller('ModalInstanceCtrl', function ($scope, $http, $timeout, $uibModalInstance, Upload, mediaItem, baseURL, assetsURL, blipperAPI) {

	console.log(mediaItem);
	 $scope.mediaItem = mediaItem;
	 $scope.mediaItem.previewFile = $scope.mediaItem.File;
	 
	  $scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	  };
	  
	  $scope.updateMediaItem = function(mediaItem){
		  $scope.hideFile = true;
		  console.log(mediaItem);
		  blipperAPI.updateMediaItem(mediaItem).then(function(data){
			  $scope.mediaItemSuccess = true;
			  $timeout(function(){
					$scope.mediaItemSuccess = false;
			  }, 2000);
		  });
		}
	  
	  $scope.uploadNewMediaFile = function(newMediaItem,errFiles) {
			
		  $scope.mediaFilesLoading = true;
		  
			if(newMediaItem.TempFile){

				newMediaItem.TempFile.upload = Upload.upload({
	                url: assetsURL+'/home/upload',
	                data: {file: newMediaItem.TempFile}
	            });
				
				newMediaItem.TempFile.upload.then(function (response) {
					
					$http({
	        		    url: baseURL+'File/'+response.data,
	        		    method: "GET",
	        		    headers: {'Content-Type': 'application/json'}
	        		}).success(function (data, status, headers, config) {
	        			$scope.mediaFilesLoading = false;
	        			$scope.mediaItem.previewFile = assetsURL + "/" + data.Filename;
	        			$scope.mediaItem.FileID = data.ID;
	        		}).error(function (data, status, headers, config) {
	        		    $scope.status = status + ' ' + headers;
	        		});

	            }, function (response) {
	                if (response.status > 0)
	                $scope.errorMsg = response.status + ': ' + response.data;
	            }, function (evt) {
	            	newMediaItem.percentage = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
	            });
			}
			
		}
});