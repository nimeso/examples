blipperControllers.controller('MediaItemsList_Controller', function($scope, $timeout, $http, uiGmapIsReady, baseURL, blipperAPI) {

	blipperAPI.getMediaItems().then(function(data){
		$scope.mediaItems = data;
		console.log($scope.mediaItems);
	});
	
	$scope.deleteMediaItem = function(mediaItem){
		var index = $scope.mediaItems.indexOf(mediaItem);
		if (confirm("Are you sure you want to delete "+$scope.mediaItems[index].Title)) {
			blipperAPI.deleteMediaItem(mediaItem);
			$scope.mediaItems.splice(index, 1);
		}
	}
	
	$scope.setApproved = function(mediaItem, isApproved){
		
		if(isApproved){
			console.log("disprove this");
			mediaItem.Approved = 0;
		}else{
			console.log("approve this");
			mediaItem.Approved = 1;
		}
		
		$http({
		    url: baseURL+'MediaItem/'+mediaItem.ID,
		    method: "PUT",
		    data: JSON.stringify(mediaItem),
		    headers: {'Content-Type': 'application/json'}
		}).success(function (data, status, headers, config) {
			
		}).error(function (data, status, headers, config) {
		    $scope.status = status + ' ' + headers;
		});
	}

});