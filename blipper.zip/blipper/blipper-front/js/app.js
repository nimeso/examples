'use strict';

/* App Module */

var blipper = angular.module('blipper', [
  'ngRoute',
  'blipperControllers',
  'blipperServices',
  'uiGmapgoogle-maps',
  'ngFileUpload',
  'ui.bootstrap',
  'ui.bootstrap.progressbar',
  'angular-sortable-view',
  'ui.select',
  'ngSanitize',
  'scheduler'
]);

blipper.value('baseURL', 'http://localhost/blipper/api/');
blipper.value('assetsURL', 'http://localhost/blipper');

blipper.config(['$routeProvider',
	function($routeProvider) {
    	$routeProvider.
		when('/devices', {
			templateUrl: 'templates/devices-list.html',
			controller: 'DevicesList_Controller'
      }).
      when('/devices/:ID', {
    	  templateUrl: 'templates/devices-detail.html',
    	  controller: 'DevicesDetail_Controller'
      }).
      when('/devices-create', {
    	  templateUrl: 'templates/devices-detail.html',
    	  controller: 'DevicesDetail_Controller'
      }).
      when('/mediaitems', {
    	  templateUrl: 'templates/media-items-list.html',
    	  controller: 'MediaItemsList_Controller'
      }).
      when('/mediaitems/:ID', {
    	  templateUrl: 'templates/media-items-detail.html',
    	  controller: 'MediaItemsDetail_Controller'
      }).
      when('/mediaitems-create', {
    	  templateUrl: 'templates/media-items-detail.html',
    	  controller: 'MediaItemsDetail_Controller'
      }).
      when('/playlists', {
    	  templateUrl: 'templates/playlists-list.html',
    	  controller: 'PlaylistsList_Controller'
      }).
      when('/playlists/:ID', {
    	  templateUrl: 'templates/playlists-detail.html',
    	  controller: 'PlaylistsDetail_Controller'
      }).
      when('/playlists-create', {
    	  templateUrl: 'templates/playlists-detail.html',
    	  controller: 'PlaylistsDetail_Controller'
      }).
      when('/home', {
    	  templateUrl: 'templates/home.html',
    	  controller: 'Home_Controller'
      }).
      otherwise({
    	  redirectTo: '/home'
      });
}]);
