<?php
class MediaItem extends DataObject{
	
	private static $db = array(
		"Title" => "Varchar(256)",
		"Time" => "Enum('15secs,30secs,45secs,1min','15secs')",
		"Status" => "Enum('Approved,Pending,Rejected','Pending')",
		"EmailApprovedSent" => "Boolean",
		"EmailRejectedSent" => "Boolean"
	);
	 
	private static $has_one = array(
		"File" => "File",
		"ImageMedia" => "Image",
		"VideoMedia" => "File",
		"UpdatedFile" => "File",
		"Member" => "Member"
	);
	
	private static $has_many = array(
		"OrderItems" => "OrderItem",
		"TimeSlots" => "TimeSlot"
	);
	
	static $default_sort = "Created DESC";
	
	public function onBeforeWrite(){
		
		parent::onBeforeWrite();
		
		if($this->Status == 'Approved' && !$this->EmailApprovedSent && $this->Member()->exists()){
			$from = "info@blippar.co.nz";
			$to = $this->Member().Email;
			//$to = "jamie@plattar.com";
			$sub = "Blippar Media Item Approved";
			$email = new Email($from,$to,$sub);
			$email->setTemplate("MediaItemApproved");
			$email->populateTemplate(new ArrayData(array(
		        'MediaItem' => $this
		    )));
			$email->send();
			
			if(!$this->EmailApprovedSent){
				$this->EmailApprovedSent = 1;
			}
		}
		
		if($this->Status == 'Rejected' && !$this->EmailRejectedSent && $this->Member()->exists()){
			$from = "info@blippar.co.nz";
			$to = $this->Member().Email;
			//$to = "jamie@plattar.com";
			$sub = "Blippar Media Item Rejected";
			$email = new Email($from,$to,$sub);
			$email->setTemplate("MediaItemRejected");
			$email->populateTemplate(new ArrayData(array(
		        'MediaItem' => $this
		    )));
			$email->send();
			
			if(!$this->EmailRejectedSent){
				$this->EmailRejectedSent = 1;
			}
		}
	}
	
	public function getCMSFields(){
		$fields = parent::getCMSFields();

		$fields->addFieldToTab("Root.Main", $up = new UploadField("File","Media File"));
		$up->setAllowedExtensions(array("mp4","avi","jpg","jpeg","png"));
		
		return $fields;
	}
	
	public function onAfterSerialize( &$formattedDataObjectMap ){

		$formattedDataObjectMap["Created"] = $this->Created;
  		$formattedDataObjectMap["Modified"] = $this->LastEdited;

  		$formattedDataObjectMap["MediaLength"] = "1:30";
  		
  		$baseURL = Director::absoluteBaseURL();
  		
  		if($this->ImageMedia()->exists()){

	  			$formattedDataObjectMap["MediaType"] = "Image";
	  			$formattedDataObjectMap["PreviewImage"] = $this->getImage("width",1281);
	  			$formattedDataObjectMap["MainImage"] = $this->getImage("width",760);
	  			$formattedDataObjectMap["BigListingImage"] = $this->getImage("cropped",360,203);
	  			$formattedDataObjectMap["ExtraSmallListingImage"] = $this->getImage("cropped",120,64);
	  			$formattedDataObjectMap["ExtraSmallSquareImage"] = $this->getImage("cropped",120,120);
	  		
  		}
  		
		if($this->UpdatedFile()->exists()){

	  			$formattedDataObjectMap["UpdatedPreviewImage"] = $this->getUpdatedImage("width",1280);
	  			$formattedDataObjectMap["UpdatedMainImage"] = $this->getUpdatedImage("width",760);
	  			$formattedDataObjectMap["UpdatedBigListingImage"] = $this->getUpdatedImage("cropped",360,203);
	  			$formattedDataObjectMap["UpdatedExtraSmallListingImage"] = $this->getUpdatedImage("cropped",120,64);
	  		
  		}
  		
  	}
  	
  	public function getImage($resizeType, $width = 100, $height = 100){

  		$baseURL = Director::absoluteBaseURL();

  		if($this->ImageMedia()->exists()){
  			if($resizeType == "cropped"){
				return $this->ImageMedia()->CroppedImage($width,$height)->getAbsoluteURL();
			}else if($resizeType == "padded"){
				return $this->ImageMedia()->PaddedImage($width,$height)->getAbsoluteURL();
			}else if($resizeType == "width"){
				return $this->ImageMedia()->SetWidth($width)->getAbsoluteURL();
			}else if($resizeType == "height"){
				return $this->ImageMedia()->SetWidth($height)->getAbsoluteURL();
			}else{
				return $this->ImageMedia()->CroppedImage($width,$height)->getAbsoluteURL();
			}
  		}
  		
  	}
  	
	public function getUpdatedImage($resizeType, $width = 100, $height = 100){
  		
  		if($this->UpdatedFile()->exists()){
  			$type = $this->UpdatedFile()->getExtension();
			//check if image
			if($type == "jpg" || $type == "jpeg" || $type == "png"){
				$img = new Image();
				$img->Name = $this->UpdatedFile()->Name;
				$img->Filename = $this->UpdatedFile()->Filename;
				$img->ParentID = $this->UpdatedFile()->ParentID;
				$img->Title = $this->UpdatedFile()->Title;
				$img->write();
				
				if($resizeType == "cropped"){
					return $img->CroppedImage($width,$height)->getAbsoluteURL();
				}else if($resizeType == "padded"){
					return $img->PaddedImage($width,$height)->getAbsoluteURL();
				}else if($resizeType == "width"){
					return $img->SetWidth($width)->getAbsoluteURL();
				}else if($resizeType == "height"){
					return $img->SetWidth($height)->getAbsoluteURL();
				}else{
					return $img->CroppedImage($width,$height)->getAbsoluteURL();
				}
				
			}
  		}
  	}
	
}