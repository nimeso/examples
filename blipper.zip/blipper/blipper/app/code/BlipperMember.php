<?php
class BlipperMember extends DataExtension{
	
	public static $db = array(
		"DontShowHelp" => "Boolean",
		"GoogleToken" => "Varchar(256)"
	);
	
	public static $has_many = array(
		"MediaItems" => "MediaItem",
		"Orders" => "Order"
	);
	
	public function getCMSFields(){
		$fields = parent::getCMSFields();
		
		$fields->insertAfter(new CheckboxField("DontShowHelp","Dont Show Help"), "Email");
		
		return $fields;
	}
	
}