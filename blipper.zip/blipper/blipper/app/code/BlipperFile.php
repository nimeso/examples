<?php
class BlipperFile extends DataExtension{
	
	public static $has_one = array(
		"Device" => "Device"
	);
	
}