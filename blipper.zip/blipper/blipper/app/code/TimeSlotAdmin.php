<?php
class TimeSlotAdmin extends ModelAdmin{

	private static $menu_title = "Time Slots";
	private static $url_segment = "timeslots";
	//private static $menu_icon = 'mysite/images/icons/applications.png';
	private static $menu_priority = 2;

	private static $managed_models = array(
		'TimeSlot'
	);

}