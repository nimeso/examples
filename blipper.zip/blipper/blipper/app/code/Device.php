<?php
class Device extends DataObject{
	
	private static $db = array(
		"UID" => "Varchar(128)",
		"Title" => "Varchar(256)",
		"Location" => "Varchar(256)",
		"Description" => "Text",
		"Content" => "HTMLText",
		"TotalScreens" => "Int",
		"MediaWidth" => "Int",
		"MediaHeight" => "Int",
		"TrafficRating" => "Int",
		"Cost" => "Float",
		"Lat" => "Varchar(128)",
		"Lng" => "Varchar(128)",
		"Likes" => "Int"
	);
	
	private static $has_one = array(
		"Playlist" => "Playlist"
	);
	
	private static $has_many = array(
		"OrderItems" => "OrderItem",
		"DeviceImages" => "DeviceImage"
	);
	
	public function getCMSFields(){
		$fields = parent::getCMSFields();
		
		$gridfieldPages = new GridField("DeviceImages","Device Images",$this->DeviceImages());
		$gridfieldPages->getConfig()
		     ->addComponent(new GridFieldDetailForm()) 
		     ->addComponent(new GridFieldAddNewButton('toolbar-header-right'))
		     ->addComponent(new GridFieldEditButton())
		     ->addComponent(new GridFieldDeleteAction())
		     ->addComponent(new GridFieldSortableRows('SortOrder'));
		$fields->addFieldToTab("Root.DeviceImages", $gridfieldPages);
		
		return $fields;
	}
    
	public function onAfterSerialize( &$formattedDataObjectMap ){
		
  		$formattedDataObjectMap["Created"] = $this->Created;
  		$formattedDataObjectMap["Modified"] = $this->LastEdited;
  		
  		if($this->DeviceImages()->exists()){
  			
  			$formattedDataObjectMap["FirstImageSmall"] = $this->getImage($this->DeviceImages()->first()->Image(),"cropped",120,80);
  			
  			$formattedDataObjectMap["ResizedImages"] = array();
  			foreach ($this->DeviceImages() as $image){
  				if($this->getImage($image->Image(),"width",800)){
  					$formattedDataObjectMap["ResizedImages"][] = $this->getImage($image->Image(),"cropped",800,360);
  				}
  			}
  		}
  	}
  	
	public function getImage($file, $resizeType, $width = 100, $height = 100){
  		
  		if($file->exists()){
			if($resizeType == "cropped"){
				return $file->CroppedImage($width,$height)->getAbsoluteURL();
			}else if($resizeType == "padded"){
				return $file->PaddedImage($width,$height)->getAbsoluteURL();
			}else if($resizeType == "width"){
				return $file->SetWidth($width)->getAbsoluteURL();
			}else if($resizeType == "height"){
				return $file->SetWidth($height)->getAbsoluteURL();
			}else{
				return $file->CroppedImage($width,$height)->getAbsoluteURL();
			}
  		}
  	}
	
}


class DeviceImage extends DataObject{
	
	private static $db = array(
		"Title" => "Varchar(128)",
		'SortOrder' => 'Int'
	);
	
	private static $has_one = array(
		"Device" => "Device",
		"Image" => "Image"
	);
	
	static $default_sort = "SortOrder ASC";
	
	public function getCMSFields(){
		$fields = parent::getCMSFields();
		
		$fields->removeByName("SortOrder");
		$fields->removeByName("DeviceID");
		$fields->addFieldToTab("Root.Main", new TextField("Title","Title"));
		$fields->addFieldToTab("Root.Main", $uploadfield = new UploadField("Image","Image"));
		$uploadfield->setFolderName("BlipparDeviceImages");
		
		return $fields;
	}

	
	public function getThumbnail(){
	  	if ($icon = $this->Image()){
	  		return $icon->CMSThumbnail();
	  	}else{
	  		return '(No Image)';
	  	}
	}
	
	public static $summary_fields = array(
		'Thumbnail',
		'Title'
	);
	
}