<?php
class Order extends DataObject{
	
	private static $db = array(
		"Referance" => "Varchar(256)",
		"FirstName" => "Varchar(256)",
		"Surname" => "Varchar(256)",
		"Email" => "Varchar(256)",
		"Phone" => "Varchar(256)",
		"Address1" => "Varchar(256)",
		"Address2" => "Varchar(256)",
		"Address3" => "Varchar(256)",
		"Address4" => "Varchar(256)",
		"Address5" => "Varchar(256)",
		"Address6" => "Varchar(256)",
		"Phone" => "Varchar(256)",
		"Company" => "Varchar(256)",
		"Status" => "Enum('Created,Pending,Completed,Cancelled','Created')",
		"EmailInvoiceSent" => "Boolean"
	);
	
	private static $has_one = array(
		"Member" => "Member"
	);
	
	private static $has_many = array(
		"OrderItems" => "OrderItem",
		"Payments" => "Payment"
	);
	
	private static $summary_fields = array (
		'ID',
		'Referance',
		'Created',
        'FirstName',
        'Surname',
        'Email',
		'Status',
		'OrderTotal',
		'Paid'
    );
	
	private static $searchable_fields = array (
		'ID',
		'Referance',
        'FirstName',
        'Surname',
        'Email',
		'Company',
		'Phone',
		'Status'
    ); 
	
	public function getCMSFields(){
		$fields = parent::getCMSFields();
		
		$fields->removeByName("Referance");
		$fields->insertBefore(new ReadonlyField("Referance","Referance"), "FirstName");
		
		return $fields;
	}
	
	public function getOrderTotal(){
		if($this->OrderItems()->exists()){
			$total = 0;
			foreach($this->OrderItems() as $orderItem){
				$total += $orderItem->Total;
			}
			return $total;
		}
	}
	
	public function getNiceOrderTotal(){
		if($this->OrderItems()->exists()){
			$total = 0;
			foreach($this->OrderItems() as $orderItem){
				$total += $orderItem->Total;
			}
			return "$".number_format($total,2);
		}
	}
	
	public function getPaid(){
		if($this->Payments()->exists()){
			$total = 0;
			foreach($this->Payments() as $payment){
				$total += $payment->getAmount();
			}
			return $total;
		}
	}
	
	public function onAfterSerialize( &$formattedDataObjectMap ){

    	$formattedDataObjectMap["Created"] = $this->Created;
  		$formattedDataObjectMap["Modified"] = $this->LastEdited;
  		$formattedDataObjectMap["Total"] = $this->getOrderTotal();
  		
	}
	
	public function onBeforeWrite(){
		
		if(!$this->Referance){
			$this->Referance = $this->createReferance();
		}
		parent::onBeforeWrite();
	}
	
	function createReferance($l = 12) {
	    return  "BL-".strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, $l));
	}
	
}

class OrderItem extends DataObject{
	
	private static $db = array(
		"DeviceTitle" => "Varchar(256)",
		"DeviceLocation" => "Varchar(256)",
		"DeviceCost" => "Int",
		"MediaItemTitle" => "Varchar(256)",
		"StartDate" => "SS_Datetime",
		"EndDate" => "SS_Datetime",
		"WeeksBooked" => "Int",
		"Total" => "Int"
	);
	
	private static $has_one = array(
		"Order" => "Order",
		"Device" => "Device",
		"MediaItem" => "MediaItem"
	);
	
	private static $summary_fields = array (
		'ID',
		'Created',
        'DeviceTitle',
        'DeviceLocation',
        'MediaItemTitle',
		'StartDate',
		'EndDate',
		'WeeksBooked'
    );
    
    public function onAfterSerialize( &$formattedDataObjectMap ){
    	
    	$baseURL = Director::absoluteBaseURL();
    	
    	$formattedDataObjectMap["Created"] = $this->Created;
  		$formattedDataObjectMap["Modified"] = $this->LastEdited;

    	if($this->MediaItem()->exists()){

	    	if($this->MediaItem()->ImageMedia()->exists()){
	  			$formattedDataObjectMap["FirstMediaItemImageSmall"] = $this->MediaItem()->getImage("cropped",120,80);
	  		}
	  		
    	}
    	
    }
    
    public function NiceTotal(){
    	return "$".number_format($this->Total,2);
    }
    
	public function NiceWeekCost(){
    	return "$".number_format($this->DeviceCost,2);
    }
	
}