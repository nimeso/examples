<?php
class TimeSlot extends DataObject{
	
	private static $db = array(
		"Title" => "Varchar(256)",
		"StartDate" => "SS_Datetime",
		"EndDate" => "SS_Datetime",
		"Status" => "Enum('Approved,Pending,Rejected','Pending')",
		"SortOrder" => "Int"
	);
	
	private static $has_one = array(
		"Playlist" => "Playlist",
		"MediaItem" => "MediaItem"
	);
	
	static $default_sort = "SortOrder ASC";
	
	public function getCMSFields(){
		$fields = parent::getCMSFields();
		return $fields;
	}
	
	public function onAfterSerialize( &$formattedDataObjectMap ){
		$formattedDataObjectMap["Created"] = $this->Created;
  		$formattedDataObjectMap["Modified"] = $this->LastEdited;
  		
  		$sdate = $this->dbObject('StartDate');
  		$formattedDataObjectMap["StartDate"] = $sdate->format('d/m/Y');
  		
  		$edate = $this->dbObject('EndDate');
  		$formattedDataObjectMap["EndDate"] = $edate->format('d/m/Y');
  		
  		if($sdate->InPast() && $edate->InFuture()){
  			$formattedDataObjectMap["Playing"] = true;
  		}else{
  			$formattedDataObjectMap["Playing"] = false;
  		}
  		
  		if($edate->InPast()){
  			$formattedDataObjectMap["Expired"] = true;
  		}else{
  			$formattedDataObjectMap["Expired"] = false;
  		}
  		
  		if($this->Playlist()->exists()){
  			$device = $this->Playlist()->Devices()->first();
  			$formattedDataObjectMap["Device"] = array(
  				"Title" => $device->Title,
  				"Location" => $device->Location
  			);
  			
  			if($device->DeviceImages()->exists()){
  				$firstFile = $device->DeviceImages()->first()->Image();
  				$formattedDataObjectMap["Device"]["FirstImage"] = $device->getImage($firstFile,"cropped",120,60);
  			}
  		}
  	}
	
}