<?php
class Playlist extends DataObject{
	
	private static $db = array(
		"Title" => "Varchar(256)"
	);
	 
	private static $has_many = array(
		"Devices" => "Device",
		"TimeSlots" => "TimeSlot"
	);

	
	public function getCMSFields(){
		$fields = parent::getCMSFields();
		return $fields;
	}
	
	public function onAfterSerialize( &$formattedDataObjectMap ){
		$formattedDataObjectMap["Created"] = $this->Created;
  		$formattedDataObjectMap["Modified"] = $this->LastEdited;
  	}
	
}