<?php
class OrderAdmin extends ModelAdmin{

	private static $menu_title = "Orders";
	private static $url_segment = "orders";
	//private static $menu_icon = 'mysite/images/icons/applications.png';
	private static $menu_priority = 2;

	private static $managed_models = array(
		'Order'
	);

}