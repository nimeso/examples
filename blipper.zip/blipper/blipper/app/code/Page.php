<?php
class Page extends SiteTree {

	private static $db = array(
	);

	private static $has_one = array(
	
	);
	
	public function getCMSFields(){
		
		$fields = parent::getCMSFields();
		return $fields;
	}

}
class Page_Controller extends ContentController {

	private static $allowed_actions = array (
		"upload",
		"uploadcropped",
		"image",
		"createMember",
		"ordersuccess",
		"ordercancel",
		"devices",
		"device",
		"membercheck",
		"createMemberFromGoogle"
	);

	public function init() {
		parent::init();
		$ThemeDir =  $this->ThemeDir();
	}
	
	public function membercheck($request){
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');
		
		$obj = json_decode($request->getBody());
		if( $member = Member::get()->filter(array("Email" => $obj->email))->first() ){
			$tokenData = $this->generateToken();
			$member->ApiToken  = $tokenData['token'];
            $member->ApiTokenExpire = $tokenData['expire'];
            $member->write();
            
			$member->login();
			$data = array(
				"status" => "success",
				"id" => $member->ID,
				"token" => $member->ApiToken
			);
		}else{
			$data = array(
				"status" => "fail"
			);
		}
		echo json_encode($data);
	}
	
	private function generateToken($expired = false)
  {
      $life  = $this->tokenConfig['life'];

      if (!$expired) {
          $expire = time() + $life;
      } else {
          $expire = time() - ($life * 2);
      }
    
      $generator = new RandomGenerator();
      $tokenString = $generator->randomToken();

      $e = PasswordEncryptor::create_for_algorithm('blowfish'); //blowfish isn't URL safe and maybe too long?
    $salt = $e->salt($tokenString);
      $token = $e->encrypt($tokenString, $salt);

      return array(
      'token' => substr($token, 7),
      'expire' => $expire
    );
  }
	
	public function devices(){
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');
		
		$devices = Device::get();
		$a = array();
		foreach ($devices as $device) {

           	$b = array(
           		"ID" => $device->ID,
           		"Title" => $device->Title,
           		"Lat" => $device->Lat,
           		"Lng" => $device->Lng,
           		"Likes" => $device->Likes,
           		"Location" => $device->Location,
           		"Cost" => $device->Cost,
           		"Description" => $device->Description,
           		"TotalScreen" => $device->TotalScreen,
           		"MediaWidth" => $device->MediaWidth,
           		"MediaHeight" => $device->MediaHeight,
           		"TrafficRating" => $device->TrafficRating
           	);
           	
           	if($device->DeviceImages()){
           		
				$b["ResizedImages"] = array();
	  			foreach ($device->DeviceImages() as $image){
	  				if($device->getImage($image->Image(),"width",800)){
	  					$b["ResizedImages"][] = $device->getImage($image->Image(),"cropped",800,360);
	  				}
	  			}
           	}

			$a[] = $b;
		}
		
		echo json_encode($a);
	}
	
	public function device($request){
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');
		
		$device = Device::get()->filter(array("ID" => $request->param('ID')))->first();

           	$b = array(
           		"ID" => $device->ID,
           		"Title" => $device->Title,
           		"Lat" => $device->Lat,
           		"Lng" => $device->Lng,
           		"Likes" => $device->Likes,
           		"Location" => $device->Location,
           		"Cost" => $device->Cost,
           		"Description" => $device->Description,
           		"Content" => $device->Content,
           		"TotalScreen" => $device->TotalScreen,
           		"MediaWidth" => $device->MediaWidth,
           		"MediaHeight" => $device->MediaHeight,
           		"TrafficRating" => $device->TrafficRating
           	);
           	
           	if($device->DeviceImages()){

				$b["ResizedImages"] = array();
	  			foreach ($device->DeviceImages() as $image){
	  				if($device->getImage($image->Image(),"width",800)){
	  					$b["ResizedImages"][] = $device->getImage($image->Image(),"cropped",800,360);
	  				}
	  			}
           	}
		
		echo json_encode($b);
	}
	
	public function uploadcropped($request){

		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');
		
		if($request->getBody()){

			$split = explode(",", $request->getBody());

			$ranFolderName = $this->generateRandomString();
			$baseFolder = Folder::find_or_make('BlipparCroppedUploads');
			$newFolder = Folder::find_or_make('BlipparCroppedUploads/'.$ranFolderName);

			file_put_contents($_SERVER['DOCUMENT_ROOT']."/blipper/".$newFolder->Filename.$ranFolderName.'.jpg', base64_decode($split[1]));
			
			$file = new Image();
			$file->Name = $ranFolderName;
			$file->Title = $ranFolderName;
			$file->Filename = $newFolder->Filename.$ranFolderName.'.jpg';
			$file->ParentID = $newFolder->ID;
			$file->Write();
			
			$data = array(
				"ID" => $file->ID,
				"URL" => $file->getAbsoluteURL()
			);
			
			echo json_encode($data);
		}
	}
	
	public function ordersuccess($request){
		
		//$member = Member::get()->filter(array("ID" => 28))->first();
		//$order = Order::get()->filter(array("ID" => 19))->first();


		if(!$request->getVar('token')){
			$error = array(
				"status" => "error",
				"message" => "No token"
			);
			echo json_encode($error);
			return;
		}
		
		if( ($request->param('ID'))  &&  $order = Order::get()->filter(array(  "ID" => $request->param('ID') ))->first() ){
			if( $order->Member()->exists() && $order->Member()->ApiToken == $request->getVar('token') ){
				if($order->Status == "Created"){
					$order->Status = "Pending";
					$order->write();
				}
				if(!$order->EmailInvoiceSent){
					$from = "info@blippar.co.nz";
					$to = $member->Email;
					$sub = "Blippar Order Confirmation: ".$order->Referance;
					$email = new Email($from,$to,$sub);
					$email->setTemplate("OrderInvoice");
					$email->populateTemplate(new ArrayData(array(
				        'Member' => $member,
						'Order' => $order
				    )));
					$email->send();
					
					$order->EmailInvoiceSent = 1;
					$order->write();
				}
				header("Location: http://blippar.co.nz/pub/#/order-details/".$order->Referance."?paymentsuccess=1"); /* Redirect browser */
				exit();
			}
		}else{
			$error = array(
				"status" => "error",
				"message" => "No order found"
			);
			echo json_encode($error);
		}
	}
	
	public function ordercancel($request){
		Debug::dump($request);
	}
	
	public function MediaItems(){
		return MediaItem::get();
	}
	
	public function createMemberFromGoogle($request){
		
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');

		if($objNew = json_decode($request->getBody())){
			
			if( property_exists($objNew,'Email') && property_exists($objNew,'Surname') && property_exists($objNew,'FirstName') && property_exists($objNew,'ApiToken') ){

				$member = Member::get()->filter(array("Email" => $objNew->Email))->first();
				
				if($member){	
					$error = array(
						'status' => 'error',
						'message' => 'This email address is already taken'
					);
					echo json_encode($error);
				}else{
					$member = new Member();
					$member->FirstName = $objNew->FirstName;
					$member->Surname = $objNew->Surname;
					$member->Email = $objNew->Email;
					$member->ApiToken = $objNew->ApiToken;
					$member->ApiTokenExpire = $objNew->ApiTokenExpire;
					$member->write();
					$member->login();
					
					$group = Group::get()->filter(array("Code" => "blipper"))->first();
					$group->Members()->add($member);
					
					/* email */
					$from = "info@blippar.co.nz";
					$to = $member->Email;
					$sub = "Welcome to Blippar";
					$email = new Email($from,$to,$sub);
					$email->setTemplate("MemberConfirm");
					$email->populateTemplate(new ArrayData(array(
				        'Member' => $member
				    )));
					$email->send();
					
					$error = array(
						'status' => 'success',
						'token' => $member->ApiToken,
						'id' => $member->ID
					);
					echo json_encode($error);
				}
			}else{
				$error = array(
					'status' => 'error',
					'message' => 'Opps! seems your missing some details'
				);
				echo json_encode($error);
			}
			
		}

	}
	
	public function createMember($request){
		
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');

		if($objNew = json_decode($request->getBody())){
			
			if( property_exists($objNew,'Email') && property_exists($objNew,'Surname') && property_exists($objNew,'FirstName') && property_exists($objNew,'Password') ){

				$member = Member::get()->filter(array("Email" => $objNew->Email))->first();
				
				if($member){	
					$error = array(
						'status' => 'error',
						'message' => 'This email address is already taken'
					);
					echo json_encode($error);
				}else{
					$member = new Member();
					$member->FirstName = $objNew->FirstName;
					$member->Surname = $objNew->Surname;
					$member->Email = $objNew->Email;
					$member->Password = $objNew->Password;
					$member->write();
					
					$group = Group::get()->filter(array("Code" => "blipper"))->first();
					$group->Members()->add($member);
					
					/* email */
					$from = "info@blippar.co.nz";
					$to = $member->Email;
					$sub = "Welcome to Blippar";
					$email = new Email($from,$to,$sub);
					$email->setTemplate("MemberConfirm");
					$email->populateTemplate(new ArrayData(array(
				        'Member' => $member
				    )));
					$email->send();
					
					$error = array(
						'status' => 'success',
						'message' => 'All good'
					);
					echo json_encode($error);
				}
			}else{
				$error = array(
					'status' => 'error',
					'message' => 'Opps! seems your missing some details'
				);
				echo json_encode($error);
			}
			
		}

	}
	
	public function upload($request){
		
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');

		if($file = $request->postVar("file")){

			$ranFolderName = $this->generateRandomString();
			
			$baseFolder = Folder::find_or_make('BlipparUploads');
			$newFolder = Folder::find_or_make('BlipparUploads/'.$ranFolderName);

			$newfile = new Image();
			$newfile->ParentID = $newFolder->ID;
			$upload = new Upload();
			$upload->loadIntoFile($file,$newfile,"BlipparUploads/".$ranFolderName);
			$newfile->write();
			
			$data = array(
				'ID' => $newfile->ID,
				'URL' => $newfile->getAbsoluteURL()
			);
			echo json_encode($data);
			
		}else{
			$error = array(
				'status' => 'error',
				'message' => 'No file was found'
			);
			echo json_encode($error);
		}
	}
	/*
	public function upload($request){
		
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');

		if($file = $request->postVar("file")){

			// Create new base folder if none
			$ranFolderName = $this->generateRandomString();
	    	$baseFolder = Director::baseFolder()."/assets/BlipperUploads";
		    if (!file_exists($baseFolder)) {
				 mkdir($baseFolder, 0777, true);
				 chmod($baseFolder,0777);
			}
			$baseFolder = Director::baseFolder()."/assets/BlipperUploads/".$ranFolderName;
		    if (!file_exists($baseFolder)) {
				 mkdir($baseFolder, 0777, true);
				 chmod($baseFolder,0777);
				 $folder = new Folder();
				 $folder->ParentID = 557;
				 $folder->Name = "1111111";
				 $folder->write();
			}
			
			$f = new File();
			$u = new Upload();
			$u->loadIntoFile($file,$f,"BlipperUploads/".$ranFolderName);
			
			return $f->ID;
		}else{
			echo "bad";
		}

	}
	*/
	
	public function image($request){
		if( $file = File::get()->filter( array("ID" => $request->getVar("fileid")) )->first() ){

			$type = $file->getExtension();

			//check if image
			if($type == "jpg" || $type == "jpeg" || $type == "png"){
				$img = new Image();
				$img->Name = $file->Name;
				$img->Filename = $file->Filename;
				$img->ParentID = $file->ParentID;
				$img->Title = $file->Title;
				$img->write();
				
				return $img->CroppedImage(100,100)->getAbsoluteURL();
			}
			
		}
	}
	
	function generateRandomString($length = 10) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}
}
