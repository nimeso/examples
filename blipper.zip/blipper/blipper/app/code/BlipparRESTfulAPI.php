<?php
class BlipparRESTfulAPI extends RESTfulAPI
{
	private static $allowed_actions = array(
		'ResizedImage',
		'DeviceList',
		'Buy',
		'MailTo'
	);
	
	public function MailTo($data){
		
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');

		$obj = json_decode($data->getBody());
		
		$from = $obj->from;
		$to = $obj->to;
		$sub = $obj->subject;
		$body = $obj->body;
		$email = new Email($from,$to,$sub,$body);
		$email->send();
		
		echo json_encode($obj);
		
	}
	
	public function Buy($data){

		if($token = $data->getVar('token')){
			
			header('Access-Control-Allow-Origin: *');
			header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
			header('Access-Control-Allow-Methods: GET, POST, PUT');
			header('Content-Type: application/json');
			
			$obj = json_decode($data->getBody());
	
			$data = array(
				"transactionId" => $obj->ID,
				"firstName" => $obj->FirstName,
				"lastName" => $obj->Surname,
				"email" => $obj->Email,
				"company" => $obj->Company,
				"billingAddress1" => $obj->Address1,
				"billingCity" => $obj->Address4,
				"billingPostcode" => $obj->Address5,
				"billingState" => $obj->Address3,
				"billingCountry" => $obj->Address6,
				"billingPhone" => $obj->Phone,
				"shippingAddress1" => $obj->Address1,
				"shippingCity" => $obj->Address4,
				"shippingPostcode" => $obj->Address5,
				"shippingState" => $obj->Address3,
				"shippingCountry" => $obj->Address6,
				"shippingPhone" => $obj->Phone
			);
			
			if($obj->Address2){
				$data["billingAddress2"] = $obj->Address2;
				$data["shippingAddress2"] = $obj->Address2;
			}
			
			if($order = Order::get()->filter(array("ID" => $obj->ID))->first()){
				$order->FirstName = $obj->FirstName;
				$order->Surname = $obj->Surname;
				$order->Email = $obj->Email;
				$order->Phone = $obj->Phone;
				$order->Company = $obj->Company;
				$order->Address1 = $obj->Address1;
				$order->Address2 = $obj->Address2;
				$order->Address3 = $obj->Address3;
				$order->Address4 = $obj->Address4;
				$order->Address5 = $obj->Address5;
				$order->Address6 = $obj->Address6;
				$order->write();
				
				$payment = Payment::create()->init("PaymentExpress_PxPay", $obj->payment->Amount, "NZD");
				$payment->OrderID = $order->ID;
				$payment->write();
				
			    $response = PurchaseService::create($payment)
		        ->setReturnUrl("http://blippar.co.nz/data/home/ordersuccess/".$order->ID."?token=".$token)
		        ->setCancelUrl("http://blippar.co.nz/pub/checkout?paymentFailed=1")
		        ->purchase($data);

		        echo $response->getRedirectURL();
		        
			}
		}else{
			$error = array(
				"status" => "error",
				"message" => "No auth token"
			);
			echo json_encode($error);
		}

	}
	
	public function DeviceList($request){
		
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');
		
  		$appid = $request->param('ID');
  		if( $device = Device::get()->filter(array("ID" => $appid))->first() ){
  			if($playlist = $device->PlayList()){
  				if($timeSlots = $playlist->TimeSlots()){
  					$list = array();
  					foreach ($timeSlots as $timeSlot){
  						if($mediaItem = $timeSlot->MediaItem()){
  							if($mediaItem->File()->exists()){
  								$timestamp = strtotime($mediaItem->File()->LastEdited);
	  							$data = array(
	  								"ID" => $mediaItem->ID,
	  								"Title" => $mediaItem->Title,
	  								"FileURL" => $mediaItem->File()->getAbsoluteURL(),
	  								"FileName" => $mediaItem->File()->Name,
	  								"Modified" => $timestamp,
	  								"Length" => 10
	  							);
	  							$list[] = $data;
  							}
  						}
  					}
  					echo json_encode($list);
  				}
  			}
  		}
  		
  	}

  	function index(SS_HTTPRequest $request)
  	{

  		if($request->param("ClassName") == "MailTo"){
  			return $this->MailTo($request);
  		}
  		
  		if($request->param("ClassName") == "DeviceList"){
  			return $this->DeviceList($request);
  		}
  		
  		if($request->param("ClassName") == "Buy"){
  			return $this->Buy($request);
  		}
  		
  		if($request->param("ClassName") == "ResizedImage"){
  			return $this->ResizedImage($request);
  		}

	    //check authentication if enabled
	    if ( $this->authenticator )
	    {

	      $policy     = $this->config()->authentication_policy;
	      $authALL    = $policy === true;
	      $authMethod = is_array($policy) && in_array($request->httpMethod(), $policy);

	      if ( $authALL || $authMethod )
	      {
	        $authResult = $this->authenticator->authenticate($request);

	        if ( $authResult instanceof RESTfulAPI_Error )
	        {
	          //Authentication failed return error to client
	          return $this->error($authResult);
	        }
	      }
	    }

	    //pass control to query handler
	    $data = $this->queryHandler->handleQuery( $request );
	    //catch + return errors
	    if ( $data instanceof RESTfulAPI_Error )
	    {
	      return $this->error($data);
	    }

	    //serialize response
	    $json = $this->serializer->serialize( $data );
	    //catch + return errors
	    if ( $json instanceof RESTfulAPI_Error )
	    {
	      return $this->error($json);
	    }

	    //all is good reply normally
	    return $this->answer($json);
  	}

	protected function unformatPayloadData(array $data)
	{
		$unformattedData = array();

		foreach ($data as $key => $value)
		{
			$newKey = $this->deserializeColumnName( $key );

    	if ( is_array($value) )
    	{
    		$newValue = $this->unformatPayloadData($value);
    	}
    	else{
    		$newValue = $value;
    	}

    	$unformattedData[$newKey] = $newValue;
		}

		return $unformattedData;
	}

  	/*
  	 * avalible resize values
  	 * cropped, padded, setwidth, setheight, ratio
  	 * setwidth will be used by default
  	 */
	public function ResizedImage(SS_HTTPRequest $request){
		
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, cache-control");
		header('Access-Control-Allow-Methods: GET, POST, PUT');
		header('Content-Type: application/json');

		if( $image = Image::get()->filter("ID",$request->param("ID"))->first() ){
			$type = $request->getVar("ResizeMethod");
			$str = '';
			$errStr = false;
			switch ($type) {
			    case "cropped":
			    	if(!$request->getVar("Width") || !$request->getVar("Height")){
			    		$errStr = "You must set a Width and Height";
			    	}
			        $resizedImage = $image->CroppedImage($request->getVar("Width"),$request->getVar("Height"))->AbsoluteURL;

			    case "padded":
					if(!$request->getVar("Width") || !$request->getVar("Height")){
			    		$errStr = "You must set a Width and Height";
			    	}
			        $resizedImage = $image->PaddedImage($request->getVar("Width"),$request->getVar("Height"))->AbsoluteURL;

			    case "setheight":
					if(!$request->getVar("Height")){
			    		$errStr = "You must set a Height";
			    	}
			        $resizedImage = $image->SetHeight($request->getVar("Height"))->AbsoluteURL;

			    case "ratio":
			    	if(!$request->getVar("Width") || !$request->getVar("Height")){
			    		$errStr = "You must set a Width and Height";
			    	}
			        $resizedImage = $image->SetRatioSize($request->getVar("Width"),$request->getVar("Height"))->AbsoluteURL;

			    default:
			    	if(!$request->getVar("Width")){
			    		$errStr = "You must set a Width";
			    	}
			    	$resizedImage = $image->SetWidth($request->getVar("Width"))->AbsoluteURL;
			}
			
			if($errStr){
				$error = array(
					"status" => "error",
					"message" => $errStr
				);
				echo json_encode($error);
				exit();
			}
			
			$data = array(
				"url" => $resizedImage
			);
			
			echo json_encode($data);
			
		}else{
			$error = array(
				"status" => "error",
				"message" => "No image found"
			);
			echo json_encode($error);
		}

	}

}