<?php
class MediaItemAdmin extends ModelAdmin{

	private static $menu_title = "Media Items";
	private static $url_segment = "mediaitems";
	//private static $menu_icon = 'mysite/images/icons/applications.png';
	private static $menu_priority = 2;

	private static $managed_models = array(
		'MediaItem'
	);

}