$(function() {


  $('body').on('click', 'a[href*="#"]', function(e) {
    if ($(e.target).hasClass('nojump')) {
        return false;
    }
    var hash = this.href.split('#')[1];
    jumpTo($('#' + hash));
    return false;
  });




$('#MapTabs a.tabtrigger').on('click', function (e) {
  e.preventDefault();
  //alert('yo');
  $(this).tab('show');
});





var $igrid = $('.igrid').isotope({
  itemSelector: '.grid-item', // use a separate class for itemSelector, other than .col-
  percentPosition: true,
  masonry: {
    columnWidth: '.grid-sizer'
  }
});

$igrid.imagesLoaded().progress( function() {
  $igrid.isotope('layout');
});







$('.case-study-filter-list').on( 'click', 'a', function() {
  var filterValue = $(this).attr('data-filter');
  $igrid.isotope({ filter: filterValue });
});

$('.news-filter-list').on( 'click', 'a', function() {
  var filterValue = $(this).attr('data-filter');
  $igrid.isotope({ filter: filterValue });
});




  $('body').on('click','.accordion-item__header',function(){
    $('.accordion-item__header[aria-expanded=true]').not(this).trigger('click');
  });

  $('#market-filters').on('click', 'a', function(e) {
    e.preventDefault();
    var speed = 300;
    var filterValue = $(this).attr('data-filter');
    if (filterValue == "*") {
      $('.accordionblock-element:hidden').slideDown(speed);
    } else {
      $('.accordionblock-element'+filterValue+':hidden').slideDown(speed);
      $('.accordionblock-element').not(filterValue).slideUp(speed);
    }
  });




  // Collapse Navbar
  var navbarCollapse = function() {
    if ($("#MainNav").offset().top > 100) {
      $("#MainNav").addClass("navbar-scrolled");
    } else {
      $("#MainNav").removeClass("navbar-scrolled");
    }

    if ($("#MainNav").offset().top > 420) {
      $("body").addClass("fixed-breadcrumbs");
    } else {
      $("body").removeClass("fixed-breadcrumbs");
    }
  };
  // Collapse now if page is not at top
  navbarCollapse();
  // Collapse the navbar when page is scrolled
  $(window).scroll(navbarCollapse);




  if ($(window).width() > 768) {

    // $(".dropdown-menu").each(function() {
    //   $(this).width($(this).width() + 10);
    // });

    $('body')
      .on('mouseenter mouseleave', '.dropdown', toggleDropdown)
      .on('click', '.dropdown-menu a', toggleDropdown);
  }else{
    //$('body').on('click', '.dropdown .mobile-drop', toggleMobileDropdown);
  }
  

  if($('[data-carousel]').length>0){
  var $options = {
    cellSelector: '.carousel-cell',
    pageDots: false,
    wrapAround: true,
    autoPlay: 8000,
    fade: true,
    arrowShape: {
      x0: 10,
      x1: 60,
      y1: 50,
      x2: 60,
      y2: 45,
      x3: 15
    }
  };
  var $carousel = $('[data-carousel]').removeClass('is-hidden');
  // trigger redraw for transition
  $carousel[0].offsetHeight;
  // init Flickity
  $carousel.flickity($options);
  var $slideContent = $('.slide-content');
  var flkty = $carousel.data('flickity');
  var selectedSlide = flkty.selectedElement;
  flkty.on('settle', function(index) {
    //selectedSlide = flkty.selectedElement;
  });
  };
  


});

function jumpTo(div) {
  var offset = 20;
  offset += $('#headerAndNav').outerHeight();
  $("body, html")
    .animate({
      scrollTop: div.offset().top - offset
    }, 400);
}

function toggleDropdown(e) {
    var _d = $(e.target).closest('.dropdown'),
      _m = $('.dropdown-menu', _d);
    setTimeout(function() {
      var shouldOpen = e.type !== 'click' && _d.is(':hover');
      _m.toggleClass('show', shouldOpen);
      _d.toggleClass('show', shouldOpen);
      $('[data-toggle="dropdown"]', _d).attr('aria-expanded', shouldOpen);
    }, e.type === 'mouseleave' ? 50 : 0);
}
function toggleMobileDropdown(e) {
    var _m = $('.dropdown-menu');
      _m.toggleClass('show');
}

/* hidden main menu */
$('#nav-icon').click(function(e){
  $(this).parent().find('ul').toggleClass('open');
  $(this).toggleClass('open');
});


$.featherlightGallery.prototype.afterContent = function() {
  debugger
  var caption = this.$currentTarget.find('img').attr('alt');
  this.$instance.find('.caption').remove();
  $('<div class="caption">').text(caption).appendTo(this.$instance.find('.featherlight-content'));
};




