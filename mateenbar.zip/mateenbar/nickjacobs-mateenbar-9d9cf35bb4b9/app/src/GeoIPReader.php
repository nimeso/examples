<?php

use GeoIp2\Database\Reader;
use SilverStripe\SiteConfig\SiteConfig;
use SilverStripe\Core\Config\Config;
use SilverStripe\Control\Controller;
use SilverStripe\Security\Permission;
/**
 * Class GeoIPReader
 */
class GeoIPReader
{
    /**
     * @var \GeoIp2\Model\Country|null
     */
    private $reader;

    /**
     * Test IP's
     * @var array
     */
    private static $testIPs = [
      'US' => '198.7.59.119',
      'AU' => '120.145.29.239',
      'NZ' => '122.56.102.57',
      'GB' => '213.208.35.38',
      'CA' => '192.206.151.131',
      'EU' => '85.214.132.117',
      'AE' => '2.51.255.255',
    ];

    /**
     * @var
     */
    private $isoCode;

    /**
     * @var array|false|string
     */
    private $ip;

    /**
     * @var
     */
    private $country;

    /**
     * @var
     */
    private $currency;


    /**
     * GeoIPReader constructor.
     * @param string $ip
     * @throws Exception
     */
    public function __construct(string $ip = '')
    {
        $this->reader = $this->setReader();
        if ($this->reader) {
            $this->ip = (!empty($ip))
              ? $ip
              : $this->getUserIP();
            $this->setCountry($this->getIP());
        }
    }

    /**
     * @return array|false|string
     */
    public function getIP()
    {
        return $this->ip;
    }

    /**
     * @return array|false|string
     */
    public function getUserIP()
    {

        if (isset($_SERVER)) {
            if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {
                $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
                if ($ip != '' && strtolower($ip) != 'unknown') {
                    $addresses = explode(',', $ip);
                    return $addresses[count($addresses) - 1];
                }
            }

            if (isset($_SERVER["HTTP_CLIENT_IP"]) && $_SERVER["HTTP_CLIENT_IP"] != '') {
                return $_SERVER["HTTP_CLIENT_IP"];
            }

            return $_SERVER["REMOTE_ADDR"];
        }

        if ($ip = getenv('HTTP_X_FORWARDED_FOR')) {
            if (strtolower($ip) != 'unknown') {
                $addresses = explode(',', $ip);
                return $addresses[count($addresses) - 1];
            }
        }

        if ($ip = getenv('HTTP_CLIENT_IP')) {
            return $ip;
        }

        return getenv('REMOTE_ADDR');
    }

    /**
     * Get the file path for Maxminds MDDB
     *
     * You can either add it from the config or
     * Site Settings in the admin
     *
     * @return array|bool|mixed|scalar|string
     */
    private function getPath()
    {
        /** @var SiteConfigExtension|SiteConfig $siteConfig */
        $siteConfig = SiteConfig::current_site_config();

        // Get path from Site Config or current classes config
        return ($geoPathAdmin = $siteConfig->getField('GeoPath'))
          ? $geoPathAdmin
          : Config::inst()->get('GeoIPReader', 'GeoPath');
    }

    /**
     * @return bool|Reader
     */
    private function setReader()
    {
        $reader = false;        
        if ($path = $this->getPath()) {            
            if (file_exists($path)) {                
                try {
                    $reader = new Reader($path);                    
                } catch (\MaxMind\Db\Reader\InvalidDatabaseException $e) {                    
                    error_log($e);
                } finally {
                    return $reader;
                }
            }
        }
        return false;
    }

    /**
     * Get reader
     * @return \GeoIp2\Model\Country|null
     */
    public function getReader()
    {
        return $this->reader;
    }


    /**
     * Set the currency
     *
     * @bonus Dev will fake it randomly to avoid local IP
     * @bonus You can also use URL Parameter ?geo=US to render US currency
     * @param $ip
     * @return $this
     * @throws Exception
     */
    public function setCountry($ip)
    {
        $ips = self::$testIPs;

        if (Config::inst()->get('GeoIPReader', 'fake-ip')) {
            //  Grab a test IP as local will
            // pull an IP that won't work
            $ip = $ips[array_rand($ips)]; // grab random IP
        }

        if (Permission::check('ADMIN')) {
            // fake city with a url param ?geo=NZ
            $request = Controller::curr()->getRequest();
            if ($checkParam = $request->getVar('geo')) {
                $ipKey = strtoupper($checkParam);
                if (array_key_exists($ipKey, $ips)) {
                    $ip = $ips[$ipKey];
                }
            }
        }
        if ($ip) {
            $isoCode = 'NZ';
            $countryModel = $this->getCountryFromIP($ip);
            if ($countryModel) {
                if (property_exists($countryModel, 'country')) {
                    $this->country = $countryModel->country;
                    $record = $this->country;
                    $isoCode = $record->isoCode;
                }
                $this->isoCode = $isoCode;
            }
        }
        return $this;
    }

    /**
     * Get country from IP
     * @param $ip
     * @return bool|\GeoIp2\Model\Country
     */
    public function getCountryFromIP($ip)
    {
        /** @var  GeoIp2\Database\Reader $reader */
        $reader = $this->getReader();
        $country = false;
        if (method_exists($reader, 'country')) {
            try {
                $country =  $reader->country($ip);
            } catch (\GeoIp2\Exception\AddressNotFoundException $e) {
                error_log($e);
            } catch (\MaxMind\Db\Reader\InvalidDatabaseException $e) {
                error_log($e);
            } finally {
                return $country;
            }
        }
        return $country;
    }


    /**
     * @return mixed
     */
    public function getCountry()
    {
        if (method_exists($this->country, 'name')) {
            return $this->country->name;
        }
        return false;
    }

    /**
     * Return the isoCode generated from GeoIP reader
     * @see GeoIPData::setCurrency() on how it's matched
     *
     * @return mixed
     * @throws Exception
     */
    public function getIsoCode()
    {
        return $this->isoCode;
    }


    /**
     * Set Currency
     * @param $currency
     */
    public function setCurrency($currency)
    {
        $this->currency = $currency ?? 0;
    }

    /**
     * et ABM currency code
     * @return int
     */
    public function getCurrency()
    {
        return $this->currency ?? 0;
    }

    /**
     * Fake the currency
     *
     * @param string $code NZ, GB, US
     * @param bool $returnCurrency
     * @return bool
     * @throws Exception
     */
    public function fakeCurrency(string $code, $returnCurrency = false)
    {
        $ips = self::$testIPs;
        $keys = implode(', ', array_keys($ips));

        if (array_key_exists($code, $ips)) {
            $this->setCountry($ips[$code]);
            if ($returnCurrency) {
                return $this->currency;
            }
        } else {
            throw new Exception('No IP associated with the code ' . $code . '. Try one of these codes: ' . $keys);
        }
        return false;
    }

}