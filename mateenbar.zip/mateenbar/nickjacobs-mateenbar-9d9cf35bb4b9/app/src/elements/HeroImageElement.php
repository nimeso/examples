<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Assets\Image;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;

class HeroImageElement extends BaseElement
{

    private static $db = [        
        'Content' => 'HTMLText',
    ];
    private static $has_one = [        
        'Image' => Image::class
    ];

    private static $owns = [
        'Image',
    ];

    private static $singular_name = 'Hero image element';
    private static $plural_name   = 'Hero image elements';
    private static $description   = 'Large image embed';

    private static $table_name = 'Elements_HeroImageElement';

    private static $icon = 'font-icon-image';

    //private static $controller_template = 'ElementsHolder';

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->addFieldToTab(
            'Root.Main',
            HTMLEditorField::create('Content', 'Content')
        );

        
       
        $fields->addFieldToTab(
            'Root.Main',
            $image = UploadField::create('Image', 'Upload an image file') ,'Content'
         );      
        $image->setAllowedExtensions(array('jpg','jpeg','png','gif'));
        $image->setFolderName('HeroImages');

        return $fields;
    }

    public function getType()
    {
        return 'Hero image block';
    }

    public function getRenderTemplates($suffix = '')
    {
        return $this->ClassName . $suffix;
    }
}
