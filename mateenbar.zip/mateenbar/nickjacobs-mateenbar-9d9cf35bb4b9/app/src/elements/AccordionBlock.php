<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Assets\Image;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\Forms\CheckboxSetField;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\ORM\ArrayList;
use SilverStripe\View\ArrayData;
use Market;


class AccordionBlock extends BaseElement
{
    private static $icon = 'font-icon-list';

    private static $inline_editable = true;

    private static $db = [
        
        'Content' => 'HTMLText',
        'PosNum'   => 'Boolean', 
        'Heading' => "Varchar",
        'Criteria' => "Varchar",
    ];

    private static $has_one = [
        'Image'   => Image::class, 
    ];

    private static $many_many = [
        'Markets'   => Market::class, 
    ];

    private static $owns = [
        'Image'
    ];

    private static $defaults = [
        'ShowTitle' => true
    ];

    private static $singular_name = 'Accordion block';
    private static $plural_name   = 'Accordion blocks';
    private static $description   = 'Accordion block with image and text';

    private static $table_name = 'Elements_AccordionBlock';

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->removeByName(array(
            'Content','PosNum','Heading','Criteria','Image'
        ));

        $source = Market::get()->map('ID', 'Title');

        $fields->addFieldsToTab("Root.Main", array(

            CheckboxField::create('PosNum','Show the position number on this accordion'),
            TextField::create('Heading','Content heading'),

            HTMLEditorField::create('Content')->setRows(6),
            $image = UploadField::create('Image','Image - normal image formats (jpg, png etc)'),  
            TextField::create('Criteria','Criteria advantages - enter as a comma separated list'), 
            CheckboxSetField::create('Markets','Select markets which apply', $source)
              
        ));

        $image->setFolderName('ElementImages');
       
        return $fields;
    }


    public function PaddedPos()
    {
        $num = $this->Pos();
        $num_padded = sprintf("%02d", $num);
        return $num_padded;
    }



    public function getRenderTemplates($suffix = '')
    {
        return  $this->ClassName . $suffix;
    }

    public function getType()
    {
        return 'Accordion Block';
    }

    
    public function getSummary()
    {
        $summary="";
        if($this->Heading)
            $summary = $this->Heading;       

        if($this->Disabled)
            $summary = 'DISABLED | ' . $summary;      
        return DBField::create_field('HTMLText', $summary)->Summary(20);
    }

    public function CriteriaList()
    {
        $crits = explode(',',$this->Criteria);
        $critlist = new ArrayList();
        foreach($crits as $item) {
            $critlist->push(
                new ArrayData(array('Item' => $item))
            );
        }
        return $critlist;
    }




    /**
     * @return array
     */
    protected function provideBlockSchema()
    {
        $blockSchema = parent::provideBlockSchema();
        $blockSchema['content'] = $this->getSummary();
        return $blockSchema;
    }

     


}
