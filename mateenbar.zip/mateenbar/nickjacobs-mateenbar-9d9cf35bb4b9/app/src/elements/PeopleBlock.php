<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Assets\Image;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\Forms\DropdownField;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
use SilverStripe\Forms\TextareaField;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\NumericField;
use SilverStripe\Forms\HeaderField;
use SilverStripe\ORM\FieldType\DBField;
use Sheadawson\Linkable\Models\Link;
use Sheadawson\Linkable\Forms\LinkField;


class PeopleBlock extends BaseElement
{
    private static $icon = 'font-icon-torso';

    private static $inline_editable = true;

    private static $db = [
        
        'Qualifications'   => 'Varchar(255)' ,
        'Position'   => 'Varchar(255)',
        'Content' => 'HTMLText'

    ];

    private static $has_one = [
        'Image'   => Image::class        
    
    ];
    private static $owns = [
        'Image',
    ];

    private static $defaults = [
        'ShowTitle'  => true
    ];

    private static $singular_name = 'People block';
    private static $plural_name   = 'People blocks';
    private static $description   = 'Staff/People block with image and text';

    private static $table_name = 'Elements_PeopleBlock';

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->removeByName(array(
            'Content','Position','Qualifications','PrimaryHeading','Linethrough','HeadingLevel','ModulePadding'
        ));

        $fields->addFieldsToTab("Root.Main", array( 
            $quals = TextField::create('Qualifications', 'Qualifications (optional)'), 
            $position = TextField::create('Position', 'Position'), 
            HTMLEditorField::create('Content')->setRows(6),
            $image = UploadField::create('Image')->setIsMultiUpload(false),                      
                
        ));        
        $image->setFolderName('PeopleImages');
        
       
        return $fields;
    }

    public function getRenderTemplates($suffix = '')
    {
        return  $this->ClassName . $suffix;
    }

    public function getType()
    {
        return 'People Block';
    }

    
   

    public function getSummary()
    {
        $summary="";
        if($this->Content)
            $summary = $this->Content;
        if($this->Disabled)
            $summary = 'DISABLED | ' . $summary;      
        return DBField::create_field('HTMLText', $summary)->Summary(20);
    }

    /**
     * @return array
     */
    protected function provideBlockSchema()
    {
        $blockSchema = parent::provideBlockSchema();
        $blockSchema['content'] = $this->getSummary();
        return $blockSchema;
    }


}
