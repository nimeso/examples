<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Assets\File;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;

class VideoElement extends BaseElement
{

    private static $db = [
        'VideoEmbedCode'   => 'Varchar',
        'Content' => 'HTMLText',
    ];
    private static $has_one = [        
        'Transcript' => File::class
    ];

    private static $owns = [
        'Transcript',
    ];

    private static $singular_name = 'Video element';
    private static $plural_name   = 'Video elements';
    private static $description   = 'Video embed';

    private static $table_name = 'Elements_VideoElement';

    private static $icon = 'font-icon-block-media';

    //private static $controller_template = 'ElementsHolder';

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->addFieldToTab(
            'Root.Main',
            HTMLEditorField::create('Content', 'Content')
        );

        
        $fields->addFieldToTab('Root.Main', TextField::create('VideoEmbedCode', 'Video Embed Code')->setDescription('This is the vimeo ID, ie if the URL is https://vimeo.com/253989945 - use 253989945 here'));       

        $fields->addFieldToTab(
            'Root.Main',
            $transcript = UploadField::create('Transcript', 'Upload a transcript file for this video') 
         );      
        $transcript->setAllowedExtensions(array('docx','txt','pdf'));
        $transcript->setFolderName('VideoTranscripts');

        return $fields;
    }

    public function getType()
    {
        return 'Video block';
    }

    public function getRenderTemplates($suffix = '')
    {
        return $this->ClassName . $suffix;
    }
}
