<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\GridField\GridField;
use SilverStripe\Forms\GridField\GridFieldAddExistingAutocompleter;
use SilverStripe\Forms\GridField\GridFieldDeleteAction;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\ORM\FieldType\DBHTMLText;
use SilverStripe\Forms\DropdownField;
use Symbiote\GridFieldExtensions\GridFieldOrderableRows;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\Forms\LiteralField;
use SilverStripe\Forms\HeaderField;
use GalleryItem;

/**
 * Class TeamElement
 *
 * @property string $Content
 *
 * @method \SilverStripe\ORM\HasManyList InfoLinkPanels()
 */
class GalleryBlock extends BaseElement
{
    /**
     * @var string
     */
    private static $icon = 'font-icon-image';

    /**
     * @var string
     */
    private static $table_name = 'Elements_GalleryBlock';

    /**
     * @var array
     */
    private static $db = [
        'Content' => 'HTMLText',
        'GridPopupStyle' => 'Boolean'
    ];

    /**
     * @var array
     */
    private static $has_many = array(
        'GalleryItems' => GalleryItem::class,
    );

    /**
     * Set to false to prevent an in-line edit form from showing in an elemental area. Instead the element will be
     * clickable and a GridFieldDetailForm will be used.
     *
     * @config
     * @var bool
     */
    private static $inline_editable = false;

    /**
     * @param bool $includerelations
     * @return array
     */
    public function fieldLabels($includerelations = true)
    {
        $labels = parent::fieldLabels($includerelations);
        $labels['GalleryItems'] = _t(__CLASS__ . '.ItemsLabel', 'Gallery items');

        return $labels;
    }

    /**
     * @return FieldList
     */
    public function getCMSFields()
    {
        $this->beforeUpdateCMSFields(function ($fields) {
            /* @var FieldList $fields */
            $fields->removeByName(array(
                'Sort','GridPopupStyle'
            ));
            
            $fields->dataFieldByName('Content')
                ->setRows(8)
                ->setTitle('Content'); 
            
            $fields->addFieldToTab('Root.Main', CheckboxField::create('GridPopupStyle','Show gallery as a grid of popups'));

            $fields->addFieldToTab('Root.Main', HeaderField::create('hf1','Gallery items'));
            
            if ($this->ID) {
                /** @var GridField $panels */
                $panels = $fields->dataFieldByName('GalleryItems');
                $panels->setTitle($this->fieldLabel('GalleryItems'));              

                $fields->removeByName('GalleryItems');
                $config = $panels->getConfig();
                $config->addComponent(new GridFieldOrderableRows('Sort'));
                $config->removeComponentsByType(GridFieldAddExistingAutocompleter::class);
                $config->removeComponentsByType(GridFieldDeleteAction::class);

                $fields->addFieldToTab('Root.Main', $panels); 
            }
        });

        return parent::getCMSFields();
    }
    

    /**
     * @return DBHTMLText
     */
    public function getSummary()
    {
        $count = $this->GalleryItems()->count();
        $label = _t(
            InfoLinkPanel::class . '.PLURALS',
            '{count} Gallery item|{count} Gallery items',
            [ 'count' => $count ]
        );
        if($this->Disabled)
            $label = 'DISABLED | ' . $label;
        return DBField::create_field('HTMLText', $label)->Summary(20);
    }


    public function getRenderTemplates($suffix = '')
    {
        return  $this->ClassName . $suffix;
    }

    /**
     * @return array
     */
    protected function provideBlockSchema()
    {
        $blockSchema = parent::provideBlockSchema();
        $blockSchema['content'] = $this->getSummary();
        return $blockSchema;
    }

    /**
     * @return string
     */
    public function getType()
    {
        return _t(__CLASS__.'.BlockType', 'Gallery block');
    }

    

}
