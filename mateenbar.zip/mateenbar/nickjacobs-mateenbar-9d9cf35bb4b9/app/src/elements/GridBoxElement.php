<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\GridField\GridField;
use SilverStripe\Forms\GridField\GridFieldAddExistingAutocompleter;
use SilverStripe\Forms\GridField\GridFieldDeleteAction;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\ORM\FieldType\DBHTMLText;
use SilverStripe\Forms\DropdownField;
use Symbiote\GridFieldExtensions\GridFieldOrderableRows;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\Forms\LiteralField;
use GridBoxItem;

/**
 * Class TeamElement
 *
 * @property string $Content
 *
 * @method \SilverStripe\ORM\HasManyList InfoLinkPanels()
 */
class GridBoxElement extends BaseElement
{
    /**
     * @var string
     */
    private static $icon = 'font-icon-thumbnails';

    /**
     * @var string
     */
    private static $table_name = 'Elements_GridBoxElement';

    /**
     * @var array
     */
    private static $db = [
        'Content' => 'HTMLText',
        //'BordersBetween' => 'Boolean',
        'Columns' => 'Varchar' ,
        'DisplayAsList' => 'Boolean' ,
        'UseBottomBorders' => 'Boolean',
        'TileHeader' => 'Enum("h3,h4,h5")'  
    ];

    /**
     * @var array
     */
    private static $has_many = array(
        'GridBoxItems' => GridBoxItem::class,
    );

    /**
     * Set to false to prevent an in-line edit form from showing in an elemental area. Instead the element will be
     * clickable and a GridFieldDetailForm will be used.
     *
     * @config
     * @var bool
     */
    private static $inline_editable = false;

    /**
     * @param bool $includerelations
     * @return array
     */
    public function fieldLabels($includerelations = true)
    {
        $labels = parent::fieldLabels($includerelations);
        $labels['GridBoxItems'] = _t(__CLASS__ . '.ItemsLabel', 'Grid box items');

        return $labels;
    }

    /**
     * @return FieldList
     */
    public function getCMSFields()
    {
        $this->beforeUpdateCMSFields(function ($fields) {
            /* @var FieldList $fields */
            $fields->removeByName(array(
                'Sort'
            ));
            
            $fields->dataFieldByName('Content')
                ->setRows(8)
                ->setTitle('Content'); 

            $fields->addFieldToTab('Root.Main', LiteralField::create('lf1','<h3>Grid items</h3><p>Add items below which will apear as columns - with image and text content - this will work best with four or less panels.<br/><br/></p>'));
            $fields->addFieldToTab('Root.Main', DropdownField::create('Columns','Set the column width',[''=>'Auto','col-md-12'=>'FullWidth','col-md-6'=>'Halfs','col-md-4'=>'Thirds','col-md-3'=>'Quarters'])->setDescription('Set to Auto to use a sensible width based on number of panels'));            
            $fields->addFieldToTab('Root.Main', CheckboxField::create('DisplayAsList','Display as list with icons/images at left?'));
            $fields->addFieldToTab('Root.Main', CheckboxField::create('UseBottomBorders','Use bottom borders?'));

            $fields->addFieldToTab('Root.Main',DropdownField::create(
                        'TileHeader',
                        'Tiles header size',
                            array(                    
                                'h3' => 'h3',
                                'h4' => 'h4',
                                'h5' => 'h5',
                            )
                    )
            );

            if ($this->ID) {
                /** @var GridField $panels */
                $panels = $fields->dataFieldByName('GridBoxItems');
                $panels->setTitle($this->fieldLabel('GridBoxItems'));              

                $fields->removeByName('GridBoxItems');
                $config = $panels->getConfig();
                $config->addComponent(new GridFieldOrderableRows('Sort'));
                $config->removeComponentsByType(GridFieldAddExistingAutocompleter::class);
                $config->removeComponentsByType(GridFieldDeleteAction::class);

                $fields->addFieldToTab('Root.Main', $panels);                
            }
        });

        return parent::getCMSFields();
    }



    public function ColumnTag()
    {
        if(!$this->Columns) {
            $count = $this->GridBoxItems()->count();
            switch ($count) {
                case 1:
                    return 'col-md-12';
                case 2:
                    return 'col-md-6';
                case 3:
                    return 'col-md-4';
                case 4:
                    return 'col-md-3';
                default:
                    return 'col-md-4';
            }
        }
        return $this->Columns;
    }

    public function TileHeaderTag()
    {
        return $this->TileHeader ? $this->TileHeader : 'h3';
    }

    /**
     * @return DBHTMLText
     */
    public function getSummary()
    {
        $count = $this->GridBoxItems()->count();
        $label = _t(
            InfoLinkPanel::class . '.PLURALS',
            '{count} Grid box item|{count} Grid box items',
            [ 'count' => $count ]
        );
        if($this->Disabled)
            $label = 'DISABLED | ' . $label;
        return DBField::create_field('HTMLText', $label)->Summary(20);
    }


    public function getRenderTemplates($suffix = '')
    {
        return  $this->ClassName . $suffix;
    }

    /**
     * @return array
     */
    protected function provideBlockSchema()
    {
        $blockSchema = parent::provideBlockSchema();
        $blockSchema['content'] = $this->getSummary();
        return $blockSchema;
    }

    /**
     * @return string
     */
    public function getType()
    {
        return _t(__CLASS__.'.BlockType', 'Grid box');
    }

    

}
