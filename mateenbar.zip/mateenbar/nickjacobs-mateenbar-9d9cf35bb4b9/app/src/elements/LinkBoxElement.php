<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\GridField\GridField;
use SilverStripe\Forms\GridField\GridFieldAddExistingAutocompleter;
use SilverStripe\Forms\GridField\GridFieldDeleteAction;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\ORM\FieldType\DBHTMLText;
use Symbiote\GridFieldExtensions\GridFieldOrderableRows;
use SilverStripe\Forms\CheckboxField;
use LinkBox;

/**
 * Class ElementAccordion
 * @package Dynamic\Elements\Accordion\Elements
 *
 * @property string $Content
 *
 * @method \SilverStripe\ORM\HasManyList Panels()
 */
class LinkBoxElement extends BaseElement
{
    /**
     * @var string
     */
    private static $icon = 'font-icon-link';

    /**
     * @var string
     */
    private static $table_name = 'Elements_LinkBoxElement';

    /**
     * @var array
     */
    private static $db = [                 
    ];

    /**
     * @var array
     */
    private static $has_many = array(
        'LinkBoxes' => LinkBox::class,
    );

    /**
     * Set to false to prevent an in-line edit form from showing in an elemental area. Instead the element will be
     * clickable and a GridFieldDetailForm will be used.
     *
     * @config
     * @var bool
     */
    private static $inline_editable = false;

    /**
     * @param bool $includerelations
     * @return array
     */
    public function fieldLabels($includerelations = true)
    {
        $labels = parent::fieldLabels($includerelations);
        $labels['LinkBoxes'] = _t(__CLASS__ . '.LinkBoxesLabel', 'Link boxes');

        return $labels;
    }

    /**
     * @return FieldList
     */
    public function getCMSFields()
    {
        $this->beforeUpdateCMSFields(function ($fields) {
            /* @var FieldList $fields */
            $fields->removeByName(array(
                'Sort',
            )); 

                     
            

            if ($this->ID) {
                /** @var GridField $panels */
                $panels = $fields->dataFieldByName('LinkBoxes');
                $panels->setTitle($this->fieldLabel('LinkBoxes'));

                $fields->removeByName('LinkBoxes');

                $config = $panels->getConfig();
                $config->addComponent(new GridFieldOrderableRows('Sort'));
                $config->removeComponentsByType(GridFieldAddExistingAutocompleter::class);
                $config->removeComponentsByType(GridFieldDeleteAction::class);

                $fields->addFieldToTab('Root.Main', $panels);


            }
        });

        return parent::getCMSFields();
    }

    /**
     * @return DBHTMLText
     */
    public function getSummary()
    {
        $count = $this->LinkBoxes()->count();
        $label = _t(
            LinkBox::class . '.PLURALS',
            '{count} Link Box|{count} Link Boxes',
            [ 'count' => $count ]
        );
        if($this->Disabled)
            $label = 'DISABLED | ' . $label;
        return DBField::create_field('HTMLText', $label)->Summary(20);
    }


    public function getRenderTemplates($suffix = '')
    {
        return $this->ClassName . $suffix;
    }

    /**
     * @return array
     */
    protected function provideBlockSchema()
    {
        $blockSchema = parent::provideBlockSchema();
        $blockSchema['content'] = $this->getSummary();
        return $blockSchema;
    }

    /**
     * @return string
     */
    public function getType()
    {
        return _t(__CLASS__.'.BlockType', 'Links block');
    }
}
