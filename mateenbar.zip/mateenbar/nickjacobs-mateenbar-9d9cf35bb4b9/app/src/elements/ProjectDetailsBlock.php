<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Assets\File;
use SilverStripe\Assets\Image;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
use SilverStripe\ORM\FieldType\DBField;

class ProjectDetailsBlock extends BaseElement
{

    private static $db = [        
        'KeyDetails' => 'HTMLText',
    ];
    private static $has_one = [        
        'ProjectImage' => Image::class
    ];

    private static $owns = [
        'ProjectImage',
    ];

    private static $defaults = [
        'Title' => 'Key Details',
        'ShowTitle' => true
    ];

    private static $singular_name = 'Project details block';
    private static $plural_name   = 'Project details block';
    private static $description   = 'Project details block';

    private static $table_name = 'Elements_ProjectDetailsBlock';

    private static $icon = 'font-icon-info-circled';

    //private static $controller_template = 'ElementsHolder';

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->addFieldToTab(
            'Root.Main',
            HTMLEditorField::create('KeyDetails', 'Key Details')
        );
     

        $fields->addFieldToTab(
            'Root.Main',
            $image = UploadField::create('ProjectImage', 'Upload a project image') 
         );      
        $image->setAllowedExtensions(array('jpg','png'));
        
        if($this->owner->getPage()){
            $image->setFolderName('CaseStudies/'.$this->owner->getPage()->URLSegment);
        }else {
            $image->setFolderName('CaseStudyImages');
        }
        

        return $fields;
    }

    public function getSummary()
    {
       $summary = $this->KeyDetails;
       if($this->Disabled)
            $summary = 'DISABLED | ' . $summary;
       return DBField::create_field('HTMLText', $summary)->Summary(20);
    }

    public function getType()
    {
        return 'Project details block';
    }

    public function getRenderTemplates($suffix = '')
    {
        return $this->ClassName . $suffix;
    }
}
