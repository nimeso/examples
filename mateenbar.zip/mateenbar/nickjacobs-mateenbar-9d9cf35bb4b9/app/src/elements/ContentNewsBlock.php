<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\GridField\GridField;
use SilverStripe\Forms\GridField\GridFieldAddExistingAutocompleter;
use SilverStripe\Forms\GridField\GridFieldDeleteAction;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\ORM\FieldType\DBHTMLText;
use SilverStripe\Forms\DropdownField;
use Symbiote\GridFieldExtensions\GridFieldOrderableRows;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\Forms\LiteralField;
use SilverStripe\Forms\HeaderField;
use SilverStripe\Blog\Model\BlogPost;


class ContentNewsBlock extends BaseElement
{

    private static $icon = 'font-icon-columns';
    private static $table_name = 'Elements_ContentNewsBlock';
    private static $inline_editable = false;

    public function getType()
    {
        return _t(__CLASS__.'.BlockType', 'Content and News Block');
    }

    private static $db = [
        'Content' => 'HTMLText'
    ];

    public function getCMSFields()
    {
        $this->beforeUpdateCMSFields(function ($fields) {
            $fields->removeByName(array(
                'Sort'
            ));
            
            $fields->dataFieldByName('Content')
                ->setRows(8)
                ->setTitle('Content'); 
        });

        return parent::getCMSFields();
    }

    public function LatestPosts() {
        return BlogPost::get()->limit(2);
    }

}
