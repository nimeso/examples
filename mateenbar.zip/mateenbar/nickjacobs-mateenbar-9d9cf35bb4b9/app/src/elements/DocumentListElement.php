<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use gorriecoe\LinkField\LinkField;
use gorriecoe\Link\Models\Link;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
use SilverStripe\Forms\DropdownField;
use SilverStripe\Forms\NumericField;
use SilverStripe\Forms\HeaderField;
use SilverStripe\Forms\LiteralField;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\Assets\File;
use SilverStripe\Forms\GridField\GridField;
use SilverStripe\Forms\GridField\GridFieldConfig_RelationEditor;
use Colymba\BulkUpload\BulkUploader;
use Symbiote\GridFieldExtensions\GridFieldOrderableRows;
use Silverstripe\SiteConfig\SiteConfig;
use UncleCheese\DisplayLogic\Forms\Wrapper;
use DocumentItem;


class DocumentListElement extends BaseElement
{
    private static $icon = 'font-icon-block-file-list';

    private static $inline_editable = false;

    private static $db = [ 
        'Content' => 'HTMLText',        
    ];

    private static $many_many = array(
        'Documents' => DocumentItem::class
    );

    private static $many_many_extraFields = [
        'Documents' => [
            'SortOrder' => 'Int'
        ],
    ];

    private static $defaults = [];

    private static $singular_name = 'Document list element';
    private static $plural_name   = 'Document list elements';
    private static $description   = 'Document list element';

    private static $table_name = 'Elements_DocumentListElement';

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();
        $fields->removeByName(array('Content','Documents'));       
       
        $fields->addFieldToTab('Root.Main', HTMLEditorField::create('Content', 'Content')->setRows(8));

        
        $fields->addFieldToTab('Root.Main',HeaderField::create('dc','Document control'));

                
        $config = GridFieldConfig_RelationEditor::create(100);               
        $config->addComponent(new BulkUploader());        
        $config->getComponentByType('Colymba\\BulkUpload\\BulkUploader')
            ->setUfSetup('setFolderName', 'Documents');
        $config->addComponent(new \Colymba\BulkManager\BulkManager());        
        $config->addComponent(GridFieldOrderableRows::create('SortOrder'));      
        
       
       $fields->addFieldToTab("Root.Main", 
         
            $gridField = GridField::create('Documents', 'Documents', $this->Documents(), $config) 
         
        );
        $gridField->setConfig($config);



       
        return $fields;
    }


    public function getDocuments()
    {       
        return $this->Documents()->sort('SortOrder');        
    }

    public function getRenderTemplates($suffix = '')
    {
        return $this->ClassName . $suffix;
    }

    public function getType()
    {
        return 'Document List';
    }


    public function getSummary()
    {
       $summary = $this->Content;
       if($this->Disabled)
            $summary = 'DISABLED | ' . $summary;
       return DBField::create_field('HTMLText', $summary)->Summary(20);
    }

    /**
     * @return array
     */
    protected function provideBlockSchema()
    {
        $blockSchema = parent::provideBlockSchema();
        $blockSchema['content'] = $this->getSummary();
        return $blockSchema;
    }
}
