<?php

namespace Elements;

use DNADesign\Elemental\Models\BaseElement;
use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Assets\Image;
use SilverStripe\Assets\File;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\Forms\DropdownField;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
use SilverStripe\Forms\TextareaField;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\NumericField;
use SilverStripe\Forms\HeaderField;
use SilverStripe\ORM\FieldType\DBField;
use Sheadawson\Linkable\Models\Link;
use Sheadawson\Linkable\Forms\LinkField;


class FeatureBlock extends BaseElement
{
    private static $icon = 'font-icon-block-layout';

    private static $inline_editable = true;

    private static $db = [
        
        'Content' => 'HTMLText',
        'ImageCaption'   => 'Varchar(255)', 
        'ImageAlignment' => "Enum('Left,Right','Left')",
        'ImageWidth' => "Enum('Normal,Wide,Narrow,FullWidth','Normal')", 
        'TwoCol' => 'Boolean'
        
        

    ];

    private static $has_one = [
        'Image'   => Image::class, 
        'ImageSVG'   => File::class        
    
    ];
    private static $owns = [
        'Image','ImageSVG'
    ];

    private static $singular_name = 'Feature block';
    private static $plural_name   = 'Feature blocks';
    private static $description   = 'Feature block with image and text';

    private static $table_name = 'Elements_FeatureBlock';

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->removeByName(array(
            'Content','ImageCaption','ImageAlignment','ImageWidth','TwoCol'
        ));

        $fields->addFieldsToTab("Root.Main", array( 
            HTMLEditorField::create('Content')->setRows(6),
            $image = UploadField::create('Image','Image - normal image formats (jpg, png etc)'),
            $imagesvg = UploadField::create('ImageSVG','Image SVG file - this will override the image above'),
            $imagecaption = TextField::create('ImageCaption', 'Caption (optional)'),            
            $imagealign = DropdownField::create('ImageAlignment', 'Image alignment', $this->dbObject('ImageAlignment')->enumValues()),
            $imagewidth = DropdownField::create('ImageWidth', 'Image width', $this->dbObject('ImageWidth')->enumValues()),
            CheckboxField::create('TwoCol','Show content in two columns?')    
        ));

        
        $image->setFolderName('ElementImages');
        $imagesvg->setFolderName('ElementSVGs');
        
       
        return $fields;
    }


    public function ImageCol()
    {
        switch ($this->ImageWidth) {
            case 'Wide':
                $out='col-md-8';
                break;
            case 'Narrow':
                $out='col-md-4';
                break;
            case 'FullWidth':
                $out='col-md-12';
                break;
            default:
                $out='col-md-6';
        }
        return $out;
    }
    public function ContentCol()
    {
        switch ($this->ImageWidth) {
            case 'Wide':
                $out='col-md-4';
                break;
            case 'Narrow':
                $out='col-md-8';
                break;      
            case 'FullWidth':
                $out='col-md-12';
                break;                         
            default:
                $out='col-md-6';
        }
        return $out;
    }



    public function getRenderTemplates($suffix = '')
    {
        return  $this->ClassName . $suffix;
    }

    public function getType()
    {
        return 'Feature Block';
    }

    
   

    public function getSummary()
    {
        $summary="";
        if($this->Content)
            $summary = $this->Content;
        

        if($this->Disabled)
            $summary = 'DISABLED | ' . $summary;      
        return DBField::create_field('HTMLText', $summary)->Summary(20);
    }



    /**
     * @return array
     */
    protected function provideBlockSchema()
    {
        $blockSchema = parent::provideBlockSchema();
        $blockSchema['content'] = $this->getSummary();
        return $blockSchema;
    }

     


}
