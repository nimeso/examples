<?php

namespace {

  use SilverStripe\CMS\Model\SiteTree;
  use SilverStripe\Lumberjack\Model\Lumberjack;	
  //use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
  //use SilverStripe\Forms\TextField;
  //use Sheadawson\Linkable\Models\Link;
  //use Sheadawson\Linkable\Forms\LinkField;
  use SilverStripe\Forms\GridField\GridField;
  use SilverStripe\Forms\GridField\GridFieldConfig_RecordEditor;
  use Symbiote\GridFieldExtensions\GridFieldOrderableRows;


    class CaseStudyHolder extends Page
    {
        private static $db = [
        	
        ];

        private static $has_one = [        	
        	
        ];

        private static $has_many = [
          'Regions' => Region::class,
          'ProjectTypes' => ProjectType::class,
        ];

        private static $defaults = [         
          
        ];

        // private static $extensions = [
        //     Lumberjack::class,
        // ];

        private static $allowed_children = [
            CaseStudyPage::class,
            //Page::class,
        ];

        




      public function getCMSFields()
      {
        $fields = parent::getCMSFields(); 
        
        $fields->addFieldsToTab("Root.Regions",
            GridField::create("Regions", null, $this->Regions(),
                $config = GridFieldConfig_RecordEditor::create()
            )
        );
        if (class_exists("Symbiote\GridFieldExtensions\GridFieldOrderableRows")) {
            $config->addComponent(new GridFieldOrderableRows());
        }

        $fields->addFieldsToTab("Root.ProjectTypes",
            GridField::create("ProjectTypes", null, $this->ProjectTypes(),
                $config = GridFieldConfig_RecordEditor::create()
            )
        );
        if (class_exists("Symbiote\GridFieldExtensions\GridFieldOrderableRows")) {
            $config->addComponent(new GridFieldOrderableRows());
        }


	     return $fields;
	    }


      public function CaseStudyChildren()
      {
        return $this->AllChildren()->filter(['ClassName' => 'CaseStudyPage']);
      }

      public function getLumberjackTitle() {
        return 'Case Studies';
      }


      public function getRegions() {
        return $this->Regions();
      }
      public function getProjectTypes() {
        return $this->ProjectTypes();
      }


	    

    }

    
}
