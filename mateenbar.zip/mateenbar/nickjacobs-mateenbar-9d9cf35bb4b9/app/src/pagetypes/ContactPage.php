<?php

use SilverStripe\Forms\TextField;
use SilverStripe\Forms\HTMLEditor\HTMLEditorField;


class ContactPage extends Page
{
    private static $table_name = 'ContactPage';

    private static $db = [
        //'NotifyEmail' => 'Text',
        'PultronNZDetails' => 'HTMLText',
        'PultronCANDetails' => 'HTMLText',
        'PultronUAEDetails' => 'HTMLText',
    ];

    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        //$fields->addFieldToTab('Root.Main', TextField::create('NotifyEmail','Email address to notify'), 'Content');  

        $fields->addFieldsToTab('Root.Locations', [
            HTMLEditorField::create('PultronNZDetails','Pultron NZ location details'),
            HTMLEditorField::create('PultronCANDetails','Pultron CAN location details'),
            HTMLEditorField::create('PultronUAEDetails','Pultron UAE location details'),

        ]);


        return $fields;
    }

}