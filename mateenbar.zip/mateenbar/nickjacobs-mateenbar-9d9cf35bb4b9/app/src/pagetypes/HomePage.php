<?php

namespace {

  use SilverStripe\CMS\Model\SiteTree;	
  //use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
  //use SilverStripe\Forms\TextField;
  use SilverStripe\Forms\NumericField;
  //use Sheadawson\Linkable\Models\Link;
  //use Sheadawson\Linkable\Forms\LinkField;
  


    class HomePage extends Page
    {
        private static $db = [
          'NewsPostsNum' => 'Int',
          'ProjectsNum' => 'Int'
        ];

        private static $has_one = [        	
        	
        ];

        




        public function getCMSFields()
	    {
	        $fields = parent::getCMSFields(); 

          $fields->addFieldsToTab('Root.Features', 
            [
            NumericField::create('NewsPostsNum','Number of news posts to display'),
            NumericField::create('ProjectsNum','Number of featured projects to display'),
            ]);        

	        	 

	        return $fields;
	    }


	    

    }

    
}
