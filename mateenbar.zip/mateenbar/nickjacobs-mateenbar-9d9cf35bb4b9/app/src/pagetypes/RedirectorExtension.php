<?php

use SilverStripe\Control\Controller;
use SilverStripe\Forms\DropdownField;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\NumericField;
use SilverStripe\Forms\TextField;
use SilverStripe\ORM\ArrayList;
use SilverStripe\ORM\DataExtension;
use SilverStripe\SiteConfig\SiteConfig;

class RedirectorExtension extends DataExtension
{


	public function updateCMSFields(FieldList $fields)
    {

        $fields->removeByName(['PageTitle']);

        

        
        return $fields;
    }



	// public function updateCMSFields(FieldList $fields)
 //    {
 //        //$fields->removeByName(['Content','PageTitle','HideTitle','FooterBlock']);
 //        $this->beforeUpdateCMSFields(function (FieldList $fields) {
 //            $fields->removeByName(['Content','PageTitle','HideTitle','FooterBlock']);
 //        });

 //    }


}