<?php

namespace {

  use SilverStripe\CMS\Model\SiteTree;
  //use Symbiote\GridFieldExtensions\GridFieldOrderableRows;
  //use SilverStripe\Forms\GridField\GridField;
  //use SilverStripe\Forms\GridField\GridFieldConfig_RelationEditor;    
  //use SilverStripe\Forms\GridField\GridFieldConfig_RecordEditor;
  //use SilverStripe\Lumberjack\Model\Lumberjack;	
  //use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
  //use SilverStripe\Forms\TextField;
  //use Sheadawson\Linkable\Models\Link;
  //use Sheadawson\Linkable\Forms\LinkField;
  


    class ProductPage extends Page
    {
        private static $db = [
        	
        ];

        private static $has_one = [        	
        	
        ];

        private static $has_many = [
          
        ];

        private static $defaults = [         
          
        ];

        private static $extensions = [
            //Lumberjack::class,
        ];

        private static $allowed_children = [            
        ];

        




      public function getCMSFields()
      {
        $fields = parent::getCMSFields();




       



 
	      return $fields;
	    }


      


	    

    }

    
}
