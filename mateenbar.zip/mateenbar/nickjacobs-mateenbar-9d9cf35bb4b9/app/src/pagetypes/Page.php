<?php

namespace {

    use SilverStripe\AssetAdmin\Forms\UploadField;
    use SilverStripe\Assets\Image;
    use SilverStripe\CMS\Model\SiteTree;
    use SilverStripe\Forms\CheckboxField;
    use SilverStripe\Forms\DropdownField;
    use SilverStripe\Forms\GridField\GridField;
    use SilverStripe\Forms\GridField\GridFieldConfig_RecordEditor;
    use SilverStripe\Forms\GridField\GridFieldConfig_RelationEditor;
    use SilverStripe\Forms\HeaderField;
    use Sheadawson\Linkable\Models\Link;
    use Sheadawson\Linkable\Forms\LinkField;
    use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
    use SilverStripe\Forms\LiteralField;
    use SilverStripe\Forms\TextField;
    use Symbiote\GridFieldExtensions\GridFieldOrderableRows;

    //use SilverStripe\Security\Permission;
    //use DNADesign\Elemental\Models\ElementalArea;
    //use DNADesign\Elemental\Extensions\ElementalAreasExtension;

    class Page extends SiteTree
    {
        private static $db = [
            'PageTitle'                 => 'Varchar',
            //'UseBlocks' => 'Boolean',
            'HideTitle'                 => 'Boolean',
            //'ShowFooterBlock'           => 'Boolean',
            //'FooterBlockContent'        => 'HTMLText',
            //'FooterBlockImageAlignment' => "Enum('Right,Left','Right')",
            //'FooterBlockImageWidth'     => "Enum('Normal,Wide,Narrow,FullWidth','Normal')",
            //'FooterBlockImageCaption'   => 'Text',
            //'RemoveSidebar'             => 'Boolean',
            'ShowInHiddenMenu'          => 'Boolean'

        ];

        private static $has_one = [
            //'FooterBlockImage' => Image::class,
            //'FooterBlockLink' => Link::class,
        ];

        private static $has_many = [
            'Banners' => Banner::class,
        ];

        private static $many_many = array(
            //'SideBarLinks' => SidebarLink::class,
        );

        private static $many_many_extraFields = [
            // 'SideBarLinks' => [
            //     'SortOrder' => 'Int',
            // ],
        ];

        private static $owns = [
            //'FooterBlockImage',
        ];

        private static $description = '';

        public function getCMSFields()
        {
            $fields = parent::getCMSFields();

            if ($this->ClassName != 'SilverStripe\CMS\Model\RedirectorPage') {

                $title = TextField::create('PageTitle', 'Page top title')->setDescription('Overrides the page title - if blank we\'ll use the page name');
                $fields->insertAfter($title, 'MenuTitle');

                $hidetitle = CheckboxField::create('HideTitle', 'Hide title on this page');
                $fields->insertAfter($hidetitle, 'PageTitle');

                $content = HTMLEditorField::create('Content')->addExtraClass('stacked');
                $fields->insertAfter($content, 'HideTitle');

                $title->DisplayUnless('HideTitle')->isChecked();

                $blocks = [
                    HeaderField::create('hf1', 'Page blocks'),
                    LiteralField::create('lf1', '<p>Page blocks will appear directly after the main Content field - if you want the blocks first then leave the Content field blank and use blocks for any content.'),

                ];

                $fields->addFieldsToTab('Root.Main', $blocks, 'ElementalArea');

                $fields->addFieldsToTab('Root.Banners',
                    GridField::create('Banners', null, $this->Banners(),
                        $config = GridFieldConfig_RecordEditor::create()
                    )
                );
                if (class_exists("Symbiote\GridFieldExtensions\GridFieldOrderableRows")) {
                    $config->addComponent(new GridFieldOrderableRows());
                }

                // $fields->addFieldsToTab('Root.SidebarLinks',
                //     GridField::create('SideBarLinks', null, $this->SideBarLinks(),
                //         $config = GridFieldConfig_RelationEditor::create()
                //     )
                // );
                // if (class_exists("Symbiote\GridFieldExtensions\GridFieldOrderableRows")) {
                //     $config->addComponent(new GridFieldOrderableRows('SortOrder'));
                // }

                // $fields->addFieldsToTab('Root.FooterBlock',
                //     [
                //         CheckboxField::create('ShowFooterBlock', 'Show the footer block on this page?'),
                //         HTMLEditorField::create('FooterBlockContent')->setRows(10),
                //         UploadField::create('FooterBlockImage')->setFolderName('FooterBlocks'),
                //         TextField::create('FooterBlockImageCaption', 'Caption (optional)'),
                //         DropdownField::create('FooterBlockImageAlignment', 'Image alignment', $this->dbObject('FooterBlockImageAlignment')->enumValues()),
                //         DropdownField::create('FooterBlockImageWidth', 'Image width', $this->dbObject('FooterBlockImageWidth')->enumValues()),
                //         LinkField::create('FooterBlockLinkID','Page to link to')
                //     ]
                // );
            }

            return $fields;
        }


        function getSettingsFields() {
            $fields = parent::getSettingsFields();
            //$fields->addFieldToTab("Root.Settings", new CheckBoxField('RemoveSidebar', 'Remove the sidebar on this page?'));
            $fields->addFieldToTab("Root.Settings", new CheckBoxField('ShowInHiddenMenu', 'Show this page in the hidden main menu?'),"ShowInMenus");
            return $fields;
        }

        

        public function slug()
        {
            //return substr($this->URLSegment,0,6);
            return strtok($this->URLSegment, '-');
        }

        public function FooterBlockImageCol()
        {
            switch ($this->FooterBlockImageWidth) {
                case 'Wide':
                    $out = 'col-lg-8';
                    break;
                case 'Narrow':
                    $out = 'col-lg-4';
                    break;
                case 'FullWidth':
                    $out = 'col-lg-12';
                    break;
                default:
                    $out = 'col-lg-6';
            }
            return $out;
        }
        public function FooterBlockContentCol()
        {
            switch ($this->FooterBlockImageWidth) {
                case 'Wide':
                    $out = 'col-lg-4';
                    break;
                case 'Narrow':
                    $out = 'col-lg-8';
                    break;
                case 'FullWidth':
                    $out = 'col-lg-12';
                    break;
                default:
                    $out = 'col-lg-6';
            }
            return $out;
        }



        // geo location stuff
        public function getCountryName()
        {
            $reader = new GeoIPReader(); // can pass IP thorugh here as well
            $reader->getReader(); // Returns the country model
            //$reader->getIsoCode(); // US, NZ, etc
            return $reader->getCountry(); // United States
        }



    }

}
