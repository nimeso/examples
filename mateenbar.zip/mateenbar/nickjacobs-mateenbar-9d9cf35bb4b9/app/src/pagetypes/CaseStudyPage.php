<?php

namespace {

  use SilverStripe\CMS\Model\SiteTree;
  use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
  use SilverStripe\Forms\Textfield;
  use SilverStripe\Forms\CheckboxField;
  use SilverStripe\Forms\HeaderField;
  use SilverStripe\Forms\DropdownField;
  //use Sheadawson\Linkable\Models\Link;
  //use Sheadawson\Linkable\Forms\LinkField;
  use SilverStripe\AssetAdmin\Forms\UploadField;
  use SilverStripe\Assets\Image;
  use SilverStripe\Forms\ListboxField;
  // use SilverStripe\Forms\GridField\GridField;
  // use SilverStripe\Forms\GridField\GridFieldAddExistingAutocompleter;
  // use SilverStripe\Forms\GridField\GridFieldDeleteAction;
  // use Symbiote\GridFieldExtensions\GridFieldOrderableRows;
  // use SilverStripe\Forms\GridField\GridFieldConfig_RelationEditor;


    class CaseStudyPage extends Page
    {
        private static $db = [
          'HomepageFeatured' => 'Boolean',
          //'FeaturedTitle'=> 'Varchar',
          'Location'=> 'Varchar',
          'TwoColumn' => 'Boolean',
          'FeaturedTitle'=> 'Varchar',
        ];

        private static $has_one = [
          'FeaturedImage'  => Image::class,
          'Region'  => Region::class
        ];

        private static $many_many = [
        'ProjectTypes' => ProjectType::class,
        ];

        private static $defaults = [
          'ShowInMenus' => false
        ];

        private static $owns = [
          'FeaturedImage'
        ];

        private static $summary_fields = [
          'Title','HomepageFeatured'
        ];

        //private static $show_in_sitetree = false;
        private static $allowed_children = [];






      public function getCMSFields()
	    {
	        $fields = parent::getCMSFields();

          $regions=Region::get()->filter(['CaseStudyHolderID'=>$this->ParentID]);
          $projecttypes=ProjectType::get()->filter(['CaseStudyHolderID'=>$this->ParentID]);

          
          $fields->addFieldsToTab("Root.Main",
          [
              TextField::create('Location'),
              DropdownField::create('RegionID','Region', $regions->map('ID','Region'))->setEmptyString('(Select one)'),
              //DropdownField::create('ProjectTypeID','ProjectType', $projecttypes->map('ID','ProjectType'))->setEmptyString('(Select one)')
              ListboxField::create( 'ProjectTypes','ProjectTypes', $projecttypes->map('ID','ProjectType'))
          ],'HideTitle');





          $fields->addFieldsToTab("Root.Featured",
          [
            //CheckboxField::create('Featured','Feature case study'),
            CheckboxField::create('HomepageFeatured','Featured on the homepage'),
            //Textfield::create('FeaturedTitle'),
            $upload = UploadField::create('FeaturedImage')
                        ->setFolderName('CaseStudies/'.$this->URLSegment)

          ]
          );

           $fields->addFieldsToTab("Root.Main",
           [
            CheckboxField::create('TwoColumn','Content in two columns?')
           ],'Content'
           );






	        return $fields;
	    }

      public function GetCaseStudySummary() {
        $ContentElements = DNADesign\Elemental\Models\ElementContent::get()->filter('ParentID', $this->ElementalAreaID)->First();
        if (isset($ContentElements->HTML)) {
          return $ContentElements->HTML;
        }
        return $this->Content;
      }




    }


}
