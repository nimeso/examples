<?php

use SilverStripe\CMS\Controllers\ContentController;
use SilverStripe\CMS\Model\SiteTree;
use SilverStripe\Control\Controller;
use SilverStripe\Control\Director;
use SilverStripe\Control\HTTPRequest;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\Security\Permission;
use SilverStripe\View\Requirements;
use SilverStripe\Core\Config\Config;
use SilverStripe\Control\Cookie;

class PageController extends ContentController
{
   
    private static $allowed_actions = ['SearchForm'];

    private static $testIPs = [
      'US' => '198.7.59.119',
      'AU' => '120.145.29.239',
      'NZ' => '122.56.102.57',
      'GB' => '213.208.35.38',
      'CA' => '192.206.151.131',
      'EU' => '85.214.132.117',
      'AE' => '2.51.255.255',
      'EG' => '41.47.255.255'

    ];

    protected function init()
    {
        parent::init();
    }

    function SearchForm() {
        $form = parent::SearchForm();
        $form->setFormAction(Director::baseURL()."searchresults/SearchForm");
        return $form;
    }

    public function HiddenMenuPages() {
        $pages = Page::get()->filter(array("ShowInHiddenMenu" => 1));
        return $pages;
    }

    /**
     * Get Continent
     * Test if the cookie is set and if not, go to ipdata.co and get it and set it
     *
     * @return bool
     */
    public function getContinent()
    {        
        // if this is a manual switch
        $request = Controller::curr()->getRequest();
        if ($checkParam = $request->getVar('g')) {

            switch (strtoupper($checkParam)) {
            case 'AF':
                $cont_name = "Africa";
                break;
            case 'AS':
                $cont_name = "Asia";
                break;
            case 'OC':
                $cont_name = "Oceania";
                break;
            case 'ME':
                $cont_name = "Middle East";
                break;            
            case 'SA':
                $cont_name = "South America";
                break;
            case 'NA':
                $cont_name = "South America";
                break;
            default:
                $cont_name = "Global";
                break;
            }
            Cookie::set('MateenLocationContinent', $cont_name );

        }

        if(!$this->testIP() && ($continent = (Cookie::get('MateenLocationContinent'))))
        {
            return $continent;
        } else {

            if($this->testIP()){
                $location = $this->getGeoLocation($this->testIP());
            }else{  
                $location = $this->getGeoLocation($this->getUserIP());
            }
            if(!$location) {
                return false;
            }
            if(!($details = json_decode($location))) {
                return false;
            }      
                     
            if($cont_name = isset($details->continent_name) ? $details->continent_name : false) { 
                switch ($cont_name) {
                    case 'Asia':
                        $middleeast = array("SA", "AE", "KW", "BH", "QA", "OM", "JO", "SY", "IQ");
                        if (in_array($details->country_code, $middleeast)) {
                             $cont_name = 'Middle East';
                        }else {
                             $cont_name = 'Global';
                        } 
                        break;
                    case 'Africa':
                        $northafrica = array("MA", "TN", "DZ", "LY", "EG");
                        if (in_array($details->country_code, $northafrica)) {
                            $cont_name = 'Middle East';
                        }else {
                             $cont_name = 'Global';
                        }                        
                        break;
                    case 'Oceania':
                        $cont_name = "Oceania";
                        break;            
                    default:
                        $cont_name = "Global";
                        break;
                }
                Cookie::set('MateenLocationContinent', $cont_name );
                return $cont_name;

            }
        }
    }


    public function geoslug(){
        return SiteTree::create()->generateURLSegment($this->getContinent());
    }



    public function testIP(){
        $ips = self::$testIPs;
        if (Permission::check('ADMIN')) {
            // fake city with a url param ?geo=NZ
            $request = Controller::curr()->getRequest();
            if ($checkParam = $request->getVar('geo')) {
                $ipKey = strtoupper($checkParam);
                if (array_key_exists($ipKey, $ips)) {
                    return $ips[$ipKey];
                }
            }
        }
        return false;
    }

    

    /**
     * Find users IP address
     *
     * @return mixed
     */
    public function getUserIP()
    {
        
        return isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
        
    }

    /**
     * Do a remote lookup to ipdata to get user country
     *
     * @param $ipAddress
     * @return bool|mixed
     */
    public function getGeoLocation($ipAddress)
    {
        
        $url = "https://api.ipdata.co/" . $ipAddress . "?api-key=9f11b5741c7e95dab9d9aeb8d3b19edb6de974127fa7d12425938f90";
        $curl = curl_init();        

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            
        ));

        $response = curl_exec($curl);

        //var_dump($response);
        $err = curl_error($curl);

        curl_close($curl);

        // if ($err) {
        //   echo "cURL Error #:" . $err;
        // } else {
        //   echo $response;
        // }


        return $err ? false : $response;
    }
    

}
