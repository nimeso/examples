<?php

use SilverStripe\CMS\Controllers\ContentController;
use SilverStripe\CMS\Model\SiteTree;
use SilverStripe\Control\Controller;
use SilverStripe\Control\Director;
use SilverStripe\Control\HTTPRequest;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\Security\Permission;
use SilverStripe\View\Requirements;
use SilverStripe\Blog\Model\BlogPost;

class SearchController extends PageController
{
    /**
     * An array of actions that can be accessed via a request. Each array element should be an action name, and the
     * permissions or conditions required to allow the user to access it.
     *
     * <code>
     * [
     *     'action', // anyone can access this action
     *     'action' => true, // same as above
     *     'action' => 'ADMIN', // you must have ADMIN permissions to access this action
     *     'action' => '->checkAction' // you can only access this action if $this->checkAction() returns true
     * ];
     * </code>
     *
     * @var array
     */
    private static $allowed_actions = ['index','result'];

    protected function init()
    {
        parent::init();
    }

    public function index($request) {
        $query = $request->requestVar('query');
        $search = SiteSearch::create($query);

        /*foreach ($search->results() as $result) {
            echo "<a href='".$result->Link."'>".$result->Title." - ".$result->Sort."</a><br>";
        }*/

        // Set the summary
        $Summary = $search->results()[0]["Summary"];

        // if the page is a casestudy page use the element content block content as the summary
        if($search->results()[0]["Type"] == "CaseStudyPage"){
            $CaseStudyPage = CaseStudyPage::get()->filter('ID', $search->results()[0]["ID"])->First();
            $Summary = $CaseStudyPage->GetCaseStudySummary();

        }
        $data = array(
            'Content' => '',
            'Results' => $search->results(),
            'Summary' => $Summary,
            'Query' => $search->getQuery(),
            'Title' => 'Search Results'
        );

        return $this->customise($data)->renderWith(array('SearchResults', 'Page'));
    }

}
