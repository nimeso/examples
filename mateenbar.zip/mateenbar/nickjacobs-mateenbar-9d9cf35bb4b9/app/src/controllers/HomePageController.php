<?php

use SilverStripe\CMS\Controllers\ContentController;
use SilverStripe\CMS\Model\SiteTree;
use SilverStripe\Control\Controller;
use SilverStripe\Control\Director;
use SilverStripe\Control\HTTPRequest;
use SilverStripe\ORM\FieldType\DBField;
use SilverStripe\Security\Permission;
use SilverStripe\View\Requirements;
use SilverStripe\Blog\Model\BlogPost;

class HomePageController extends PageController
{
    /**
     * An array of actions that can be accessed via a request. Each array element should be an action name, and the
     * permissions or conditions required to allow the user to access it.
     *
     * <code>
     * [
     *     'action', // anyone can access this action
     *     'action' => true, // same as above
     *     'action' => 'ADMIN', // you must have ADMIN permissions to access this action
     *     'action' => '->checkAction' // you can only access this action if $this->checkAction() returns true
     * ];
     * </code>
     *
     * @var array
     */
    private static $allowed_actions = [];

    protected function init()
    {
        parent::init();

        

    }    
    

    public function HomeProjects()
    {
        $numposts=$this->ProjectsNum;
        return CaseStudyPage::get()->filter(['HomepageFeatured' => true])->sort('RAND()')->limit($numposts);        
        
    }

    public function HomeNews()
    {
        $numposts=$this->NewsPostsNum;        
        return BlogPost::get()->filter(['ParentID' => '10'])->sort('PublishDate DESC')->limit($numposts);        
        
    }
}
