<?php

class ContactPageController extends PageController
{

    private static $allowed_actions = array('index', 'ContactForm');

    public function init()
    {
        parent::init();

    }

    public function ContactForm()
    {
        return new ContactForm($this, 'ContactForm');
    }

}