<?php

use SilverStripe\Control\Email\Email;
use SilverStripe\Control\HTTPRequest;
use SilverStripe\Core\Config\Config;
use SilverStripe\Forms\EmailField;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\Form;
use SilverStripe\Forms\FormAction;
use SilverStripe\Forms\RequiredFields;
use SilverStripe\Forms\TextareaField;
use SilverStripe\Forms\TextField;
use SilverStripe\View\Requirements;
use SilverStripe\SiteConfig\SiteConfig;
use SilverStripe\Forms\FileField;
use SilverStripe\Assets\File;
use SilverStripe\Assets\Upload;

class ContactForm extends Form
{

    protected $template = 'Includes/ContactForm';

    public function __construct($controller, $name)
    {

        $fields = FieldList::create(

            TextField::create('Name', 'Name')
                ->setAttribute('placeholder', 'First Last'),

            EmailField::create('Email', 'Email')
                ->setAttribute('placeholder', 'name@example.co.nz'),

            TextField::create('Phone', 'Phone')
                ->setAttribute('placeholder', 'Phone number'),

            TextareaField::create('Message', 'Enquiry') ,
            
            FileField::create('Upload', 'Add attachment')
                ->setAllowedExtensions(['pdf', 'docx', 'doc'])
                ->setFolderName('ContactForm-Uploads')
                //->getValidator()->setAllowedMaxFileSize(1000000)

                

        );

        $actions = FieldList::create(
            FormAction::create('doSubmit')->setTitle('Submit')->addExtraClass('btn')
        );

        $validator = new RequiredFields('Name', 'Email', 'Phone','Message');

        parent::__construct($controller, $name, $fields, $actions, $validator);

        $session = $controller->getRequest()->getSession();

        if ($values = $session->get('FormInfo.ContactForm_ContactForm.data')) {
            $this->loadDataFrom($values);
            $session->clear('FormInfo.ContactForm_ContactForm.data');
        }

        $this->addExtraClass('contact-form__form');

        Requirements::javascript('https://www.google.com/recaptcha/api.js');

        Requirements::customScript("
            function happyCaptcha(t) {
              $('#ContactForm_ContactForm_action_doSubmit').prop('disabled', false);
            }

            function unhappyCaptcha(t) {
              $('#ContactForm_ContactForm_action_doSubmit').prop('disabled', true);
            }

            unhappyCaptcha();");
    }

    public function RecaptchaKey()
    {
        return Config::inst()->get('GoogleRecaptcha', 'recaptcha_key');
    }

    public function Page()
    {
        return $this->controller;
    }

    public function doSubmit(array $data, Form $form, HTTPRequest $request)
    {
        unset($data['SecurityID']);

        $config = SiteConfig::current_site_config(); 

        $secret     = Config::inst()->get('GoogleRecaptcha', 'recaptcha_secret');
        $googleLink = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=" . $data['g-recaptcha-response'];

        $verify = json_decode(file_get_contents($googleLink));

        $session = $this->controller->getRequest()->getSession();

        if ($verify->success) {
            unset($data['g-recaptcha-response']);
            unset($data['action_doSubmit']);

            $spam = json_decode(file_get_contents('http://www.stopforumspam.com/api?f=json&email=' . $data['Email']), true);

            if ($spam['email']['frequency'] > 3) {
                //what were we meant to do here???
                return $this->controller->redirect($this->controller->Link() . 'success');
            }
            $hasFile = false;

            if(file_exists($_FILES['Upload']['tmp_name'])) {

                $up = new Upload();
                $file = File::create(); 
                $up->loadIntoFile($data['Upload'], $file, 'ContactFormUploads');

                if($up->isError()) {
                    //handle error here
                    var_dump($up->getErrors());
                }else {
                    //file uploaded
                    $hasFile = true;           
                } 
            }


            $body = '';
            $body .= '<p><strong>Name:</strong> ' . $data['Name'] . '</p>';
            $body .= '<p><strong>Email:</strong> ' . $data['Email'] . '</p>';
            $body .= '<p><strong>Phone:</strong> ' . $data['Phone'] . '</p>';
            $body .= '<p><strong>Message:</strong></p>';
            $body .= $data['Message'];
            if($hasFile){

                $body .= '<p>--------------------</p><p>This message has an attached file.</p><p>--------------------</p>';
            }


            // foreach ($data as $key => $value) {
            //     if (is_array($value)) {
            //         $body .= '<p><strong>' . $this->splitCase($key) . ':</strong></p>';
            //         foreach ($value as $key2 => $value2) {
            //             $body .= "<p> - $value2</p>";
            //         }
            //     } else {
            //         $body .= '<p><strong>' . $this->splitCase($key) . ':</strong> ' . nl2br($value) . '</p>';
            //     }
            // }

            switch ($this->Page()->geoslug()) {
                case 'oceania':
                    $to = $config->OCContactEmail;
                    break;
                case "middle-east":
                    $to = $config->MEContactEmail;
                    break;
                default:
                    //$to = $this->Page()->NotifyEmail;
                    $to = $config->ContactEmail;
                    break;
            }




            
            


            $from    = 'noreply@mateenbar.com';
            $subject = 'New contact email from Mateenbar.com website';
            $email   = new Email($from, $to, $subject, $body);
            if($hasFile){
                $filepath = 'assets/' . $file->Filename;
                $email->addAttachment($filepath);
            }

            if (!empty($to)) {
                $email->send();
            }

            if($hasFile && $file){                
                $file->delete();
            }

            //$session->set('page_alert', ['Message' => 'Your message has been submitted, thank you.', 'Type' => 'success']);
            //return $this->controller->redirect($this->controller->Link());
            return [
                'SuccessMessage' => 'Your message has been submitted, thank you.',
                'ContactForm' => ''
            ];
        } else {
            $session->set('FormInfo.ContactForm_ContactForm.data', $data);
            $session->set('page_alert', ['Message' => 'There was an issue sending your message. Please try again later or contact us directly.', 'Type' => 'error']);
            return $this->controller->redirectBack();
        }

    }

    public function splitCase($str)
    {
        return preg_replace('/([a-z0-9])([A-Z])/', '$1 $2', $str);
    }

}
