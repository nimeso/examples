<?php

namespace {
    use SilverStripe\CMS\Model\SiteTree;
    use SilverStripe\Forms\FieldList;
    use SilverStripe\Forms\TextField;
    use SilverStripe\ORM\DataObject;
    use SilverStripe\Security\Member;
    use SilverStripe\Security\Permission;
    use SilverStripe\AssetAdmin\Forms\UploadField;
    use SilverStripe\Assets\File;
    use SilverStripe\Assets\Image;
    use SilverStripe\Forms\LiteralField;
    use Elements\LinkBoxElement; 
    use Sheadawson\Linkable\Models\Link;
    use Sheadawson\Linkable\Forms\LinkField;

    class LinkBox extends DataObject
    {
        /**
         * @var array
         */
        private static $db = [        
            'Title' => 'Varchar',
            'SubTitle' => 'Varchar',               
            'Content' => 'HTMLText', 
            'Sort' => 'Int'
        ];       

        /**
         * @var array
         */
        private static $has_one = [
            'LinkBoxElement' => LinkBoxElement::class,
            'LinkBoxLink' => Link::class,
            'Image' => Image::class,
            'BackgroundVideo' => File::class     

        ];


        private static $has_many = [
              
        ];

        /**
         * @var array
         */
        private static $owns = array(
            'Image','BackgroundVideo'
        );

        /**
         * @var array Show the panel $Title by default
         */
        private static $defaults = [
            
        ];

        private static $summary_fields = array(        
            'Title' => 'Title',
        );

        /**
         * @var string
         */
        private static $default_sort = 'Sort';

        /**
         * @var string Database table name, default's to the fully qualified name
         */
        private static $table_name = 'Elements_LinkBox';

        /**
         * @return FieldList
         *
         * @throws \Exception
         */
        
        public function getCMSFields()
        {
         
            $fields = parent::getCMSFields();
            $this->beforeUpdateCMSFields(function (FieldList $fields) {
                $fields->removeByName(['Sort','LinkBoxElementID','LinkBoxLinkID','Image']); 

                $link = LinkField::create('LinkBoxLinkID','Page to link to');
                $fields->insertAfter($link,'Content');

                $uploader = UploadField::create('Image','Linkbox image');
                $uploader->setFolderName('LinkImages');
                $uploader->getValidator()->setAllowedExtensions(['png','gif','jpeg','jpg']);
                $fields->insertAfter($uploader,'Content');
                //$fields->addFieldToTab('Root.Main', $uploader);
                $uploader2 = UploadField::create('BackgroundVideo');
                $uploader2->setFolderName('BannerVideos');
                $uploader2->getValidator()->setAllowedExtensions(['mp4']);
                $fields->insertAfter($uploader2,'Image');

            });

           

            return parent::getCMSFields();
        }




       
        public function getPage()
        {
            $page = null;

            if ($this->LinkBoxElementID) {
                if ($this->LinkBoxElement()->hasMethod('getPage')) {
                    $page = $this->LinkBoxElement()->getPage();
                }
            }

            return $page;
        }

        


        public function canView($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canEdit($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canDelete($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canCreate($member = null, $context = [])
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }




    }
}