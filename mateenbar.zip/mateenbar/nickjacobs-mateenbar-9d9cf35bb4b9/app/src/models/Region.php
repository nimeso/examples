<?php

namespace {

    use SilverStripe\CMS\Model\SiteTree;
    //use SilverStripe\Assets\File;
    //use SilverStripe\Assets\Image;
    //use SilverStripe\Forms\FieldList;
    //use SilverStripe\Forms\TextField;
    use SilverStripe\ORM\DataObject;
    use SilverStripe\Security\Member;
    use SilverStripe\Security\Permission;
    //use SilverStripe\AssetAdmin\Forms\UploadField;
    
    //use Sheadawson\Linkable\Models\Link;
    //use Sheadawson\Linkable\Forms\LinkField;


    class Region extends DataObject
    {
        /**
         * @var array
         */
        private static $db = [
            'Sort' => 'Int',
            'Region' => 'Varchar',            
             
        ];

        /**
         * @var array
         */
        private static $has_one = [            
            //'Image' => Image::class ,
            'CaseStudyHolder' => CaseStudyHolder::class     
        ];

        /**
         * @var array
         */
        private static $owns = array(
            //'Image'
        );

        /**
         * @var array Show the panel $Title by default
         */
        private static $defaults = [
            //'ShowTitle' => true
        ];

        private static $summary_fields = array(        
            'Region' => 'Region' 
        );

        /**
         * @var string
         */
        private static $default_sort = 'Sort';

        /**
         * @var string Database table name, default's to the fully qualified name
         */
        private static $table_name = 'Region';

        /**
         * @return FieldList
         *
         * @throws \Exception
         */
        public function getCMSFields()
        {
         
            $fields = parent::getCMSFields();
            $this->beforeUpdateCMSFields(function ($fields) {
                $fields->removeByName(['Sort','CaseStudyHolderID']);

                // $fields->addFieldsToTab("Root.Main", [                    
                //     $image = UploadField::create('Image')
                //             ->setFolderName('Markets')
                //             ->setDescription('Upload an image.')
                //             ->setAllowedExtensions([
                //                 'jpg',
                //                 'jpeg',
                //                 'png',
                //                 'gif'
                //             ])
                // ]);


            });

            return parent::getCMSFields();
            
        }

        public function slug()
        {            
            return SiteTree::create()->generateURLSegment($this->Region);
        }
    


        public function canView($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canEdit($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canDelete($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canCreate($member = null, $context = [])
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }




    }
}