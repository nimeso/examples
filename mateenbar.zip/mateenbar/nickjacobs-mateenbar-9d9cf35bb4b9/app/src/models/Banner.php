<?php

use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Assets\File;
use SilverStripe\Assets\Image;
use SilverStripe\ORM\DataObject;
use SilverStripe\Security\Permission;
use SilverStripe\View\Requirements;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\TextareaField;
use SilverStripe\Forms\CheckboxField;
//use Sheadawson\Linkable\Models\Link;
//use Sheadawson\Linkable\Forms\LinkField;


class Banner extends DataObject
{
    private static $table_name = 'Banner';

    private static $summary_fields = [
    	'BannerTitle'
    ];

    private static $default_sort = 'Sort';

    private static $db = [
    	'BannerTitle' => 'Varchar(250)',
    	'Caption' => 'Text',
        'Sort' => 'Int',
        'TallBanner' => 'Boolean',
        'TitleStrip' => 'Boolean',
        
    ];

    private static $has_one = [
        'BannerImage' => Image::class,
        'Page' => 'Page',
        'BackgroundVideo' => File::class,
        //'BannerLink' => Link::class      
    ];

    private static $owns = [
        'BannerImage','BackgroundVideo'
    ];

    private static $has_many = [
        
    ];

	private static $many_many = [
       
    ];

    
    

    public function canView($member = null)
    {
        return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
    }

    public function canEdit($member = null)
    {
        return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
    }

    public function canDelete($member = null)
    {
        return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
    }

    public function canCreate($member = null, $context = [])
    {
        return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
    }




    public function getCMSFields()
    {
        $fields = parent::getCMSFields();

        $fields->removeByName(['PageID','LinkTracking','FileTracking','Sort','Buttons','Caption']);

        $fields->addFieldsToTab('Root.Main', [
            TextareaField::create('Caption','Banner caption'),
            CheckboxField::create('TallBanner','Tall banner style'),
            CheckboxField::create('TitleStrip','Title strip style')->setDescription('Use a black baground behind the title')

        ]);


        $uploader = UploadField::create('BannerImage');
        	$uploader->setFolderName('BannerImages');
        	$uploader->getValidator()->setAllowedExtensions(['png','gif','jpeg','jpg']);

        $fields->addFieldToTab('Root.Main', $uploader);

        $uploader2 = UploadField::create('BackgroundVideo');
            $uploader2->setFolderName('BannerVideos');
            $uploader2->getValidator()->setAllowedExtensions(['mp4']);


        $fields->addFieldToTab('Root.Main', $uploader2);

        //$fields->addFieldToTab('Root.Main',LinkField::create('BannerLinkID', 'Link to a page or file'));



        
        //Requirements::javascript('js/CMS.PlanBuilder.js');

        // $fields->addFieldToTab('Root.Main', UploadField::create('PlanImage')
        //         ->setDescription('jpg, gif and png filetypes allowed.')
        //         ->setFolderName('Uploads/BuilderImages/')
        //         ->setAllowedExtensions([
        //             'jpg',
        //             'jpeg',
        //             'png',
        //             'gif',
        //         ]), 'PricingPrefab');


        


        return $fields;
    }

    
}
