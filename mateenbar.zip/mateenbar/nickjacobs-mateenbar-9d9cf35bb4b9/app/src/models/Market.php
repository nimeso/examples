<?php

namespace {

    use SilverStripe\CMS\Model\SiteTree;
    use SilverStripe\Assets\File;
    use SilverStripe\Assets\Image;
    use SilverStripe\Forms\FieldList;
    use SilverStripe\Forms\TextField;
    use SilverStripe\ORM\DataObject;
    use SilverStripe\Security\Member;
    use SilverStripe\Security\Permission;
    use SilverStripe\AssetAdmin\Forms\UploadField;
    
    //use Sheadawson\Linkable\Models\Link;
    //use Sheadawson\Linkable\Forms\LinkField;


    class Market extends DataObject
    {
        /**
         * @var array
         */
        private static $db = [
            'Sort' => 'Int',
            'Title' => 'Varchar',            
             
        ];

        /**
         * @var array
         */
        private static $has_one = [            
            'Image' => Image::class ,
            'MarketHolder' => MarketHolder::class     
        ];

        /**
         * @var array
         */
        private static $owns = array(
            'Image'
        );

        /**
         * @var array Show the panel $Title by default
         */
        private static $defaults = [
            //'ShowTitle' => true
        ];

        private static $summary_fields = array(        
            'Thumbnail' => 'Image' ,'Title' => 'Title' 
        );

        /**
         * @var string
         */
        private static $default_sort = 'Sort';

        /**
         * @var string Database table name, default's to the fully qualified name
         */
        private static $table_name = 'Market';

        /**
         * @return FieldList
         *
         * @throws \Exception
         */
        public function getCMSFields()
        {
         
            $fields = parent::getCMSFields();
            $this->beforeUpdateCMSFields(function (FieldList $fields) {
                $fields->removeByName(['Sort','Image','MarketHolderID']);

                $fields->addFieldsToTab("Root.Main", [                    
                    $image = UploadField::create('Image')
                            ->setFolderName('Markets')
                            ->setDescription('Upload an image.')
                            ->setAllowedExtensions([
                                'jpg',
                                'jpeg',
                                'png',
                                'gif'
                            ])
                ]);


            });

            return parent::getCMSFields();
            
        }

        

        public function Thumbnail()
        {
            $image = $this->Image();
            return ($image) ? $image->CMSThumbnail() : false;
        }
       

        public function slug()
        {            
            return SiteTree::create()->generateURLSegment($this->Title);
        }        


        public function canView($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canEdit($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canDelete($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canCreate($member = null, $context = [])
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }




    }
}