<?php

namespace {

    use SilverStripe\Assets\File;
    use SilverStripe\Assets\Image;
    //use SilverStripe\Forms\CheckboxField;
    //use SilverStripe\Forms\OptionsetField;
    use SilverStripe\Forms\FieldList;
    //use SilverStripe\Forms\LiteralField;
    use SilverStripe\Forms\TextField;
    use SilverStripe\Forms\TextareaField;
    //use SilverStripe\Forms\NumericField;
    use SilverStripe\Forms\DropdownField;
    use SilverStripe\ORM\DataObject;
    use SilverStripe\Security\Member;
    use SilverStripe\Security\Permission;
    use Elements\GalleryBlock;
    use SilverStripe\AssetAdmin\Forms\UploadField;
    use DNADesign\Elemental\Forms\TextCheckboxGroupField;
    use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
    use Sheadawson\Linkable\Models\Link;
    use Sheadawson\Linkable\Forms\LinkField;


    class GalleryItem extends DataObject
    {
        /**
         * @var array
         */
        private static $db = [
            'Sort' => 'Int',
            'Title' => 'Varchar',
            'Caption' => 'Text',
            'Width' => 'Enum("One third,Half,Two thirds, Full")'
        ];

        /**
         * @var array
         */
        private static $has_one = [
            'GalleryBlock' => GalleryBlock::class,
            'Image' => Image::class,
            'ItemLink' => Link::class, 
        ];

        /**
         * @var array
         */
        private static $owns = array(
            'Image'
        );

        /**
         * @var array Show the panel $Title by default
         */
        private static $defaults = [
            //'ShowTitle' => true
        ];

        private static $summary_fields = array(        
            'Thumbnail' => 'Image',
            'Title' => 'Title',
            'Width' => 'Width' 
        );

        /**
         * @var string
         */
        private static $default_sort = 'Sort';

        /**
         * @var string Database table name, default's to the fully qualified name
         */
        private static $table_name = 'Elements_GalleryItem';

        /**
         * @return FieldList
         *
         * @throws \Exception
         */
        public function getCMSFields()
        {
         
            $fields = parent::getCMSFields();
            $this->beforeUpdateCMSFields(function (FieldList $fields) {
                $fields->removeByName(array(
                         'Sort','Caption','Width','GalleryBlockID','Image'
                ));

                // Add a combined field for "Title" and "Displayed" checkbox in a Bootstrap input group
                
                /*
                $fields->replaceField(
                    'Title',
                    TextCheckboxGroupField::create()
                        ->setName('Title')
                );
                */

               // $fields->addFieldToTab("Root.Main", $titlebelow = CheckboxField::create('TitleBelow','Show the title below the Image?'));


                $fields->addFieldsToTab("Root.Main", array(
                    
                    $image = UploadField::create('Image')
                            ->setFolderName('CaseStudies/'.$this->getPage()->URLSegment .'/GalleryItems')
                            ->setDescription('Upload an image.')
                            ->setAllowedExtensions([
                        'jpg',
                        'jpeg',
                        'png',
                        'gif'
                    ]),

                    TextareaField::create('Caption'),

                    LinkField::create('ItemLinkID', 'Link to a page or file'),
                                 
                    DropdownField::create('Width','Image width',$this->dbObject('Width')->enumValues())               
                                 

                )); 

                     
               
            });

            return parent::getCMSFields();
        }

        /**
         * @return null
         */
        public function getPage()
        {
            $page = null;

            if ($this->GalleryBlockID) {
                if ($this->GalleryBlock()->hasMethod('getPage')) {
                    $page = $this->GalleryBlock()->getPage();
                }
            }

            return $page;
        }


        public function Thumbnail()
        {
            $image = $this->Image();
            return ($image) ? $image->CMSThumbnail() : false;
        }

        public function RightColWidth(){        
            if($this->Width=='One third')return 'col-md-4';
            if($this->Width=='Half')return 'col-md-6';
            if($this->Width=='Two thirds')return 'col-md-8';
            return 'col-12';
        }

        public function LeftColWidth() 
        {
            if($this->Width=='One third')return 'col-md-8';
            if($this->Width=='Half')return 'col-md-6';
            if($this->Width=='Two thirds')return 'col-md-4';
            return 'col-12';
        }
        


        public function canView($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canEdit($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canDelete($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canCreate($member = null, $context = [])
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }




    }
}