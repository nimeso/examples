<?php

namespace {


    use SilverStripe\AssetAdmin\Forms\UploadField;
    use SilverStripe\Assets\File;
    use SilverStripe\Forms\TextField;
    use SilverStripe\ORM\DataObject;
    use Elements\DocumentListElement;
    use SilverStripe\Forms\DateField;
    use SilverStripe\Forms\FieldList;
    use SilverStripe\ORM\ValidationResult;

    class DocumentItem extends DataObject
    {
        private static $table_name = 'DocumentItem';

        private static $db = [
            'Title'     => 'Text',
            'Sort' => 'Int',
            'ShowInSearch' => 'Boolean',
            //'DatePublished' => 'Date',
        ];

        private static $has_one = [
            'Document'           => File::class,
            //'DocumentListElement' => DocumentListElement::class,
        ];

        private static $owns = [
            'Document',
        ];

        private static $defaults = [
            'ShowInSearch' => true,
        ];

        private static $summary_fields = [

        ];

        private static $default_sort = 'Sort';

        public function getCMSFields()
        {

            return FieldList::create(
                TextField::create('Title'),

               // DateField::create('DatePublished', 'Date of publication/upload (optional)'),

                UploadField::create('Document', 'Document file')
                    ->setAllowedExtensions(['pdf','doc','docx','xls'])
                    ->setFolderName('Documents')
            );
        }

        public function NiceDatePublished()
        {
            $time = strtotime($this->owner->DatePublished);
            return date('j F Y', $time);
        }


        //if the title is empty - set a default based on the file name
        protected function onBeforeWrite()
        {

            if (!$this->Sort) {
                $this->Sort = DocumentItem::get()->max('Sort') + 1;
            }
            if (empty($this->Title)) {
                $this->Title = $this->Document()->Title;
               // if ($this->DocumentID) {
               //      $this->Title = $this->Document()->Title;
               //  } else {
               //       $this->Title = 'Document-' . $this->ID;
               //  }
            }
            if($this->Document() && $this->Document()->exists()) {
                $this->Document()->publishSingle();
            }
            parent::onBeforeWrite();
        }


    }
}

