<?php

namespace {

    use SilverStripe\Assets\File;
    use SilverStripe\Assets\Image;
    use SilverStripe\Forms\CheckboxField;
    use SilverStripe\Forms\OptionsetField;
    use SilverStripe\Forms\FieldList;
    use SilverStripe\Forms\LiteralField;
    use SilverStripe\Forms\TextField;
    use SilverStripe\Forms\NumericField;
    use SilverStripe\Forms\DropdownField;
    use SilverStripe\ORM\DataObject;
    use SilverStripe\Security\Member;
    use SilverStripe\Security\Permission;
    use Elements\GridBoxElement;
    use SilverStripe\AssetAdmin\Forms\UploadField;
    use DNADesign\Elemental\Forms\TextCheckboxGroupField;
    use SilverStripe\Forms\HTMLEditor\HTMLEditorField;
    use Sheadawson\Linkable\Models\Link;
    use Sheadawson\Linkable\Forms\LinkField;


    class GridBoxItem extends DataObject
    {
        /**
         * @var array
         */
        private static $db = [
            'Sort' => 'Int',
            'Title' => 'Text',
            'ShowTitle' => 'Boolean',
            'Content' => 'HTMLText', 
            'Alignment' => 'Varchar',
            'PadWidth' => 'Int',
            'ExtraClasses' => 'Varchar',
            //'AllowPopup' => 'Boolean',
            'Featured' => 'Boolean',
            'Label' => 'Varchar',
            'IconStyle' => 'Boolean',
            //'TileColour' => 'Enum("White,Grey,Black,Pink")'      
        ];

        /**
         * @var array
         */
        private static $has_one = [
            'GridBox' => GridBoxElement::class,
            'Image' => Image::class,
            'ItemLink' => Link::class,
        ];

        /**
         * @var array
         */
        private static $owns = array(
            'Image'
        );

        /**
         * @var array Show the panel $Title by default
         */
        private static $defaults = [
            //'ShowTitle' => true
        ];

        private static $summary_fields = array(        
            'Title' => 'Title','isFeatured' => 'Featured'
        );

        /**
         * @var string
         */
        private static $default_sort = 'Sort';

        /**
         * @var string Database table name, default's to the fully qualified name
         */
        private static $table_name = 'Elements_GridBoxItem';

        /**
         * @return FieldList
         *
         * @throws \Exception
         */
        public function getCMSFields()
        {
         
            $fields = parent::getCMSFields();
            $this->beforeUpdateCMSFields(function (FieldList $fields) {
                $fields->removeByName(array(
                         'Sort','GridBoxID','ShowTitle','Content','Image','Alignment','ItemLinkID','PadWidth','ExtraClasses','TileColour','Label','Featured','IconStyle'
                     ));

                // Add a combined field for "Title" and "Displayed" checkbox in a Bootstrap input group
                $fields->replaceField(
                    'Title',
                    TextCheckboxGroupField::create()
                        ->setName('Title')
                );

               // $fields->addFieldToTab("Root.Main", $titlebelow = CheckboxField::create('TitleBelow','Show the title below the Image?'));


                $fields->addFieldsToTab("Root.Main", array(

                    CheckboxField::create('Featured','Featured tile (full width)'),
                    
                    $image = UploadField::create('Image')
                            ->setFolderName('ElementImages/GridBoxItems')
                            ->setDescription('Upload an image.'),
                    CheckboxField::create('IconStyle','Use icon style (don\'t resize image)'),
                    //$iconhead = LiteralField::create('lf1','<i style="margin-left:17%;margin-bottom:10px;font-size:3rem" class="'.$this->Icon.'"></i>'),

                    //CheckboxField::create('AllowPopup','Allow to popup a larger version of the image?'),
                    
                    HTMLEditorField::create('Content')->setRows(8),                
                    DropdownField::create(
                        'Alignment',
                        'Text alignment',
                            array(                    
                                'text-center' => 'Center',
                                'text-left' => 'Left',
                                'text-right' => 'Right',
                            )
                    ),

                    //DropdownField::create('TileColour', 'Tile colour', $this->dbObject('TileColour')->enumValues()),
                    Textfield::create('Label'),
                    
                    $link = LinkField::create('ItemLinkID', 'Link to a page or file') ,

                               

                )); 

                $fields->addFieldsToTab("Root.Styles", array(
                    NumericField::create('PadWidth','Pad the horizontal width of the image:')->setDescription('Enter a pixel value (ie 20) - this will help to size images that are a different shape'),
                    Textfield::create('ExtraClasses','Extra style classes to apply')
                )); 

                //$titlebelow->displayIf('ShowTitle')->isChecked()->end();        
               
            });

            return parent::getCMSFields();
        }

        /**
         * @return null
         */
        public function getPage()
        {
            $page = null;

            if ($this->GridBoxID) {
                if ($this->GridBox()->hasMethod('getPage')) {
                    $page = $this->GridBox()->getPage();
                }
            }

            return $page;
        }

        public function isFeatured()
        {
            if($this->Featured) return "Yes";
        }


        public function canView($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canEdit($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canDelete($member = null)
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }

        public function canCreate($member = null, $context = [])
        {
            return Permission::check('CMS_ACCESS_CMSMain', 'any', $member);
        }




    }
}