<?php

use SilverStripe\Control\Controller;
use SilverStripe\Forms\DropdownField;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\NumericField;
use SilverStripe\Forms\TextField;
use SilverStripe\ORM\ArrayList;
use SilverStripe\ORM\DataExtension;
use SilverStripe\SiteConfig\SiteConfig;

class BlogPostExtension extends DataExtension
{



	public function updateCMSFields(FieldList $fields)
    {
        $fields->removeByName(['Tags','FeaturedInWidget','Authors','AuthorNames']);

    }

    public function NiceDatePublished()
    {
        $time = strtotime($this->owner->PublishDate);
        return date('j F Y', $time);
    }




}