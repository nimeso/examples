<?php

use SilverStripe\CMS\Model\SiteTree;
use SilverStripe\Core\Convert;
use SilverStripe\ORM\ArrayList;
use SilverStripe\ORM\DataList;
use SilverStripe\ORM\DataObject;

class SiteSearch extends DataObject
{

    protected $fields = "Title,MenuTitle,MetaDescription";
    protected $query;
    protected $pagetype = "Page";

    public function __construct($query = Null)
    {
        $this->query = Convert::raw2xml(trim($query));
    }

    public function getQuery()
    {
        return $this->query;
    }

    public function GetScope() {
        return [
            'pages' => [
                'Page' => [
                    'fields'  => 'Title,PageTitle,Content,FooterBlockContent,FooterBlockImageCaption',
                    'Title'   => 'Title',
                    'Summary' => 'Content'
                ],
                'ContactPage' => [
                    'fields'  => 'Title,PageTitle,Content,FooterBlockContent,FooterBlockImageCaption,PultronNZDetails,PultronCANDetails,PultronUAEDetails',
                    'Title'   => 'Title',
                    'Summary' => 'Content'
                ],
                'CaseStudyPage' => [
                    'fields'  => 'Title,PageTitle,Content,FooterBlockContent,FooterBlockImageCaption',
                    'Title'   => 'Title',
                    'Summary' => 'CaseStudySummary'
                ]
            ],
            'objects'  => [
                'Banner' => [
                    'fields'    => 'BannerTitle',
                    'page_type' => 'Page',
                    'page_id'   => 'PageID'
                ]
            ],
            'elements' => [
                'DNADesign\Elemental\Models\ElementContent' => [
                    'fields'     => 'HTML',
                    'page_types' => 'Page',
                ],
                'Elements\PeopleBlock' => [
                    'fields'     => 'Title, Content, Qualifications, Position',
                    'page_types' => 'Page',
                ],
                'Elements\FeatureBlock' => [
                    'fields'     => 'Title, Content, ImageCaption',
                    'page_types' => 'Page',
                ],
                'Elements\GridBoxElement' => [
                    'fields'     => 'Title, Content',
                    'page_types' => 'Page',
                ],
                'Elements\AccordionBlock' => [
                    'fields'     => 'Title, Heading, Content',
                    'page_types' => 'Page',
                ],
            ],
        ];
    }

    public function results()
    {
        $SearchResults = [];
        $keyword = $this->query;
        $keywords = explode(" ", $keyword);

        //pages first
        $pagetypes = $this->GetScope()['pages'];
        foreach ($pagetypes as $pagetype => $options) {
            $fields  = (isset($options['fields'])) ? explode(',',$this->fields.",".$options['fields']) : explode(',',$this->fields);

            $results = $this->searchPageType($pagetype,$fields,$keywords);

            foreach ($results as $r) {
                $SearchResults[$r->ID] = $this->getPageResult($pagetype,$r);
            }
        }

        //now objects
        $objects = $this->GetScope()['objects'];
        foreach ($objects as $object => $options) {
            $fields  = explode(',',$options['fields']);
            $results = $this->searchObject($object,$fields,$keywords);


            foreach ($results as $r) {
                $fieldname = $options['page_id'];

                if (strpos($fieldname, '.') > 0) {
                    $fieldname = explode('.', $fieldname);
                    $parent = $fieldname[0];
                    $fieldname = $fieldname[1];
                    $page_id = $r->$parent()->$fieldname;
                } else {
                    $page_id = $r->$fieldname;
                }

                if (isset($SearchResults[$page_id])) {
                    //page already in results
                    continue;
                }

                //else add the page into the search results array
                $pageres = $this->getPageResult($options['page_type'],$page_id);
                if (!empty($pageres)) {
                    $SearchResults[$page_id] = $pageres;
                }
            }
        }

        //now elements
        $elements = $this->GetScope()['elements'];
        foreach ($elements as $element => $options) {
            $fields     = explode(',',$options['fields']);
            $matches    = $this->searchObject($element,$fields,$keywords);
            $page_types = explode(',', $options['page_types']);


            foreach ($matches as $r) {
                $area = $r->ParentID;

                // var_dump($area);die();

                //check all page types
                foreach ($page_types as $pagetype) {
                    $pages = DataList::create($pagetype)->where('ElementalAreaID = '.$area);

                    // var_dump($pages->first());die();
                    foreach ($pages as $page) {
                        if (isset($SearchResults[$page->ID])) {
                            //page already in results
                            continue;
                        }

                        $pageres = $this->getPageResult($pagetype,$page);
                        if (!empty($pageres)) {
                            $SearchResults[$page->ID] = $pageres;
                        }
                    }
                }
            }
        }

        // var_dump(ArrayList::create($SearchResults)->sort(["Sort"=>"ASC",'Title'=>'ASC']));die();
        return ArrayList::create($SearchResults)->sort(["Sort"=>"ASC",'Title'=>'ASC']);
    }

    protected function searchObject($object,$fields,$keywords) {
        $where = $this->buildSearchString($fields,$keywords);
        $results = DataList::create($object)->where($where);

        return $results;
    }

    protected function searchPageType($pagetype,$fields,$keywords) {
        $where = $this->buildSearchString($fields,$keywords);

        $results = DataList::create($pagetype)
                ->where($where)
                ->filter("ShowInSearch", 1);

        $results->sort(array(
            'Relevance' => 'DESC',
            'Title' => 'ASC'
        ));

        return $results;
    }

    protected function getPageResult($page_type,$page_data) {
        if (is_numeric($page_data)) {
            $page_data = SiteTree::get_by_id($page_type,$page_data);
        }

        $options = $this->GetScope()['pages'][$page_type];
        $title   = (isset($options['Title'])) ? $options['Title'] : "Title";
        $summary = (isset($options['Summary'])) ? $options['Summary'] : "Content";
        // var_dump($page_data->$summary);die();

        return ($page_data->ShowInSearch == 1) ? [
                    'ID'      => $page_data->ID,
                    'Sort'    => $page_data->Sort,
                    'Link'    => $page_data->Link(),
                    'Title'   => $page_data->$title,
                    'Summary' => $page_data->$summary,
                    'Type'    => $page_type,
                ] : false;
    }

    protected function buildSearchString($fields,$keywords) {
        $where = [];
        foreach ($keywords as $keyword) {
            $subwhere = [];
            foreach ($fields as $f) {
                $subwhere[] = "$f LIKE '%$keyword%'";
            }
            $where[] = "(".implode(" OR ", $subwhere).")";
        }
        $where = implode(" AND ", $where);

        return $where;
    }

}
