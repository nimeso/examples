<?php
use SilverStripe\Forms\FieldList;
use SilverStripe\ORM\DataExtension;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\TextareaField;
use SilverStripe\Forms\HeaderField;
use SilverStripe\AssetAdmin\Forms\UploadField;
use SilverStripe\Assets\Image;

use SilverStripe\ORM\DataObject;
use SilverStripe\CMS\Model\SiteTree;

use SilverStripe\Forms\TreeDropdownField;


class CustomSiteConfig extends DataExtension
{

    private static $db = [
    	'ContactAddress' => 'Text',
    	'ContactPhone' => 'Varchar',
    	'ContactEmail' => 'Varchar',

        'MEContactAddress' => 'Text',
        'MEContactPhone' => 'Varchar',
        'MEContactEmail' => 'Varchar',

        'OCContactAddress' => 'Text',
        'OCContactPhone' => 'Varchar',
        'OCContactEmail' => 'Varchar',


    	'LinkedInLink' => 'Varchar',
        'FacebookLink' => 'Varchar',
        'TwitterLink' => 'Varchar',
        'InstagramLink' => 'Varchar',

        'DefaultBannerTitle' => 'Varchar',
        'EnquiryContent' => 'Varchar',


    ];

    private static $has_one = [
        'DefaultBanner' => Image::class,
        'EnquiryLink' => SiteTree::class
    ];

    private static $owns = [
        'DefaultBanner'
    ];

    public function updateCMSFields(FieldList $fields)
    {

    	$fields->addFieldsToTab('Root.Main',[
    		HeaderField::create('hf1','Global Contact Details'),
    		TextareaField::create('ContactAddress'),
    		TextField::create('ContactPhone'),
    		TextField::create('ContactEmail'),   		
    	]);

        $fields->addFieldsToTab('Root.Main',[
            HeaderField::create('hf2','Middle East Contact Details'),
            TextareaField::create('MEContactAddress'),
            TextField::create('MEContactPhone'),
            TextField::create('MEContactEmail')            
        ]);

        $fields->addFieldsToTab('Root.Main',[
            HeaderField::create('hf3','Oceania Contact Details'),
            TextareaField::create('OCContactAddress'),
            TextField::create('OCContactPhone'),
            TextField::create('OCContactEmail')            
        ]);

        $fields->addFieldsToTab('Root.Main',[
            HeaderField::create('hf4','Social Media'),
            TextField::create('LinkedInLink'),
            TextField::create('TwitterLink'),
            TextField::create('FacebookLink'),
            TextField::create('InstagramLink'),            
        ]);
        $fields->addFieldsToTab('Root.Main',[
            HeaderField::create('hf4','Enquiry bar'),            
            TextField::create('EnquiryContent'),
            TreeDropdownField::create( 'EnquiryLinkID', 'Enquiry Link', SiteTree::class )
        ]);

        $uploader = UploadField::create('DefaultBanner');
        $uploader->setFolderName('BannerImages');
        $uploader->getValidator()->setAllowedExtensions(['png','gif','jpeg','jpg']);

        $fields->addFieldsToTab('Root.Main', [
            HeaderField::create('hf2','Default Banner'),
            //TextField::create('DefaultBannerTitle','Default banner title'),
            $uploader


        ]);

        
    }
}
