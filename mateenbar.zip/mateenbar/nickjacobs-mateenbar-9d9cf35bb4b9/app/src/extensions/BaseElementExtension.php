<?php

//use gorriecoe\LinkField\LinkField;
//use gorriecoe\Link\Models\Link;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\DropdownField;
use SilverStripe\Forms\TextField;
//use SilverStripe\Forms\LiteralField;
//use SilverStripe\Forms\HeaderField;
//use SilverStripe\Forms\Tab;
use SilverStripe\ORM\DataExtension;


class BaseElementExtension extends DataExtension
{

    private static $db = [        
        'HeadingLevel'   => 'Varchar', 
        'ModulePadding' => 'Enum("normal,none","normal")',
        'ModuleWidth' =>  'Enum("contained,fullwidth","contained")',
        'ModuleBg' => 'Varchar'
    ];

    private static $many_many = [];

    private static $many_many_extraFields = [];

    private static $defaults = [];

    
    public function updateCMSFields(FieldList $fields)
    {

        $fields->removeByName(['HeadingLevel','Padding']);

        $heading = DropdownField::create('HeadingLevel', 'Heading level', array( 'h2' => 'Heading 2', 'h3' => 'Heading 3', 'h4' => 'Heading 4'), $value = 'h3');
        $heading->setDescription('Ignore this if the title is not displayed'); 
        $fields->insertAfter('Title',$heading);

        $padding = DropdownField::create('ModulePadding', 'Module padding', array( 'normal' => 'Normal', 'none' => 'None'), $value = 'normal');
        $padding->setDescription('Set the vertical padding on this element'); 
        $fields->insertAfter('HeadingLevel',$padding);

        $width = DropdownField::create('ModuleWidth', 'Module width', array( 'contained' => 'Contained', 'fullwidth' => 'Full width'), $value = 'contained');
        $width->setDescription('Set the width of this element'); 
        $fields->insertAfter('ModulePadding',$width);

        $fields->insertAfter('ModuleWidth',TextField::create('ModuleBg','Row background color'));

        
        return $fields;
    }

    public function getHeadingTag()
    {
        return ($this->owner->HeadingLevel ? $this->owner->HeadingLevel : 'h3');

    }

    public function getModulePad()
    {
        if($this->owner->ModulePadding == 'none')
            {
                return 'nopadding';
            }

    }

}
